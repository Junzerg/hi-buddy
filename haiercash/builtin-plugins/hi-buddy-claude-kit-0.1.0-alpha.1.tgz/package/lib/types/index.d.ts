import { Context, Service } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { EnvironmentView, SessionSnapshot, StoredSession } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        hiBuddyClaude: HiBuddyClaude;
    }
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        'hi-buddy-claude/denied': {};
        'hi-buddy-claude/unavailable': {};
    }
}
export default class HiBuddyClaude extends TypertRemoteService {
    static inject: string[];
    private domain;
    private engine;
    private models;
    private stopping;
    constructor(ctx: Context);
    protected [Service.init](): Promise<void>;
    private authorize;
    private detect;
    environment(executable?: string): Promise<EnvironmentView>;
    modelChoices(): Promise<{
        models: {
            provider: string;
            model: string;
            name: string;
            providerName: string;
        }[];
        problems: {
            provider: string;
            code: string;
        }[];
    }>;
    list(): StoredSession[];
    open(id: string): SessionSnapshot;
    create(cwd: string, provider: string, model: string): Promise<StoredSession>;
    send(id: string, requestId: string, text: string): Promise<string>;
    answer(id: string, taskId: string, approvalId: string, allow: boolean, answers: {
        question: string;
        answer: string;
    }[]): boolean;
    cancel(id: string): void;
    watch(id: string, signal: AbortSignal): AsyncIterable<SessionSnapshot>;
}
