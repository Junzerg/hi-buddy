export declare function taskFailure(error: unknown): string;
