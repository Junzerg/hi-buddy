import { z } from 'zod';
import type { StoredSession } from '../types.ts';
export declare const claudeDomain: {
    name: string;
    version: number;
    layout: "per-record";
    global: {
        schema: z.ZodObject<{
            executable: z.ZodString;
        }, z.core.$strip>;
        initial: {
            executable: string;
        };
    };
    tables: {
        sessions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, StoredSession>;
    };
};
