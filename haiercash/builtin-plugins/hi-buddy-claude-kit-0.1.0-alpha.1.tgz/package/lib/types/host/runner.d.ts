import type { Context } from '@deepseek-ai/cordis';
import type { TaskExecution } from './session-engine.ts';
import { DshModelSource } from './model-source.ts';
/** Supported CLI pin: expand only after a real compatibility run. */
export declare const CLI_VERSION = "2.1.218";
export declare const SDK_VERSION = "0.3.218";
export declare function taskRunner(ctx: Context, models: DshModelSource, executable: () => Promise<string>, configDirectory: string): (task: TaskExecution) => Promise<void>;
