import { Interactions, type InteractionAnswer } from './interactions.ts';
import type { StoredSession, SessionSnapshot, TranscriptEntry } from '../types.ts';
export interface SessionPersistence {
    list(): StoredSession[];
    save(session: StoredSession): Promise<void>;
}
export interface TaskExecution {
    signal: AbortSignal;
    session: StoredSession;
    text: string;
    nativeSession(id: string): Promise<void>;
    append(message: TranscriptEntry): Promise<void>;
    ask: Interactions['ask'];
}
export type TaskRunner = (task: TaskExecution) => Promise<void>;
/** Single Host admission owner. Client subscriptions do not own tasks or approvals. */
export declare class SessionEngine {
    private readonly persistence;
    private readonly run;
    private readonly sessions;
    private readonly tasks;
    private readonly directories;
    private readonly listeners;
    private readonly epoch;
    private sequence;
    private closed;
    constructor(persistence: SessionPersistence, run: TaskRunner);
    initialize(): Promise<void>;
    list(): StoredSession[];
    snapshot(id: string): SessionSnapshot;
    create(input: Pick<StoredSession, 'cwd' | 'provider' | 'model' | 'cliVersion' | 'sdkVersion'>): Promise<StoredSession>;
    private notify;
    private commit;
    send(id: string, requestId: string, text: string): Promise<string>;
    answer(id: string, taskId: string, approvalId: string, answer: InteractionAnswer): boolean;
    cancel(id: string): void;
    subscribe(id: string, signal: AbortSignal): AsyncGenerator<SessionSnapshot>;
    settled(id: string): Promise<void>;
    close(): Promise<void>;
}
