export type SessionStatus = 'idle' | 'running' | 'waiting-for-input' | 'cancelling' | 'completed' | 'failed' | 'interrupted';
export interface TranscriptEntry {
    id: string;
    kind: 'user' | 'assistant' | 'tool' | 'tool-result' | 'notice';
    text: string;
    toolName?: string;
    toolUseId?: string;
}
export interface StoredSession {
    version: 1;
    id: string;
    nativeId?: string;
    cwd: string;
    provider: string;
    model: string;
    cliVersion: string;
    sdkVersion: string;
    status: SessionStatus;
    revision: number;
    createdAt: string;
    updatedAt: string;
    taskId?: string;
    error?: string;
    requests: {
        id: string;
        text: string;
        taskId: string;
    }[];
    messages: TranscriptEntry[];
}
export interface ApprovalView {
    id: string;
    taskId: string;
    toolUseId: string;
    toolName: string;
    inputJson: string;
}
export interface SessionSnapshot {
    epoch: string;
    sequence: number;
    session: StoredSession;
    approvals: ApprovalView[];
}
export interface EnvironmentView {
    path: string;
    version: string;
    sdkVersion: string;
    compatible: boolean;
    error: string;
    authentication: 'unknown';
}
