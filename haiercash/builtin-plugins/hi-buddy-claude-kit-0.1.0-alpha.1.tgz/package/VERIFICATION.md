# 验证记录

日期：2026-11-09。插件 `0.1.0-alpha.1`。这是可供集成的 alpha，不是 Desktop 发布验收结论。

## 实测基线

| 项目 | 版本 / 范围 |
| --- | --- |
| OS | Linux x86_64，kernel 6.8.0-146-generic |
| Node | 24.22.2（默认 shell 的 22.23.1 未用于正式构建验证） |
| pnpm | 11.28.5 |
| SDK | @anthropic-ai/claude-agent-sdk 0.3.218，包声明 CLI 2.1.218 |
| 用户本机 CLI | 2.1.218；始终显式传入 executable |
| DSH | 0.2.2-rc.1，checkout HEAD d5008d13d4ab3463bcb1f7897bfb118d21a17f44 |
| 外网模型 | 用户 Web profile 的 deepseek-athropic / deepseek-flash[1m]，anthropic-messages |

宿主工作树有其他未提交改动（包括 ui-settings-models 文案与设计资料）；本任务未修改宿主源码、bundle、lockfile、desktop 打包脚本或预置包。源码 checkout 与已构建宿主产物一起构成此次开发基线，不能只凭 HEAD 重现整棵工作树。

## 已验证

### 构建与可重复测试

- Host / Client TypeScript 编译通过，宿主 Typert 工具链生成 `./typert`、`./remote` 与编解码产物；不手写 Remote 类型副本。
- 24 项自动测试：显式协议与地址保留、配置缺失/非法地址、错误分类脱敏、未知存储版本拒绝、环境白名单、错误 task/重复审批、取消及关闭审批、问题完整性、发送幂等与重启不重跑、同目录互斥、Client 订阅退出不取消、重启状态、插件关闭结算。
- 真正的 `subprocess-local` 测试：停止拥有的进程范围、重复清理、拒绝关闭后新进程；另外启动的测试进程保持存活。

### 真实 Loader / app / Remote

`scripts/check-loader.ts` 在临时 DSH home 中通过正式 headless profile、app boot 和 Loader 加载构建后的插件，非手动串联 `ctx.plugin(Kit)`：

- 插件激活、读取真实 settings/llm/credentials 服务，保留原有 agents 服务。
- 真实 Gateway 调用生成的 Remote 方法，安全输出不包含 fixture 凭据，未授权 peer 被拒绝。
- Remote watch 返回真实会话快照。
- 通过 Loader entry 禁用后 Host service 与 Remote 注销；重新启用后原有 v1 会话仍在，原有 agents 服务保持可用。
- CLI 缺失、不可执行、不支持版本，以及含空格/中文的 CLI 路径。

### 本机 CLI 与外网模型

`scripts/probe-dsh-model.mjs` 使用宿主凭据 provider 只读解析用户保存的外网路由，在临时配置目录中测试；不是运行中 Host 的完整模型解析，因此另有以下 packaged Host 测试。

- 两轮聊天、流式事件、原生 session ID 续聊。
- 原生 Write 审批允许后文件存在，拒绝后目标文件不存在；收到工具结果。
- 原生 AskUserQuestion 回调收到测试答案并成功完成。
- 原生 Bash 执行固定 `sleep 30` 后取消，宿主 subprocess 确认所有测试进程范围为空。
- 审批决定由测试脚本对限定 fixture 请求返回，不代表真人页面点击验收。

`scripts/check-live-loader.ts` 进一步通过真实 Loader 与 **构建后的 Host 服务**测试：

- 从临时 Host 的有效 settings、llm 与原生 credentials provider 解析用户保存的路由，不复制凭据到配置。
- 第一轮成功；同 request ID 重试返回同 task ID。
- 关闭整个测试 Host，再启动同一测试 home，第二轮续聊准确保留首轮约定词及原生 session ID。
- 删除本测试拥有的原生 session 文件，续聊明确失败，未伪装成已恢复。
- alpha.1 增加原生 AskUserQuestion 等待期间通过 Loader 禁用／重新启用：任务 interrupted、旧审批回答 false；另一次等待期间关闭整个 Host，再启动后 interrupted 且无旧审批。两项均使用真实 CLI 与外网模型通过。

### 页面交互与截图

`scripts/check-browser.mjs` 用真实宿主 Button/Input/theme 渲染实际 Page 组件。页面数据/操作为明确标注的 fixture，不连接生产 Host，不开启任何生产旁路服务。

- 创建会话、发送、回答问题、拒绝操作通过；无浏览器控制台异常。
- 390px 窄窗口无页面横向溢出；浅色及深色截图已生成并查看。
- `verification/fixture-empty-light.png`
- `verification/fixture-conversation-light.png`
- `verification/fixture-mobile-dark.png`

## 未验证 / 交付边界

- 内网公司网关、公司账号 token 刷新及默认模型同步。用户已确认内网支持 Messages；本机未探测内网。
- Windows、macOS、真实 Electron Desktop，以及实际当前 app 安装/启用/禁用/卸载/升级后的完整 UI 流程。
- 浏览器经真实 Web carrier 在网络中断、重连及多窗口情况下的端到端回归。已有 Host 幂等、Remote 快照、订阅断开和框架重连实现测试，不能替代该项。
- 模型 API 未认证、网络故障、异常协议的完整 fixture 矩阵；已有安全错误分类及历史未登录实测，但尚未覆盖全部 UI 场景。
- 其他 SDK/CLI 版本，继承 catalog 默认协议的 provider，企业工具桥接、项目 hooks/MCP 开启、计划模式、全量原生历史导入。
- v1 到未来 schema 的升级迁移；当前只读写 v1，拒绝不匹配的版本，不自动修改未知格式。
- 强制 SIGKILL/机器掉电无法运行插件 disposer；持久任务重启标 interrupted，平台进程托管的崩溃保证需 Desktop 平台验收。
- 正式名称、商标及最终部署许可由宿主发布准备核定。

## 失败与已修复问题

- 早期个人登录探针：在 peng 用户下、settingSources=[] 时返回 `Not logged in`，虽然原生 auth status 为 true。后续用户明确改用 DSH 模型配置，该历史结果不再是产品阻塞，也没有要求迁移 OAuth token。
- 初次 Client 编译发现开发链接被 pnpm 的 registry 同版本包替换，导致模块声明不一致；开发链接脚本改为显式指向目标宿主，重新生成与构建通过。发布包无本机路径依赖。
- 初次浏览器启动缺 libatk 等库；本机已有 `/tmp/haier-browser-libs/extracted/usr/lib/x86_64-linux-gnu`，仅以 LD_LIBRARY_PATH 为测试提供，不是运行依赖。
- 页面测试最初以同名 label 同时匹配消息区和输入框；改为 textbox 角色定位后通过。

## 命令

```sh
pnpm install --ignore-scripts
pnpm dev:link-host
pnpm build
pnpm test
pnpm typecheck
pnpm test:loader
pnpm test:browser
pnpm test:live /absolute/dsh-home provider-id /absolute/claude
pnpm pack --pack-destination dist
```

浏览器须安装 Playwright 的系统依赖；上述临时库目录只是本机验证环境，包内不会引用它。真实测试会产生所选服务用量，默认单元测试不访问模型 API。源码调研及许可详情见 THIRD-PARTY-NOTICES.md。

## 安装包检查

- alpha.1 已从独立 `/tmp` 消费目录安装的 tgz 路径，通过真实 Loader/app 执行环境检测、生成 Remote、禁用/重新启用和数据保留测试；不是只导入源码服务。测试入口可用 `CLAUDE_KIT_TEST_ENTRY=/absolute/installed/package/lib/index.js pnpm test:loader` 指定。
- 独立 `/tmp` 消费目录通过 pnpm 安装 tgz（不读取相邻宿主源码、不执行安装脚本），Host、typert 与 remote 三个入口导入成功。不是当前 Desktop 的插件管理安装验收。
- 包含 Host/Client、生成编解码、两种 locale、bundle patch、许可与 README/VERIFICATION；运行依赖无 `workspace:*`、`file:` 或本机绝对路径。
- 初次包审计发现 Client 的构建注释携带开发机 CSS 路径（非运行依赖）；改为压缩 Client 产物，重新生成后路径检查通过。
- 生产 Client 模块注册通过 VM 语法/注册检查。独立安装不等于真实 app 已启用 Client；桌面装配验收仍未完成。

## 四项目报告 P0 复核（alpha.1）

已阅读 `docs/FOUR-PROJECT-AUDIT-2026-11-09.md` 及来源索引。保持官方 SDK＋DSH 路线，未移植 AGPL 实现，未采用 abort 后另发 continue 的审批方案。Happy 新 commit 的补充研究不改变原研究快照来源与许可证；本轮新增运行时代码为插件自己的状态保护。

| 检查 | 结果与证据 | 仍需验收 |
| --- | --- | --- |
| 已回答审批刷新/重连/多窗口 | 两个真实 engine 订阅者均收到无审批快照；重订阅无旧审批。Client SnapshotOrder 测试丢弃乱序帧及旧 Host 帧 | 真实浏览器 Web carrier 多窗口断网端到端 |
| 重复发送/审批/过期审批 | 并发准入仅一个任务，其他 busy；持久 ID 重试不重跑；回答与取消两种顺序、预取消、旧 task/重启审批均拒绝重复结算 | 网络丢包全链路 |
| 旧任务 finally/exit | 回调持有任务对象身份，终结后禁用；finally 仅释放仍归属自己的 reservation。A 完成、B 运行时注入 A 的延迟写入/原生 ID/审批，B 不受影响 | 平台级异常退出矩阵 |
| Client 断连与 Host 重启 | 订阅关闭不取消；Host close 释放订阅；重启中断旧任务、保留请求去重，不重跑。真实 Loader＋CLI 的重启续聊另有测试 | SIGKILL/掉电的进程托管 |
| 取消/禁用/退出清理 | managed-range 测试包含直接父进程先退出、后代仍活着的情况；清理后后代不再运行，另开进程不受影响。引擎关闭拒绝审批并等待 runner 清理；真实 Loader 在原生问题等待期间禁用/退出并重开通过 | Desktop 操作系统退出、卸载按钮到子进程的完整链路；外部 Claude 共存专项 |
| CLI 缺失不回退 | Loader 检查缺失、不可执行、空格中文路径、不支持版本；runner 在 query 前拒绝不兼容路径，始终显式 executable | Windows wrapper 与 macOS |
| 原始公司路由及认证 | 新增 account resolver fixture：原始 endpoint/model ID 保留、每任务刷新 token、异步配置变化拒绝执行、缺 token 报错，不改用其他凭据 | 内网公司登录及真实 token 刷新 |
| AskUserQuestion | 多问题、原始选项、多选文本及自由回答保留，只传允许的 answers；普通审批不能改写命令 | 原生多选控件未实现；使用文本输入 |
| 恢复丢失/失败与终态 | 真实 CLI 原生记录删除后失败；runner 只接受明确 success 且非 is_error，流结束本身不算成功 | 完整协议错误 fixture 矩阵 |
| 同目录互斥 | Host create 用 realpath；engine 原子占用 cwd；同目录第二任务 busy | Windows 大小写/链接的真实文件系统测试 |
| 加载、数据与许可 | 正式 Loader/app、生成 Remote、v1 保留与未知版本拒绝；发行包不依赖开发机路径 | 当前 Desktop 插件管理 UI 的安装/升级与原聊天完整回归 |

本轮修正了三处实际边界：状态写入串行化并限制回调归属；取消状态不再被在途写入覆盖；准入存储结果未知时 fail closed，不用旧快照覆盖可能已保存的去重记录。快照新增 Host epoch/sequence（不改变持久 v1），Client 过滤旧序号与已退役 epoch。审批不写入持久存储；Host 重启不恢复旧审批。

以上分别是源码复核、可重复测试和此前真实 CLI 验证，不把上游源码调研算作本插件运行通过。未验证项保留在各行及上文，不宣称完整桌面验收或双平台通过。
