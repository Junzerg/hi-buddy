# 上游调研与复用选择

核查日期：2026-11-09。以下 commit 由 GitHub API 返回，许可证及归档状态同时核查；它们是研究基线，不等于已验证运行兼容。

## 选择

优先使用官方 TypeScript Agent SDK 的公开 `query`、`canUseTool`、`resume` 与取消能力，显式指定用户本机 CLI。Happy 当前的 query 本身已是官方 SDK 适配层，不需要重写 CLI 交互协议。

Happy 的审批请求映射、一次性结算和 AbortSignal 清理值得局部复用，但不整体移植其 PermissionHandler：它依赖 Happy Session、远程 RPC、推送、agent state 和权限缓存。插件必须替换这些依赖为 DSH Remote、storage-domain 与生命周期，并排除自动同意与 bypass 路径。尚未决定复制哪些代码到运行实现；现有快照仅用于核查，许可证已保留。

不复制 AGPL 项目代码，不嵌入其他 app，不引入 relay、账号或移动端同步。SDK 包自身的许可证也需单独检查，不能按 Happy 的 MIT 许可证解释。

## 固定来源

| 项目 | commit | 状态 / 许可证 | 用途 |
| --- | --- | --- | --- |
| [slopus/happy](https://github.com/slopus/happy) | `6c8758d62bf5f244e9a3375c6b012f99a5abb337` | 未归档 / MIT | SDK 与审批适配的优先参考 |
| [siteboon/claudecodeui](https://github.com/siteboon/claudecodeui) | `2053f3d7a086fd44f7fe373c913da487629b0a95` | 未归档 / AGPL-3.0 | 功能参照，不复制代码；resolver 的详细执行路径尚待复核 |
| [winfunc/opcode](https://github.com/winfunc/opcode) | `c24004d3bbc910bd30b49d402daec254dac26ab2` | 未归档 / AGPL-3.0 | 不作为底座；用户指出的跳过权限路径尚待本轮逐文件复核 |
| [sugyan/claude-code-webui](https://github.com/sugyan/claude-code-webui) | `9109263873cfc2a6eb0a160396fdfd60c2d6a37f` | 已归档 / MIT | 仅局部参考，不推断当前 CLI 兼容性 |

### Happy 已读文件

- `packages/happy-cli/src/claude/sdk/query.ts`：包装官方 SDK；传递 cwd、resume、permissionMode 与 canUseTool。当前实现复制整个 process.env，不符合本插件环境筛选要求；也未显式固定本机 executable，不能原样采用。
- `packages/happy-cli/src/claude/utils/permissionHandler.ts`：使用 SDK toolUseID；维护 pendingRequests；响应时删除请求；AbortSignal 清理；AskUserQuestion 单独进入交互。其权限缓存、模式切换、Session 与远程通知绑定需要剥离。
- 根 `LICENSE`：MIT，Copyright (c) 2026 Happy Coder Contributors。快照见 `research/happy-LICENSE`。

## 官方接口核查

- [TypeScript reference](https://code.claude.com/docs/en/agent-sdk/typescript)
- [用户交互](https://code.claude.com/docs/en/agent-sdk/user-input)
- [权限](https://code.claude.com/docs/en/agent-sdk/permissions)
- [原生设置](https://code.claude.com/docs/en/agent-sdk/claude-code-features)
- [认证与分发](https://code.claude.com/docs/en/legal-and-compliance)

当前文档强调 canUseTool 不是所有工具的必经路径；原生规则与 hooks 也参与判断。实现不能宣称每个工具都会询问。

当前设置文档说明省略 settingSources 会读取原生文件配置；显式空列表仍不排除 managed policy 和全局 ~/.claude.json。实现应明确传值并显示策略，不依赖跨版本默认值。

分发文档要求保留原始二进制与原生认证方法，用户自行认证及承担用量，不由插件代收或中转凭据。文档另有限制产品/功能命名的品牌条款；“Claude”仍只作为用户指定的内部工作名称，正式发布前由宿主方核定名称及适用条款。

## 最小验证门槛

本机 CLI 为 2.1.218，npm registry 当前 SDK 为 0.3.319。版本号并不证明兼容；SDK 版本暂未选定，需检查包声明并实测显式 executable、默认审批、两轮续聊、AskUserQuestion 和取消。

后续核查找到 SDK `0.3.218`，其 package.json 明确声明 Claude Code `2.1.218`，选作第一轮验证候选。初始化成功，但真实请求返回未登录错误，详见 `VERIFICATION.md`；尚未选定可发布的兼容版本。SDK `0.2.218` 不存在（registry 返回 E404），不能按错误的版本前缀推导配套关系。

在这条真实链路通过前，不扩展正式页面，不使用纯 fixture 成功替代真实兼容性证据。若本机认证、网络或受支持 API 阻碍验证，保留具体失败阶段与可复现步骤，不更换成内置 CLI 或私有协议。
