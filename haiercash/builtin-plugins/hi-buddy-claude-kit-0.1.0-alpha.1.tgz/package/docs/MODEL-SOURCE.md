# 模型来源决定

状态：用户已确认产品方向；接口适配与真实执行尚未验证。

## 当前接入契约（后续确认，优先于下方历史调研）

用户确认内网模型网关已提供 Anthropic Messages 接口，并提供模型设置截图作为配置依据。宿主维护方负责将公司默认模型同步改为 Anthropic 风格；插件不修改宿主同步逻辑。

- Web 开发环境：在 DSH 模型设置中配置可从外网访问的 Anthropic Messages 测试路由；插件读取同一宿主的有效配置，不设单独的测试密钥表单。
- Desktop 内网环境：读取宿主同步的公司 Anthropic Messages 路由、模型目录与认证。公司登录及认证刷新由宿主负责。
- 两种环境执行同一资格检查：有效协议为 `anthropic-messages`，存在可选模型且宿主认证可用。不按 Anthropic、DeepSeek、GLM 等品牌筛选，也不按显示名称猜协议。
- 缺少匹配配置、模型或认证时，Host 阻止任务，页面给出具体原因并引导到宿主模型设置确认。配好后可重新检测。
- 保留配置中的服务地址及模型 ID；不把公司模型名转换成官方模型名，不根据品牌把网关地址替换成厂商官方地址。
- 只向所选宿主路由使用其对应凭据；不将公司凭据用于外网测试服务。不读取个人 Claude 登录作为回退。
- 配置满足条件表示允许发起调用；网络、服务认证、CLI 协议与工具行为的真实兼容性另行验证，错误应在页面可恢复地展示。

截图证明用户确认的内网配置具有 Anthropic Messages 协议选项及公司模型目录，不证明本开发机已连接内网、该配置已保存到本机 Web profile，或本插件的真实 SDK 链路已通过。本机不探测内网服务。

先前“官方 DeepSeek 地址映射”只作为历史调研保留，**不采用自动地址映射方案**。外网测试也必须由宿主明确配置地址与协议。

2026-11-09 用户明确要求：作为插件直接读取 DSH 模型能力；如果 DSH 没有配置 Anthropic 模型，则要求先配置后使用。这取代最初“不配置 DSH 模型也能聊天”的要求，也取代“双模型来源可选”的建议。

## 产品行为

- DSH 是模型配置与凭据管理的唯一入口。插件不另建账号或 API key 表单，不回退本机原生登录。
- 没有可用 Anthropic 配置时，页面仍可进入并显示原因、CLI 环境和已有会话；创建可执行会话与发送请求受 Host 校验约束，不能只禁用按钮。
- 用户完成宿主模型配置后，插件重新检测并开放使用；每次任务重新解析所选配置，不能继续使用已删除的配置或缓存旧凭据。
- Claude Code 继续拥有执行循环、原生工具权限与会话；不通过 DSH agent 代跑，也不将其记录转成 DSH Session。
- 本机 CLI 仍由用户安装，SDK 显式指定 executable，不使用 SDK 内置二进制回退。
- 凭据只在 Host 内通过宿主正式服务取得，并按 Claude 支持的方式用于该插件拥有的执行进程；不发送到 Client、不记录日志、不写入用户 Claude 配置。禁止整份宿主环境透传。
- Claude 原生设置不得覆盖用户在插件中选择的 DSH 服务地址、模型与认证。具体配置隔离方式需实测；不能把 settingSources=[] 误当成完全隔离全局配置。

## 宿主源码初查

宿主 HEAD：`d5008d13d4ab3463bcb1f7897bfb118d21a17f44`。以下为源码事实，不代表集成通过：

- `packages/client/ui-settings-models/README.md`：现有模型设置已支持配置 provider、凭据引用、模型列表和自定义 Anthropic Messages 路由，应复用该设置入口。
- `packages/llm/llm/src/index.ts`：`listProviders()` 是公开元数据；不能假定它返回 endpoint 或凭据，也不能把内部 stream 接口直接传给 CLI。
- `packages/llm/llm/src/types.ts`：可配置 provider 描述包含 settings 定位信息。需继续核查有效配置读取，不能仅凭 provider 显示名识别协议。
- `packages/credentials/credentials/src/index.ts`：宿主有凭据引用解析服务，配置界面无需获得密钥值。
- `packages/llm/llm-pi-ai/src/index.ts`：适配器按任务解析有效 profile 和认证；须对齐其配置语义，不能只读取某个 JSON 文件或绕过凭据服务。

“Anthropic 模型”的具体筛选将依据宿主真实协议元数据。Anthropic Messages 路由与 Claude Code 完整兼容不是同一事实；未实测的第三方路由不能标为已验证兼容。

### DeepSeek 适配澄清

用户已在 Web 配置 DeepSeek，模型列表为 `deepseek-flash`、`deepseek-v4-pro`。资格判断应针对 Anthropic Messages 协议，不能按模型品牌排除 DeepSeek，也不能把配置文件省略 `api` 当成协议不支持：宿主可能继承 catalog 默认值。

2026-11-09 核查 [DeepSeek 官方接口说明](https://api-docs.deepseek.com/guides/anthropic_api/)及 [Claude Code 集成指南](https://api-docs.deepseek.com/quick_start/agent_integrations/claude_code/)，官方提供 `https://api.deepseek.com/anthropic`。因此官方 DeepSeek API key 路由可评估直接复用宿主的凭据与模型，并使用其官方 Messages 端点，不要求用户另配 Anthropic 品牌模型。

该地址映射仅适用于确认是官方 DeepSeek 的路由；不得将自定义网关或账户授权的凭据擅自发送到官方端点。宿主已有 `subagent-claude-code/tests/real-deepseek.e2e.ts` 可参考测试设计，但使用 SDK 内置 CLI 且不是本插件的交互链路，不能代替本机 CLI 的验收。

## 对此前验证的影响

本轮执行用户已确认是 peng，HOME=/home/peng，并非用户目录错误。用户反馈原生聊天正常。原生用户 settings 存在认证及 endpoint 环境配置，仅检查了字段名称，未输出值；此前 settingSources=[] 的探针没有加载这些用户设置，因此原生聊天成功不代表该探针可以认证。

此前未登录结果保留为历史证据，但无需用户重新登录。下一条真实验证链路应使用 DSH 选定模型与 Host 凭据解析；原生登录不再是本插件的产品前置条件。
