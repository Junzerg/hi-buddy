# 四项目补充调研与开发后复核建议

调研日期：2026-11-09。由侧边会话独立完成，供主会话开发完成后参考。本轮只新增本报告及来源索引，不修改实现、依赖、测试、原调研文档或宿主配置，不要求主会话暂停。

本报告是**固定版本的源码审阅**，不是四个上游 app 的运行验收，也不是本插件实现的审计结果。下文“应检查”不代表当前插件已经存在相应缺陷。上游测试只阅读了源码，没有在本轮执行。48 份研究材料的 commit、原始 URL、字节数及 SHA-256 见 [来源索引](FOUR-PROJECT-AUDIT-SOURCES-2026-11-09.json)。上游源码临时下载在仓库外，AGPL 实现没有复制到插件目录或运行产物。

## 给主会话的结论

**继续采用官方 TypeScript Agent SDK＋DSH Host/Client 接入，不建议推倒重来或改为整套 Happy。** Happy 当前的 `query.ts` 本身已经委托官方 SDK；官方 SDK 已承担原生 CLI 通信。DSH 的模型配置、鉴权、Remote、存储和插件生命周期由本插件适配是合理分工。

但“使用官方 SDK”不等于已经复用了完整桌面会话管理。应从下面的成熟实现中吸收可验证的行为，尤其是审批的一次性结算、重连后撤销已回答审批、多窗口同步、旧任务结束不能污染新任务，以及进程清理不能只看直接子进程退出。

建议的复用分层：

| 层 | 建议 | 理由 |
| --- | --- | --- |
| CLI 协议、原生执行与会话续聊 | 直接依赖锁定版本的官方 SDK | Happy 也走同一路径；不复制私有控制协议、不解析交互终端文字 |
| 审批生命周期 | Happy 可作为 MIT 局部改造候选；不整搬类 | 核心生命周期有价值，但它绑定 Happy Session、RPC、推送、权限缓存和模式切换 |
| 重连、回放、多窗口与终态 | ClaudeCodeUI 作为功能及测试场景参照 | 场景覆盖较具体；AGPL 实现不直接复制，也不逐句翻译或机械改名移植 |
| 本机路径与进程管理 | 使用 DSH executable lookup / subprocess | 上游各自的路径兜底、Tauri kill 或共享环境行为不满足本项目契约 |
| UI | 复用宿主 primitives、locale、slots | 不搬上游视觉、组件库或应用导航 |
| 旧 SDK 适配 | 不采用 sugyan 项目的聊天/审批实现 | 固定旧版 Claude Code SDK，审批是中止后发新轮次继续，不是当前原生回调闭环 |

## 版本、许可证与研究边界

| 项目 | 本轮固定 commit | 清单版本 / SDK 声明 | 状态与许可 |
| --- | --- | --- | --- |
| Happy | `b0c0f8a1e9e7796ccc606386bbe7ee279d6cf467` | happy-cli `1.2.6`；Agent SDK `^0.3.295` | 未归档；MIT |
| ClaudeCodeUI | `2053f3d7a086fd44f7fe373c913da487629b0a95` | `1.37.8`；Agent SDK `^0.3.311` | 未归档；根 LICENSE 为 AGPL v3，package.json 声明 `AGPL-3.0-or-later` |
| Opcode | `c24004d3bbc910bd30b49d402daec254dac26ab2` | 前端 package `0.2.1`；核查的 Claude 执行路径是 Rust 启 CLI | 未归档；AGPL-3.0 |
| claude-code-webui | `9109263873cfc2a6eb0a160396fdfd60c2d6a37f` | backend `0.1.56`；旧 `@anthropic-ai/claude-code` 固定 `1.0.108` | 已归档；MIT |

表中 SDK 是 **package.json 声明**，不是本轮安装或测试出的解析版本。不能把使用较新 SDK 的上游行为直接当成插件候选 `0.3.218` / 本机 CLI `2.1.218` 的保证。

Happy HEAD 相比主调研的 `6c8758d62bf5f244e9a3375c6b012f99a5abb337` 已更新。本轮下载的 `query.ts` 和 `permissionHandler.ts` 与项目 `research/` 中最初保留的两份快照 SHA-256 相同；其他文件引用本轮 commit，不混用行号。

许可证来源：[Happy](https://github.com/slopus/happy/blob/b0c0f8a1e9e7796ccc606386bbe7ee279d6cf467/LICENSE)、[ClaudeCodeUI](https://github.com/siteboon/claudecodeui/blob/2053f3d7a086fd44f7fe373c913da487629b0a95/LICENSE)、[其 package 声明](https://github.com/siteboon/claudecodeui/blob/2053f3d7a086fd44f7fe373c913da487629b0a95/package.json)、[Opcode](https://github.com/winfunc/opcode/blob/c24004d3bbc910bd30b49d402daec254dac26ab2/LICENSE)、[claude-code-webui](https://github.com/sugyan/claude-code-webui/blob/9109263873cfc2a6eb0a160396fdfd60c2d6a37f/LICENSE)。

MIT 若后续复制或改造代码，应保留对应版权、完整许可和免责声明，并记录文件、commit 与改动。Happy 的版权署名为 Happy Coder Contributors（2026）；sugyan 项目 LICENSE 署名为 Claude Code Web UI（2025）。不要只写“参考 GitHub / MIT”。

本轮不选择 AGPL 衍生方案；若以后决定移植其实现，需要另行明确许可与分发方案。不能认为只取一个函数、改变量名或改写成另一种语言就自动免除许可条件。图标、字体、第三方 vendor 与 SDK 自身也不能仅凭仓库根许可证一并当成 MIT。本报告不认定任何产品分发方案已经获得法律批准。

## Happy：审批生命周期有价值，整套适配层不宜移植

### 核查结果

1. `sdk/query.ts` 把 cwd、resume、模型与 canUseTool 映射到官方 SDK。它复制整个 `process.env`，设置 Happy entrypoint；这条 wrapper 没有为本项目要求显式提供 executable。AbortSignal 映射注册了 abort listener，本文件未先处理已 aborted 信号，也没有在 query 结束处移除该 listener。**局部改造时需补边界测试，不据此宣称原 app 存在已复现缺陷。** [H1]
2. `permissionHandler.ts` 将 pending request 放入 Map；响应处理先查找、移除 pending，再结算；找不到的迟到/重复响应不再处理。请求 key 在有子 agent 时使用 `agentID:toolUseID`，另保留原始 toolUseID 关联工具消息。`AskUserQuestion` 在自身 allow/bypass 分支前走交互路径。 [H2]
3. 处理器有工具白名单、Bash 前缀缓存、acceptEdits / plan / bypass 路径及实时权限模式更新；这些不是本插件首期“单次用户决策”的必需能力，不应照搬。它允许合并任意 updatedInput；插件应针对问题回答验证字段，普通“允许”保留 Host 持有的原输入，避免 Client 借审批修改命令。 [H2]
4. `reset()` 拒绝内存待处理请求，把服务端遗留请求转成 cancelled。`claudeRemoteLauncher.ts` 在启动处理器后主动 reset 前一个 CLI 留下的审批；理由明确：旧进程已消失，页面仍显示无法结算的审批。这个重启处理值得采用。 [H2][H3]
5. `claudeCheckSession.ts` 通过项目路径对应 JSONL 是否存在、有非空 uuid/messageId/leafUuid 判断“看起来存在”。这只是历史文件启发式检查，**不能证明目标 CLI 成功恢复该上下文**；本插件仍需真实 resume 结果。 [H4]

### 具体采用建议

可复用的最小行为单元是“pending request 的注册—结算—取消—历史状态迁移”。如果主实现已经有一个更小的 DSH 自有实现，不必为了署名复用再换掉它；对照这些行为补测试即可。若直接抽取 H2 代码，应保留 MIT 声明，替换 Session/RPC/push/logger 依赖，删除自动允许缓存，并增加插件 task ID、Host 启动代次和一次性响应校验。

不复用 Happy 的 native JSONL 路径推断、历史重写/fork、entrypoint 标记绕过过滤、共享 process.env 修改、relay 或移动同步。首期不需要其动态切模式、复杂消息排队或全量历史迁移。

来源：

- [H1 — sdk/query.ts](https://github.com/slopus/happy/blob/b0c0f8a1e9e7796ccc606386bbe7ee279d6cf467/packages/happy-cli/src/claude/sdk/query.ts#L28-L85)
- [H2 — permissionHandler.ts](https://github.com/slopus/happy/blob/b0c0f8a1e9e7796ccc606386bbe7ee279d6cf467/packages/happy-cli/src/claude/utils/permissionHandler.ts#L156-L425)
- [H3 — 启动时清理旧审批](https://github.com/slopus/happy/blob/b0c0f8a1e9e7796ccc606386bbe7ee279d6cf467/packages/happy-cli/src/claude/claudeRemoteLauncher.ts#L106-L116)
- [H4 — claudeCheckSession.ts](https://github.com/slopus/happy/blob/b0c0f8a1e9e7796ccc606386bbe7ee279d6cf467/packages/happy-cli/src/claude/utils/claudeCheckSession.ts)
- [H5 — 已有审批测试](https://github.com/slopus/happy/blob/b0c0f8a1e9e7796ccc606386bbe7ee279d6cf467/packages/happy-cli/src/claude/utils/permissionHandler.test.ts)

## ClaudeCodeUI：最有价值的是重连与多窗口场景

### 已复核的本机 CLI resolver

Windows 路径解析尝试 `.exe`、npm wrapper 目标、`where.exe` 查找。未显式配置且没有找到目标时返回 undefined，runtime 仅在解析值存在时设置 `pathToClaudeCodeExecutable`，从而允许 SDK 自行选用内置二进制；显式配置的未解析路径则保留。非 Windows 默认返回裸命令 `claude`。相应行为有命名明确的测试。**这与本插件缺失时必须报错的要求不一致，不移植 resolver。** 路径含空格、npm wrapper、多份安装优先级可以转为测试情形。 [C1][C2]

### 审批及状态同步

- `waitForToolApproval` 有 settled 防重入、Map 清理、timeout 清理、AbortSignal listener 移除，还处理 signal 已 aborted 的入口。普通工具默认等待约 55 秒，交互类工具可无限等待。超时返回拒绝而不是允许。55 秒是该 app 的选择，不是 SDK 要求，也不建议作为本插件默认照搬。 [C3]
- `canUseTool` 通过请求 ID 等待用户结果，并发送 `permission_resolved` / `permission_cancelled`。其回归测试明确覆盖：已回答的 request 仍在 replay buffer 内，若没有撤销事件，刷新和第二个窗口会让审批复活。**本插件若采用完整快照而非事件回放，应让快照只包含仍有效请求，并以 revision/启动代次屏蔽旧事件。** [C3][C4]
- 模块还包含 skipPermissions、bypass 和自行匹配 allow/disallow 的路径，以及 whole-host env forwarding；不建议复制到本插件。 [C3]

### 会话与任务所有权

- `chat-run-registry` 区分 app session ID 与 provider native session ID；后者持久化为映射，运行事件赋予 seq，第二个并行请求被拒绝。多连接附着不会让原连接失去订阅。其状态和 writer 由服务端持有，页面刷新不等于终止任务。 [C5]
- `completeRunIfCurrent` 只允许仍是该 session 当前 run 的对象发终态；专门防止 A 的异步 finally 晚到时把已开始的 B 标成完成。重复 complete 也被过滤。相关测试可以作为本插件的高优先级用例。 [C5][C6]
- 事件缓冲有数量上限，完成任务保留一段时间供回放。这些是内存重连机制，不能当成 Host 重启后的恢复或持久幂等依据。插件的游标宜携带 task ID/运行代次；不要仅以 session 内的一个递增数推断跨任务、跨重启事件归属。 [C5]
- `recordProviderSessionId` 写入映射失败时上游会记录错误后继续；本插件持久化保证较强，不应据此放宽成“原生 ID 保存失败也声称可恢复”。 [C5]

### 不直接采用的部分

自建 WebSocket、REST、数据库、浏览器本地缓存、模块级全局 run Map，以及运行中后台任务/侧问题/steer 的复杂持有逻辑均不是 DSH 接入模板。本插件应保留 Typert Remote 与宿主 stream；先实现用户要求的一会话一任务和明确 busy。

另外，C3 中关于 bypass/auto 下 AskUserQuestion 的注释与当前官方权限文档的表述并不一致。不要拿上游注释当规范，更不要据此添加私有 hook 绕过；以锁定 SDK/CLI 的真实 default-mode 行为为准。 [O1][O2]

来源：

- [C1 — claude-cli-path.ts](https://github.com/siteboon/claudecodeui/blob/2053f3d7a086fd44f7fe373c913da487629b0a95/server/shared/claude-cli-path.ts)
- [C2 — resolver 测试](https://github.com/siteboon/claudecodeui/blob/2053f3d7a086fd44f7fe373c913da487629b0a95/server/shared/tests/claude-cli-path.test.ts)
- [C3 — 原生运行、审批与设置适配](https://github.com/siteboon/claudecodeui/blob/2053f3d7a086fd44f7fe373c913da487629b0a95/server/modules/providers/list/claude/claude-runtime.provider.ts)
- [C4 — 审批重放回归测试](https://github.com/siteboon/claudecodeui/blob/2053f3d7a086fd44f7fe373c913da487629b0a95/src/modules/chat/tests/permissionPromptReplay.test.tsx)
- [C5 — chat-run-registry.service.ts](https://github.com/siteboon/claudecodeui/blob/2053f3d7a086fd44f7fe373c913da487629b0a95/server/modules/websocket/services/chat-run-registry.service.ts)
- [C6 — run registry 测试](https://github.com/siteboon/claudecodeui/blob/2053f3d7a086fd44f7fe373c913da487629b0a95/server/modules/websocket/tests/chat-run-registry.test.ts)

## Opcode：确认排除执行底座，进程 UI 只作功能参照

`execute_claude_code`、`continue_claude_code`、`resume_claude_code` 三个 Rust 入口均在参数数组中带 `--dangerously-skip-permissions`；使用 `-p` 和 stream-json，不是带人机审批的 SDK 回调链路。仅移除一个参数不会自动补出本插件需要的审批协议。 [P1]

`spawn_claude_process` 从 system/init 取得 session ID，发送带 session 后缀的 Tauri 事件，同时保留泛用事件。它还使用 `current_process`，启动新执行前杀掉旧 child。不能照搬为插件多会话所有权；插件必须按自己 task 的 handle 清理，不能因页面切换或另一会话启动而杀旧任务。 [P1]

ProcessRegistry 记录 run/PID，尝试 child kill、超时检查与平台命令回退；但核查的 Unix fallback 发送给单个 PID，Windows fallback 使用 `taskkill /F /PID`。这些代码不能证明完整后代进程均被回收，也不能代替 DSH managed-range 的 waitForExit 验证。 [P2]

`sessionPersistence.ts` 保存 session/project/scroll 等浏览器展示引用，适合作为“展示状态和原生上下文分开”的产品参照，不是 durable task 状态或原生恢复成功的证据。 [P3]

源码中还有整份环境传递、环境值 debug logging、直接 stderr 推送；本插件应使用自己的必要变量清单与凭据脱敏。无需移植 Rust/Tauri 或自建 Electron IPC。 [P1]

来源：

- [P1 — claude.rs，入口约 L1220–1320，进程约 L1495 起](https://github.com/winfunc/opcode/blob/c24004d3bbc910bd30b49d402daec254dac26ab2/src-tauri/src/commands/claude.rs)
- [P2 — process/registry.rs](https://github.com/winfunc/opcode/blob/c24004d3bbc910bd30b49d402daec254dac26ab2/src-tauri/src/process/registry.rs#L239-L432)
- [P3 — sessionPersistence.ts](https://github.com/winfunc/opcode/blob/c24004d3bbc910bd30b49d402daec254dac26ab2/src/services/sessionPersistence.ts)

## sugyan/claude-code-webui：MIT 但审批机制不适合当前需求

该归档项目 backend 固定旧 `@anthropic-ai/claude-code@1.0.108`，chat handler 设置 node executable、显式 cliPath、resume、allowedTools，并将 SDK 消息包装成自建 HTTP NDJSON。所读调用中没有本次需要的 canUseTool 暂停—回答机制。 [S1][S2]

其 UnifiedMessageProcessor 检出权限错误后要求 abort 当前请求并显示权限面板；ChatPage 的“允许”添加工具模式后发送一条新的 `continue`，拒绝仅关闭本地面板。这是**结束当前调用后另起一轮继续**，不能当成“原生审批结果回到同一次执行器”。它会模糊请求幂等和副作用边界，应明确排除。 [S3][S4]

取消请求按 request ID 查 AbortController；Frontend 在 fetch 成功或失败的 finally 都清理 loading 状态，且调用未检查 HTTP 成功状态。本插件不应把“按钮清了 loading”当成 Host 已停止。 [S5][S6]

可参考的内容仅是小而清晰的流消息分类、工具 use/result 关联、历史/展示分层；这些并不构成一个比官方 SDK＋DSH stream 更合适的可移植通信模块。建议本轮不直接复制；将精力用于当前 SDK 的端到端测试。

来源：

- [S1 — backend/package.json](https://github.com/sugyan/claude-code-webui/blob/9109263873cfc2a6eb0a160396fdfd60c2d6a37f/backend/package.json)
- [S2 — backend/handlers/chat.ts](https://github.com/sugyan/claude-code-webui/blob/9109263873cfc2a6eb0a160396fdfd60c2d6a37f/backend/handlers/chat.ts)
- [S3 — UnifiedMessageProcessor.ts](https://github.com/sugyan/claude-code-webui/blob/9109263873cfc2a6eb0a160396fdfd60c2d6a37f/frontend/src/utils/UnifiedMessageProcessor.ts#L109-L140)
- [S4 — ChatPage.tsx 审批动作](https://github.com/sugyan/claude-code-webui/blob/9109263873cfc2a6eb0a160396fdfd60c2d6a37f/frontend/src/components/ChatPage.tsx#L269-L352)
- [S5 — backend/handlers/abort.ts](https://github.com/sugyan/claude-code-webui/blob/9109263873cfc2a6eb0a160396fdfd60c2d6a37f/backend/handlers/abort.ts)
- [S6 — useAbortController.ts](https://github.com/sugyan/claude-code-webui/blob/9109263873cfc2a6eb0a160396fdfd60c2d6a37f/frontend/src/hooks/chat/useAbortController.ts)

## 开发完成后的复核清单

以下是本轮建议，不另加复杂产品功能；优先核对已有实现并补缺失测试。P0 是首期交付边界，P1 是可靠性完善。已通过且未受后续修改影响的测试不必重复跑。

| 优先级 | 复核情形 | 预期结果 / 证据 | 依据 |
| --- | --- | --- | --- |
| P0 | 同一 task 两次发送；多个窗口同时发送；请求已接收但响应丢失后重试 | Host 只启动一次，返回同一任务或明确 busy；终态后重复同一请求也不重跑 | 用户幂等要求；C5 只解决活跃任务互斥，不能替代持久请求去重 |
| P0 | 窗口 A 回答审批，B 仍开着；A 随后刷新 | 两边审批都撤销，旧事件不会复活按钮；SDK 只收到一次结果 | C4、H2 |
| P0 | 注册前 signal 已取消；回答与取消同时到；重复/旧 task/旧 Host 代次回答 | 只结算一次，listener/Map 释放；旧结果不可交给新执行器 | H1/H2、C3；本插件代次约束 |
| P0 | AskUserQuestion 多个问题、多选、自由输入和拒绝 | 保留原问题/选项，验证回答结构；不通过修改命令输入或发送新 continue 冒充回答 | H2、S3/S4、O1 |
| P0 | A 已终结，B 已启动，A 的 finally/exit/timeout 迟到 | 不能改变 B 的 running 状态或清掉 B 的 pending；一个 task 只有一个最终终态 | C5/C6 |
| P0 | Client 断连或离页；Host 重启 | 前者不停止执行，可拿快照追上；后者标 interrupted、旧审批失效，不自动重跑未知副作用 | C5、H3、用户要求 |
| P0 | 原生 session 丢失、cwd/configDir 改变或 resume 报错 | 明确恢复失败；不能以新会话空上下文继续却宣称已恢复 | H4、用户要求 |
| P0 | 停止长命令、禁用、卸载、Host 正常退出，另有用户自开的 Claude | owned managed range/流/审批确实清理；外部 Claude 不受影响；取消请求与确认结束分开记录 | P2、S6、用户要求 |
| P0 | CLI 缺失、不可执行、空格/中文路径、Windows wrapper、不支持版本 | 明确错误，无内置 SDK CLI 回退；argv 数组；由宿主 executable lookup 验证 | C1/C2 |
| P0 | provider result 为错误，或进程退出但没有成功 result | failed/interrupted，不能仅按 subtype、exit code 或 stream end 标成功；无虚构工具完成 | S2 仅流结束不足；用户终态要求 |
| P0 | 两个插件会话指向同一目录，包括符号链接/等价路径 | Host 对规范化目录互斥；显示无法约束外部终端 | 用户要求；不能用 P1 全局 current_process 杀旧任务代替 |
| P0 | Web 外网测试和 Desktop 公司网关配置、登录失效、凭据刷新 | 重用宿主有效配置、原始模型 ID/endpoint；不回退个人登录，不跨 origin 转发公司凭据 | 当前产品决定；四项目都不能代替 DSH 适配 |
| P0 | 包首次安装与升级、真实 Loader/app、Remote 调用和页面交互 | 使用发布包加载，而非手工 service 拼装；模型与 agent 无强制绑定；卸载注册清理 | 用户交付要求；本调研未替主会话执行 |
| P1 | 回放游标过旧、缓冲裁剪、快照订阅边界恰逢新事件 | 明确快照替换/版本规则，不丢终态；大结果/长流有容量边界 | C5；不要复制其数字当宿主规范 |
| P1 | 暗浅色、窄窗、长工具参数、键盘与 IME、失败后重试 | 宿主 primitives；拒绝/停止可达；错误不清空输入或会话列表 | 用户 UI 要求；不移植上游视觉 |

## SDK 与设置策略复核

官方文档说明 canUseTool 用于原生需要人机交互的请求，不保证每个工具都进入它。按真实权限模式显示，首期 default，不引入 Happy/ClaudeCodeUI 的自动同意缓存来“修好”测试。 [O1][O2]

当前官方设置文档说明 settingSources 控制用户/项目/local 文件设置，但不等于完全隔绝 managed policy 和全局配置。项目 hooks/MCP 的加载范围要显式展示；如果插件用自己的 configDir 保持公司模型配置边界，应保证目录在重启后稳定、没有泄露认证，并记录哪些原生用户设置不会加载。相关结论仍需按锁定 CLI 实测。 [O3]

官方资料（活文档，2026-11-09 查阅；不是旧 SDK 行为的追溯保证）：

- [O1 — Handle approvals and user input](https://code.claude.com/docs/en/agent-sdk/user-input)
- [O2 — Configure permissions](https://code.claude.com/docs/en/agent-sdk/permissions)
- [O3 — Use Claude Code features in the SDK](https://code.claude.com/docs/en/agent-sdk/claude-code-features)

## 建议主会话如何使用本报告

1. 先完成当前实现，不为“使用过 Happy 代码”的名义重构工作中的官方 SDK 适配。
2. 用 P0 表逐项对应现有实现与测试证据；确有缺口时做一轮局部修正，优先处理重连审批、任务归属和进程清理。
3. 最终第三方记录明确区分“官方 SDK 运行依赖”“MIT 改造代码”“仅功能参考”“研究快照”。本侧边调研新增的运行时第三方复制量为零。
4. 在 VERIFICATION 中独立记录真实 CLI、协议 fixture、真实 Loader/app、页面交互、桌面平台验收；本报告的上游测试阅读不计为这些项目通过。

本轮没有安装或运行四个上游 app，没有复制 AGPL 实现到插件，没有修改主会话实现，也未验证内网公司网关。已深入核查的是本文列出的核心执行/审批/恢复/重连路径；不宣称覆盖四个仓库的所有功能或依赖许可证。
