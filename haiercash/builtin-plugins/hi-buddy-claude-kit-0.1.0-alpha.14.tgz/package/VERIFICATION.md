# 验证记录

## 已验证

`0.1.0-alpha.14` 在 Ubuntu 24.04.5 x64、Node 24.22.2、DSH `0.2.2-rc.1` 和 hi-buddy `ae0a9064190f44048ebed09ca68d8dc624eda8dd` 上通过构建、类型检查和 25 项自动化测试。Chromium 验证了从 `/` 菜单选择、直接输入后按 Enter、提交按钮、Escape 焦点返回，以及有零个、一个和多个模型时的流程。

真实 DSH Loader 和内置 Claude Code 2.1.218 使用 Anthropic Messages fixture 验证，同一原生会话的下一轮请求使用新模型 ID，历史保留。直接把 `/model` 提交到 Host 的 `send` 会在任务发起前被拒绝。Desktop 窗口和公司网关待验收。[模型选择器截图](verification/model-command-light.png)

`0.1.0-alpha.13` 使用 Ubuntu 24.04.5 x64、Node 24.22.2、DSH `0.2.2-rc.1`、hi-buddy `f60f499f684cf3f966d46551d86578571aa70b51`、Agent SDK 0.3.218 和内置 Claude Code 2.1.218 验证。

| 验证 | 结果 |
| --- | --- |
| 会话呈现 | Chromium 使用宿主 `BrandLogo`、`UserMessageBubble`、`DisclosureRow` 和主题。验证工具参数和结果配对、思考可折叠、命令结果可展开，以及 390px 深色窗口 |
| 真实原生执行 | DSH Loader 与 Typert Remote 通过 Anthropic Messages fixture 接收原生流式思考。真实 Claude Code 执行 Read 并返回文件内容，结果按原生工具 ID 配对 |
| 命令 | 原生目录发现返回八项且不创建会话。`/context` 返回用量，`/compact` 分别验证未压缩、完成事件、续聊与重连。`/code-review` 确认传入的参数出现在 SDK 展开的 Skill 提示中 |
| 本机扩展边界 | 独立临时目录中，`settingSources: []` 不发现示例本机 Skill 和 MCP，启用 `user/project` 后发现该 Skill 并开始连接 MCP。插件本轮保留现有设置策略。MCP 状态 UI 验证使用浏览器 fixture |

[会话预览](verification/session-transcript-light.png) · [命令菜单](verification/slash-commands-light.png)

`0.1.0-alpha.12` 的斜杠命令在 Ubuntu 24.04.5 x64、Node 24.22.2、DSH `0.2.2-rc.1` 和 hi-buddy `63dc1aa9071f0476dac8e513ee8f54589ef68b83` 上验证。构建、类型检查和 25 项自动化测试通过。浏览器覆盖输入 `/`、筛选、方向键、Enter、Escape、点击、参数编辑、显式发送和 390px 窄屏。命令菜单复用宿主 `Menu` 和 `MenuItemButton`。

真实 Loader 与 Agent SDK 0.3.218 的内置 Claude Code 2.1.218 通过 Typert Remote 执行 `/context` 和 `/compact`。测试使用本地 Anthropic Messages fixture，覆盖空会话提示、已有会话带参数压缩、压缩后的原生续聊，以及结果在同一 Host 内重新打开和重连后保留。Gateway 的回复使用 fixture，内网模型实际压缩待验收。

[斜杠命令菜单](verification/slash-commands-light.png)

`0.1.0-alpha.11` 使用 Ubuntu 24.04.5 x64、Node 24.22.2、DSH `0.2.2-rc.1` 和 hi-buddy `7c0124e022001ff7c998f8a6550241f2e3152cec` 的 Loader、Client 组件与主题。构建、类型检查和 25 项自动化测试通过。

| 验证 | 结果 |
| --- | --- |
| 工作区布局 | Chromium 1600px 下会话详情和文件预览可同时打开。文件与 Diff 面板打开或展开时，聊天输入框保留。390px 深色窗口下，标题栏菜单打开下方工具区，长会话名仍为新建按钮留出空间 |
| 文件与改动 | 文件树搜索、定位、创建、刷新和收起通过。聊天文件链接和 Diff 均能跳转预览及行号。改动段反馈可带入现有草稿，焦点返回输入框 |
| 会话 | 左侧会话列表和标题栏选择器保持同步。会话详情可跳到实际审批。原生历史、发送、问答、拒绝和复制续聊命令通过页面 fixture 回归 |
| 真实 Loader 和 Typert Remote | 验证项目内绝对路径可预览，拒绝目录越界和指向外部的符号链接。嵌套项目的 Diff 返回正确的项目相对预览路径。禁用和重新启用后项目仍可读取 |
| 安装包 | 核对 SHA-256、入口、Remote、locale、bundle patch 和依赖引用。从独立目录安装 tarball 并加载，省略平台依赖时得到 SDK 运行时安装提示。PATH 中的测试用 CLI 未被执行 |

[宽屏文件预览](verification/workspace-files-light.png) · [工作台与差异](verification/native-session-light.png) · [窄屏深色](verification/native-session-mobile-dark.png) · [项目入口](verification/projects-light.png)

原生运行时集成验证使用 `0.1.0-alpha.9`。实测环境为 Ubuntu 24.04.5 x64、Node 24.22.2、Agent SDK 0.3.218 和内置 Claude Code 2.1.218。终端验证使用独立的 Claude Code 2.1.218。宿主为 DSH `0.2.2-rc.1`，hi-buddy HEAD 为 `b550cdb269d891badb05aa08fffbb25c39ca403a`。

| 验证 | 结果 |
| --- | --- |
| 安装包 | 从 `.tgz` 安装后由真实 Loader 启用。在独立目录用 `--no-optional` 安装后，发送时由 SDK 报告缺少运行时，会话显示安装提示 |
| 终端与内置运行时往返 | PATH 无 `claude` 时，插件通过内置运行时执行真实模型请求。终端创建的会话可在插件续聊，插件创建的会话可由终端用 `--resume <会话ID>` 续聊 |
| 子 agent 与终端列表 | 插件发起的子 agent 产生可读取的独立记录，终端续聊父会话可读到子 agent 结果。按终端会话选择器规则过滤程序化会话时，插件新建会话不出现在列表中 |
| 会话与任务 | 跨项目打开被拒绝。DSH 新建会话在首次发送后可通过 SDK 查询。原生问题可通过 Remote 回答，重复回答被拒绝。重启后的重复发送返回原任务 ID |

原生会话往返及原生问答的真实模型测试使用已保存的外网 Anthropic Messages 路由，以及临时 DSH profile、工作目录和 Claude 配置目录。终端步骤使用本机 CLI 的非交互模式。

## 未验证

页面截图和交互使用隔离浏览器和 fixture。真实 Desktop 窗口、Windows、macOS、其他终端版本和内网认证待验收。`alpha.13` 的思考和工具过程使用本地模型接口 fixture。本机扩展启用和 MCP 认证、调用待接入。工作区采用固定的并排布局与窄屏堆叠，文件预览只读。自由拖动停靠和面板独立窗口属于后续范围。

## 失败项

首次省略平台依赖的安装检查从源码目录启动，解析到了开发依赖里的 SDK 二进制，导致使用 fixture 地址的请求超时。切换到独立安装目录启动同一个 Loader 检查后通过。
