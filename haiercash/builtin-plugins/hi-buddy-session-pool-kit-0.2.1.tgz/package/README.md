# hi-buddy-session-pool-kit

版本 `0.2.1`。同一个本地 hi-buddy 实例内的普通会话共享一个通信池，成员可来自不同项目或工作空间。插件拥有全部成员、发现、投递校验及简介业务；未修改宿主，不使用 Team、Subagent 运行时、任务分派、等待工具或网络消息服务。

## 使用

打开侧栏会话菜单，选择「加入任务池」；已加入时显示「退出任务池」。保存中禁止重复操作，读取失败可重试，操作结果使用宿主 Toast。菜单每次打开读取宿主当前状态，不轮询；其他窗口改变状态后重新打开菜单即可更新显示，工具授权始终实时校验。

侧栏「任务池」（固定 id `session-pool`）展示唯一共享池的成员数量、工作空间、会话标题、简介与运行状态，点击成员打开对应会话。会话标题前的紧凑图标表示成员资格，hover 显示「已加入任务池」；退出后消失。页面与标记共享可取消的成员事件订阅，页面未打开时也更新；连接重置时重新订阅，读取失败保留上次结果并提供重试。

- `session_pool_list()`：返回其他成员的 `sessionId`、`workspaceTitle`、`sessionTitle`、`summary`、`status`。状态为 `running`、`idle` 或 `unloaded`；宿主没有标题时为空字符串。不提供历史或文件读取权限。
- `session_pool_send({ sessionId, text })`：文字非空且最多 16000 个 UTF-16 code units。发送者仅取工具执行器传入的真实 Agent，不接受 `senderId`。双方必须在池内；禁止发给自己。
- 成功为 `{ ok: true, messageId, status: 'accepted' }`，只表示宿主 `steer` 接受投递。恢复失败为 `restore-failed`；其他投递拒绝为 `delivery-rejected`，附错误说明。未入池调用工具由执行器报告错误。

消息使用宿主 `createUserMessage` 和来源 `{ kind: 'agent-message', form: 'relay', senderSessionId }`。运行中接收方在后续步骤接收，空闲接收方会被唤醒；已保存但未加载的普通会话通过 `sessionController.resolveAgent` 恢复。插件不自行 resume，也不 dispose 借用的 Agent。接收方按普通会话逻辑工作，必要时使用相同工具回复，不强制逐条确认。

恢复前后分别检查成员资格，并比较成员授权代次；恢复期间退出再加入也不会接受旧请求。退出操作立即阻止新发现、发送和接收，并取消简介任务，再等待持久化。退出前已接受的消息属于宿主正常收件箱，不追溯撤回。持久化失败会报告失败；本进程继续拒绝投递，但磁盘仍可能保留旧状态，应重试退出，不能把失败当成跨重启保存成功。

## 简介与持久化

`storageDomain` 的 `hi_buddy_session_pool` 域保存成员加入状态、最近成功简介及对应 `summarySeq`，路径和后端由宿主配置决定。退出和卸载保留记录，重新加入沿用旧简介，随后由新轮次更新。消息仅走原有会话日志和收件箱，没有插件消息数据库。

插件监听 `session/event` 的 `turn/end`，用 host-only `sessionPoolInput` projection 汇总本轮文本、工具结果和最后的模型路由。projection 不出现在客户端快照中；宿主若启用 projection cache，会按其规则保存该有界辅助状态。输入保留最近 24000 个 UTF-16 code units，每项工具结果最多 6000；不扫描文件或导出全会话历史。

每轮结束后通过 `ctx.llm.prepareCall` 使用该会话最后请求的 provider/model，结合上一版简介生成任务、进度和阻塞摘要。辅助用途为 `session-pool-summary`，不写新的会话轮次；选择模型声明的最低推理强度，输出 token 上限 400，超时 30 秒，存储最多 1200 字符。失败保留旧简介并记录日志。新轮次取代旧任务、退出或卸载均 abort；序号、授权代次及串行提交共同防止旧结果覆盖新简介。

卸载撤销两个工具、提示、事件监听、projection、Typert Client 挂载及页面/侧栏入口/前缀标记/菜单/Toast 注册和成员订阅，取消并等待简介调用，等待已开始的投递恢复检查结束，最后关闭存储句柄。

## 宿主依赖与配置

需要 Node >=24.9，目标 hi-buddy `>=0.2.2-rc.1 <0.2.2-rc.2`，且具备已验证的以下实际接口；版本号本身不保证接口存在：

- `agents`、`sessions`、Agent 作用域 `tools` / `systemPrompt`、`llm.prepareCall`、`sessionProjections`。
- `sessionController.resolveAgent`、冷会话安全的 `sessionController.list`、`workspaceRegistry`、`remoteAccess`。
- `storageDomain` 及宿主已配置的持久化后端；`typert` / Gateway 及生成描述符加载。
- Client `remote.$mount`、`slots`、`locale`、共享 React / primitives；ui-workspace 提供 `sidebar.workspaces.session.menu.item`，ui-layout 提供 `shell.overlay` / `main`，ui-sidebar 提供 `sidebar.panellist`，uiWorkspace 提供 `openSession`。需要宿主 Sidebar allowlist 允许 `session-pool`，并提供 `sidebar.session.title.prefix`（list/root/inline，owner.sessionId）；该通用槽位由宿主任务补充，本 kit 未修改宿主。
- 标题来自宿主 `title` projection；若未装标题提供方，则返回空标题。`subagent` 仅为已有 `agent-message` 来源协议的开发期类型引用，不加载其业务或声明客户端依赖。

插件无业务配置项。安装包带有 `cordis.patch.yml`，插入 Host 服务：

```yaml
- id: session-pool
  name: hi-buddy-session-pool-kit
```

在宿主插件安装流程中安装本地 tgz，由宿主读取 manifest 和 patch，并加载 Client 入口；不要仅复制 `lib/client.js`。当前没有替用户安装到正在使用的 profile。

## 构建与验证

从独立 kit 仓库构建。开发时需要相邻 `../../hi-buddy` checkout 及其已构建的真实包；最终 tgz 不需要相邻源码。官方 Typert generator 在忽略的 `build/typert` 分析副本中生成协议，不写宿主源码。

```sh
cd hi-buddy-session-pool-kit
npm ci
npm run build
npm test
npm run test:ui
npm pack
```

入口与产物：`lib/index.js`、`lib/client.js`、`lib/typert.host.*`、`lib/typert.remote-client.*`、声明文件，以及 `hi-buddy-session-pool-kit-0.2.1.tgz`。UI 测试使用相邻宿主的 Playwright 与真实 Menu；输出隔离预览截图到 `dist/verification/`。测试不会操作用户现有会话或数据目录。

具体证据、环境及未验证项见 [VERIFICATION.md](VERIFICATION.md)。公共接口建议见 [0002-session-pool-host-interfaces.md](../docs/design-proposals/0002-session-pool-host-interfaces.md)。

## Model Experience

- 每个普通 Agent 增加两个工具及一段固定简短指引；未入池时工具调用失败，不暴露池成员。
- 指引声明转发消息是其他会话的数据，不是用户或系统指令；不鼓励自动确认循环。
- 池列表占用调用方上下文；成员数量和摘要长度会影响 token 消耗。简介辅助调用按完成轮次发生，使用现有供应商计费，不新增主会话上下文消息或污染主轮次 KV-cache。
- 摘要是模型生成、可能过时的参考信息；`summarySeq` 仅保存最后成功版本，不把摘要失败解释为会话失败。

## Known Limitations and Deferred Work

0.1.1 原始 tgz 已由宿主任务完成完整 Web 验收；本版 0.2.0 新页面和标记尚待宿主任务验收，未调用真实模型供应商。已通过真实 Loader 服务组合及隔离浏览器测试。本版需宿主新增的通用标题前缀槽位及 Sidebar allowlist 配置；现有恢复接口缺少调用方取消参数，卸载期间会等待已启动的恢复结束（随后拒绝投递）；来源协议的类型归属也有改进建议，均未私自修改宿主。

## 0.2.1 图标调整

任务池入口与标题前标记统一使用用户指定的 Lucide MessagesSquare。kit 携带单个 SVG 与完整上游许可（vendor/lucide），不引入图标库运行时。前缀保持 12px，颜色使用宿主 --dsw-alias-state-business-primary，Tooltip、页面与业务保持原有行为。本版完整宿主验收由宿主任务另行执行。
