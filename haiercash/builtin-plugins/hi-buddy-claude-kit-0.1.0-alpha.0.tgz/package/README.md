# hi-buddy-claude-kit

独立 hi-buddy / DSH profile bundle，工作名称“Claude”。本机 Claude Code CLI 拥有执行循环、工具和原生上下文；插件提供页面、审批、取消和会话引用，不创建 DSH agent，不注入原有聊天事件。

当前版本 `0.1.0-alpha.0`，供宿主接入与验收，**不是已通过桌面发布验收的正式版本**。构建、真实 Loader/Remote、Linux 本机 CLI 与隔离页面测试的证据见 [VERIFICATION.md](VERIFICATION.md)。

## 模型与环境

- 唯一模型来源是当前 Host 的 DSH 模型设置。首期读取有效配置中明确声明 `api: anthropic-messages` 的路由、原始模型 ID 和 endpoint，不按模型品牌筛选，不自动切换厂商地址。
- Web 使用已配置的外网测试路由；Desktop 使用公司同步的 Anthropic Messages 路由。默认同步由宿主方调整。无匹配配置、模型或认证时，需要在左下角「设置 → 模型」配置后重试。
- Host 每次任务通过 credentials 服务解析 API key 引用；`accountRequired` 路由调用宿主 deepseekAccount 的、绑定所选 endpoint 的令牌解析。密钥不传给 Client、不落入插件会话。公司登录链路尚未做内网实测。
- 不读取个人 Claude OAuth 凭据，不以原生登录回退。页面原生认证显示“未知”，实际使用的是 DSH 路由认证。
- 只实测并接受 CLI `2.1.218`，SDK 固定 `0.3.218`。路径留空时使用宿主 subprocess executable lookup；否则要求绝对路径。检测缺失、不可执行和版本不匹配；不自动安装/升级用户 CLI，不使用 SDK 内置 CLI 回退。SDK 自身 npm 可选依赖可能下载其平台二进制，本插件始终传入已验证的本机路径。

## 安装与启用

使用目标 app 自带、与 Host 同版本的插件管理入口安装 `.tgz`，选择 `hi-buddy-claude-kit` bundle 并启用 `hi-buddy-claude` 行；没有 HMR 时重启该 profile。独立 CLI 的对应命令为：

```sh
dsh plugin --profile web add /absolute/path/hi-buddy-claude-kit-0.1.0-alpha.0.tgz
```

安装后在插件管理页面启用 bundle。不要使用不明版本的全局 dsh 管理 Desktop；Desktop 的最终接入、预置包及发布准备由宿主维护方完成。本次没有修改宿主 bundle、lockfile 或桌面打包脚本。

Host 服务和 Remote namespace 均为 `hiBuddyClaude`；root sidebar 条目与 main keyed slot 均为 `hi-buddy-claude`。运行时要求 Cordis 4.1.0、DSH `>=0.2.2-rc.1 <0.2.2-rc.2`、Node >=24.9。manifest、生成 Typert、Client、locale 与 bundle patch 随包交付。

## 使用与数据

页面中检测 CLI，选择宿主模型，输入 **Desktop Host 所在机器**的绝对目录。目录会检查存在、权限并规范化；不新增 Electron IPC。创建会话后发送消息；审批仅针对实际进入 `canUseTool` 的请求，允许一次、拒绝或回答原生问题。非回调工具遵循 Claude 原生权限，首期仅使用 default 模式，不提供 bypass 或 plan 模式切换。

**原生设置策略**：使用 `$DSH_HOME/hi-buddy-claude/native` 独立配置目录及显式 `settingSources: []`。不读取个人、项目/local settings、个人登录、项目 hooks 或 MCP；组织 managed policy 仍可能生效。项目 hooks/MCP 可执行代码，本期不提供开启它们的选项。插件不修改用户原有 Claude 配置。

插件引用、任务幂等标识、目录、版本与展示消息通过 `storage-domain` 的 `hi_buddy_claude` v1 域存储，实际后端位置由宿主 storage 路由决定；原生会话文件由 Claude 保存在上述独立配置目录。展示数据不替代原生上下文。每个会话最多 500 次请求、展示记录最多 2 MB；达到限制时应新建会话。

切换页面或 Client 断连不取消任务；重连获取状态快照。停止、禁用和 Host 正常退出会中止本插件拥有的进程范围并使审批失效，不按进程名清理用户自己的 Claude。Host 重启把未终结任务标为 interrupted，不重跑结果未知的命令。恢复失败明确报错，不生成一个新原生会话冒充恢复。

禁用或卸载保留 storage-domain 数据和原生会话文件，不自动清空历史。同目录互斥仅约束同一插件 Host 实例，不能约束外部终端或另一个独立 Host。

## 从源码构建

在本仓库中保留 `shared/`，并在相邻目录放置匹配的 hi-buddy 源码及已构建的类型/运行产物。开发链接只在本插件 node_modules 内建立；消费者安装 tgz 不需要相邻源码。

```sh
cd hi-buddy-claude-kit
pnpm install --ignore-scripts
pnpm dev:link-host
pnpm build
pnpm test
pnpm test:loader
pnpm test:browser
pnpm pack --pack-destination dist
```

浏览器测试依赖宿主已有 Playwright 与系统运行库。真实模型测试会消费所选服务的用量，明确传入保存配置的 DSH home、provider 和本机 CLI 路径：

```sh
pnpm test:live /absolute/dsh-home provider-id /absolute/path/to/claude
```

该脚本启动临时测试 Host，通过宿主凭据服务只读解析所选外网 API-key 路由，不修改你的模型配置。公司账户路由必须在真实公司 Host 中验收。测试源码不作为消费者的安装步骤。

## 已知限制

- Windows/macOS、真实 Desktop 的安装/禁用/升级和视觉验收未验证；截图来自隔离组件 fixture，非桌面截图。
- 首期只识别明确声明协议的配置；仅继承 provider catalog 默认协议的路由暂不可选，需在宿主设置显式选择 Anthropic Messages。
- 当前直接文本回答 AskUserQuestion，完整原生问题及选项展示在请求参数中；未实现原生富交互选择控件。
- 不支持全量导入原生历史、文件回退、Cowork、云同步、企业工具桥接或 app 完全退出后继续执行。
- 部分运行错误采用安全的英文分类提示；页面基础文案有中英字典，完整错误本地化尚未完成。

[来源与许可证](THIRD-PARTY-NOTICES.md)。正式名称及部署条款由宿主发布准备阶段核定。
