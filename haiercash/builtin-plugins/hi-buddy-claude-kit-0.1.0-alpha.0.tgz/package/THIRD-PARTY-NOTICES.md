# 第三方来源与声明

## Happy 研究快照

来源：<https://github.com/slopus/happy/tree/6c8758d62bf5f244e9a3375c6b012f99a5abb337>。

| 本地文件 | 上游文件 | 修改 |
| --- | --- | --- |
| research/happy-query.ts | packages/happy-cli/src/claude/sdk/query.ts | 原样下载，仅文件重命名 |
| research/happy-permissionHandler.ts | packages/happy-cli/src/claude/utils/permissionHandler.ts | 原样下载，仅文件重命名 |
| research/happy-LICENSE | LICENSE | 原样保留 |

许可证：MIT。Copyright (c) 2026 Happy Coder Contributors。完整许可及免责声明见 [research/happy-LICENSE](research/happy-LICENSE)，必须与这些副本一并保留。目前未将研究快照纳入运行代码或发布产物。

AGPL 项目目前只记录来源和调研结论，没有复制其实现。官方 SDK 的最终锁定版本、许可和分发内容将在选型与打包时补记。

## 官方 SDK 验证候选

`@anthropic-ai/claude-agent-sdk@0.3.218` 仅安装在外部临时验证目录。package.json 许可证字段为 `SEE LICENSE IN README.md`；随包 LICENSE.md 内容为：

> © Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

它不是 Happy 的 MIT 代码，不能将其重新标为 MIT。当前目录没有复制 SDK 实现或二进制，最终依赖与许可记录待兼容验证后确定。

## 实现与分发更新（2026-11-09）

正式源码现在使用官方 SDK 0.3.218（精确运行依赖）。SDK 及其可选平台包保留原上游许可；npm 自动安装依赖不改变其许可。本插件不重新打包或修改 Claude CLI，运行始终使用用户安装且验证过的 executable。

Happy 两个文件用于设计评估，没有把它们作为运行模块嵌入。插件自行实现 DSH 所有权、一次性审批和中断清理，保留 MIT 声明于发布包 `third-party/HAPPY-LICENSE`，研究副本仍只在源码目录。AGPL 项目没有代码复制或运行依赖。

宿主进程适配参考 `packages/subagent/subagent-claude-code/src/process.ts` 的公开 SpawnedProcess/SubprocessHandle 契约；本插件使用自己的 task owner、环境筛选和清理实现，不导入宿主一次性 subagent 功能。Cordis/DSH 运行时保持外部 peer；React 与 UI primitives 由宿主 Client 模块表提供。
