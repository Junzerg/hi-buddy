# 验证记录

当前版本为 `0.1.0-alpha.6`。在 Ubuntu 24.04.5 x64、Node 24.22.2、Claude Code CLI 2.1.218、Agent SDK 0.3.218 上验证；宿主为 DSH `0.2.2-rc.1`，hi-buddy HEAD 为 `6fa808311f1e0f125634f8424f31333a647bceb7`，工作树包含宿主模型文案等本地改动。

- 构建、类型检查和 26 项自动化测试通过。macOS 和 Windows 的候选路径使用 fixture 验证，未在这两个平台实机启动。
- 真实 DSH Loader 和 Typert Remote：移除 `NVM_DIR`、`NVM_BIN`，使用仅含 Node 24 和系统目录的 PATH。宿主普通 PATH 查找失败，插件从用户 nvm 的 Node 22.23.1 目录找到真实 CLI，运行 `--version` 返回 2.1.218。
- Loader 还验证了 PATH 优先、显式路径失败时无回退、中文和空格路径、版本不兼容、不可执行、启动失败、异常版本输出、配置持久化和清空。禁用插件后，正在运行的版本探测进程已退出。
- 隔离浏览器验证了未选项目时「运行环境」可见 CLI 缺失提示，并通过既有页面交互回归。没有重启用户正在使用的 Web，也没有重新执行真实模型往返测试。

以下原生会话和模型往返证据来自 `0.1.0-alpha.5`，在同一 CLI／SDK 版本和 DSH `0.2.2-rc.1` 下完成（hi-buddy HEAD `591fd84a989e1e7c474b5da9b3740f028aa5802e`）。

| 验证 | 结果 |
| --- | --- |
| 构建和类型 | Host、Client 及生成的 Typert Remote 构建通过 |
| 自动化测试 | 24 项通过，覆盖凭据解析、审批去重、取消、进程清理及中断恢复 |
| 真实 DSH Loader | 从独立临时目录安装打包产物，验证 Loader 加载、Remote 授权及序列化、CLI 路径检测、禁用和重新启用 |
| 本机 Claude CLI 与真实 DSH Remote | 终端创建会话，DSH 发现项目和会话、读取历史并按同一 ID 续聊。终端再续聊后，DSH 刷新可读到新增消息 |
| 会话与任务 | 跨项目打开被拒绝。DSH 新建会话在首次发送后可通过 SDK 查询。原生问题可通过 Remote 回答，重复回答被拒绝。重启后的重复发送返回原任务 ID |
| Git 改动 Remote | 用真实临时 Git 仓库验证已跟踪文件、含中文空格的未跟踪文件、逐文件差异、拒绝列表之外的路径和非 Git 目录 |
| 项目和文件 Remote | 实际添加空会话项目并在重新启用后读取，验证目录列表、文件查找、新建、只读预览、拒绝覆盖和目录越界 |
| 浏览器页面 | 使用宿主主题、图标和组件验证项目下拉搜索、目录选择器、文件树查找定位、新建文件夹和文件、预览、中间栏会话切换和新建、模型切换、问答及逐文件差异。在 390px 深色视图验证区域切换 |

原生会话往返及原生问答的真实模型测试使用已保存的外网 Anthropic Messages 路由，以及临时 DSH profile、工作目录和 Claude 配置目录。终端步骤使用本机 CLI 的非交互模式。

页面预览使用测试数据。真实 Desktop 安装及浏览器载体的端到端交互、内网认证、Windows 和 macOS 待验收。

[项目入口](verification/projects-light.png) · [工作台与差异](verification/native-session-light.png) · [窄屏深色](verification/native-session-mobile-dark.png)
