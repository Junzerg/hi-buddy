# hi-buddy Claude

在 hi-buddy 侧边栏打开 **Claude**，选择本机项目，再从中间栏顶部选择或新建会话。已有会话按 Claude Code 的原生 ID 继续，新会话在首次发送后进入 Claude Code 的会话列表。在终端继续同一会话后，点击页面的「刷新」即可读取新增内容。

左侧通过可搜索的下拉框切换项目。用「新建项目」打开目录选择器，将选中的现有目录加入列表。文件树支持查找、定位、刷新、全部收起和新建文件或文件夹。点文件在中间查看只读文本预览，关闭预览可返回聊天。右侧「改动」查看文件差异。右侧在任务结束后自动刷新，也可手动刷新。这里展示 Git 工作区相对 HEAD 的未提交改动，包含用户或其他工具的修改。未提交初始版本的仓库分别显示暂存和未暂存差异。窄窗口通过顶部按钮切换区域。

## 使用条件

- hi-buddy / DSH 0.2.2-rc.1，Node.js 24.9 或更新版本。
- 查看工作区差异需要本机 Git。
- 本机 Claude Code CLI 2.1.218。可在「运行环境」填写宿主机器上的绝对路径并检测，Windows 上填写 `.exe` 文件路径。显式路径检测失败时，页面会显示该路径和原因。
- 在 hi-buddy 的「设置 → 模型」配置明确使用 Anthropic Messages 协议的模型和认证。插件使用所选路由的原始模型 ID 和地址，认证由 DSH Host 提供。

在目标 profile 的插件管理器安装本地 `.tgz` 并启用。使用 DSH CLI 管理 Web profile 时，执行以下命令。

```sh
dsh plugin --profile web add /absolute/path/hi-buddy-claude-kit-0.1.0-alpha.6.tgz
```

CLI 路径留空时，插件先查宿主的 PATH。找不到可执行文件时，再查常见的原生安装、Homebrew（macOS）、WinGet（Windows）、npm 全局目录及 nvm 的 Node 安装目录。检测使用选中的文件运行 `--version`。如果机器上有多个版本，可用绝对路径指定兼容版本。插件不会安装 CLI、改写 PATH 或回退到 SDK 内置运行时。常见路径依据 [Claude Code 安装文档](https://code.claude.com/docs/en/setup)、[npm 目录规则](https://docs.npmjs.com/cli/v8/configuring-npm/folders) 和 [nvm 安装布局](https://github.com/nvm-sh/nvm/blob/master/nvm.sh)。

## 会话和权限

项目来自 Claude Code 会话的工作目录和通过目录选择器添加的目录。会话数据来自 Host 用户的 Claude Code 配置目录，默认为 `~/.claude`，也支持 Host 启动时设置的 `CLAUDE_CONFIG_DIR`。页面展示最近 200 条可呈现记录，文本总量上限为 1 MB。

Claude Code 运行工具并写入原生会话。插件转发 Claude 请求的工具审批和问题，使用默认权限模式。执行时关闭用户、项目和本地设置来源，组织托管策略仍可能生效。离开页面后，正在执行的任务会继续。停止任务会关闭插件管理的进程。

同一 Host 在一个工作目录内一次运行一项任务。请在外部终端结束本轮执行后再到 hi-buddy 继续同一会话。插件的 DSH 存储只记录 CLI 路径、已添加的目录、任务状态和请求去重信息，消息历史由 Claude Code 管理。

## 构建和验证

构建需要相邻的 hi-buddy 源码及其已构建的开发依赖。安装包自带生成的 Host、Client 和 Remote 产物。

```sh
pnpm install --frozen-lockfile
pnpm dev:link-host
pnpm build
pnpm test
pnpm typecheck
pnpm test:loader
pnpm test:browser
pnpm pack --pack-destination dist
```

外网模型集成测试需要一个已保存的 Web profile 和明确的 Anthropic Messages 路由。测试使用临时项目和原生会话。

```sh
pnpm test:live /absolute/dsh-home provider-id /absolute/path/to/claude
```

参见 [验证记录](VERIFICATION.md) 、[宿主右栏接入调查](RIGHTBAR.md) 和 [第三方依赖声明](THIRD-PARTY-NOTICES.md)。
