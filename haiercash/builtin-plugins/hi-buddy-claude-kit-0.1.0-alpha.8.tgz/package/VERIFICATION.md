# 验证记录

当前版本为 `0.1.0-alpha.8`。实测环境为 Ubuntu 24.04.5 x64、Node 24.22.2、Agent SDK 0.3.218 和内置 Claude Code 2.1.218。终端验证使用独立的 Claude Code 2.1.218。宿主为 DSH `0.2.2-rc.1`，hi-buddy HEAD 为 `b550cdb269d891badb05aa08fffbb25c39ca403a`。

| 验证 | 结果 |
| --- | --- |
| 构建和类型 | Host、Client 及生成的 Typert Remote 构建通过 |
| 自动化测试 | 25 项通过，覆盖 SDK 会话通信与认证、模型和连接失败的区分，以及凭据解析、审批去重、取消、进程清理和中断恢复 |
| 真实 DSH Loader 和 Typert Remote | 从 SDK 平台依赖检测运行时。验证 PATH 里的同名命令和旧版保存的绝对路径都不参与选择。禁用及重新启用后仍可读取已添加的项目 |
| 安装包 | 从 `.tgz` 安装后由真实 Loader 启用。保留可选依赖时运行时可用。在独立目录用 `--no-optional` 安装时提示缺失并阻止发送，即使 PATH 中有同名命令 |
| 终端与内置运行时往返 | PATH 无 `claude` 时，插件通过内置运行时执行真实模型请求。终端创建的会话可在插件续聊，插件创建的会话可由终端用 `--resume <会话ID>` 续聊 |
| 子 agent 与终端列表 | 插件发起的子 agent 产生可读取的独立记录，终端续聊父会话可读到子 agent 结果。按终端会话选择器规则过滤程序化会话时，插件新建会话不出现在列表中 |
| 会话与任务 | 跨项目打开被拒绝。DSH 新建会话在首次发送后可通过 SDK 查询。原生问题可通过 Remote 回答，重复回答被拒绝。重启后的重复发送返回原任务 ID |
| Git 改动 Remote | 用真实临时 Git 仓库验证已跟踪文件、含中文空格的未跟踪文件、逐文件差异、拒绝列表之外的路径和非 Git 目录 |
| 项目和文件 Remote | 实际添加空会话项目并在重新启用后读取，验证目录列表、文件查找、新建、只读预览、拒绝覆盖和目录越界 |
| 浏览器页面 | 验证内置运行时状态、缺失时禁止发送和复制终端续聊命令。回归项目、文件树、会话、模型、问答和文件差异，在 390px 深色视图验证区域切换 |

原生会话往返及原生问答的真实模型测试使用已保存的外网 Anthropic Messages 路由，以及临时 DSH profile、工作目录和 Claude 配置目录。终端步骤使用本机 CLI 的非交互模式。

页面预览使用测试数据。其他终端版本、Windows 和 macOS 的实际运行、Desktop 安装及内网认证待验收。

[项目入口](verification/projects-light.png) · [工作台与差异](verification/native-session-light.png) · [窄屏深色](verification/native-session-mobile-dark.png)
