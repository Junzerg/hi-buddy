# 宿主右栏接入调查

核查宿主 `591fd84a989e1e7c474b5da9b3740f028aa5802e`。

宿主已提供可扩展的右栏标签。扩展可用 `sidebarRightTabs.register` 声明标签，通过 `sidebar.right.pane.tab` 提供内容。打开资源和页面分别走 `sidebarRight.openResource`、`sidebarRight.openTab`。宿主已有 Document Preview 和 Browser 标签，Git diff 可以作为扩展标签承接插件已有的差异数据。

当前接口有两个具体限制。

- `RightbarRoot.tsx` 只有在 `activePanelId === null` 时显示会话右栏。选中 Claude 独立页面后，宿主会隐藏这些右栏子树。标签控制器要求当前已挂载的 **DSH Session**。直接从没有会话上下文的独立页调用会出现 `sidebarRight: no session surface is mounted`，单独展开布局列也不会产生标签上下文。
- 内置文件预览的资源地址为 `dsh-resource://file/session/<sessionId>/…`，Host 按该 DSH Session 的文件系统校验访问。Claude 原生会话 ID 无法作为这里的 Session ID。Browser 不读 Claude 文件，但它仍是会话右栏中的标签。

可行接法是宿主先支持由独立面板提供右栏上下文。最小契约需要面板标识、项目根目录与权限来源，以及针对该上下文打开标签的操作。宿主再为现有文件预览提供以项目或面板为作用域的资源地址。届时可以复用 Browser、Document Preview 和宿主右栏外壳，由 Claude 插件注册 Git diff 标签。是否把这套上下文扩展为通用能力，应由宿主决定。

本次实现复用了已经公开且独立于 Session 的 `sidebar.files.tree` Factory。宿主右栏联动停在源码调查阶段。当前文件预览是中间区域的只读文本视图，差异仍走现有插件面板。

宿主出处为 `packages/client/ui-sidebar-right/src/client/shell/RightbarRoot.tsx`、`packages/client/ui-sidebar-right/src/client/service.ts`、`packages/client/ui-sidebar-documentpreview/README.md`、`packages/client/ui-sidebar-browser/README.md` 和 `packages/client/ui-sidebar-files/README.md`。项目选择和文件树工具参考了本地 code-platform 的 `src/client.ts` 与 `src/file-search-view.ts`。
