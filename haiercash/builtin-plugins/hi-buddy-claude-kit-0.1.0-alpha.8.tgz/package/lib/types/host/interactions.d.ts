import type { PermissionResult } from '@anthropic-ai/claude-agent-sdk';
export interface PendingInteraction {
    id: string;
    taskId: string;
    toolUseId: string;
    toolName: string;
    inputJson: string;
}
export interface InteractionAnswer {
    allow: boolean;
    answers?: Record<string, string>;
}
/** Task-scoped approvals. Only an extant request can settle, exactly once. */
export declare class Interactions {
    private readonly changed;
    private readonly pending;
    private closed;
    constructor(changed: () => void);
    snapshot(): PendingInteraction[];
    ask(taskId: string, toolName: string, input: Record<string, unknown>, toolUseId: string, signal: AbortSignal): Promise<PermissionResult>;
    answer(taskId: string, id: string, answer: InteractionAnswer): boolean;
    close(): void;
}
