import type { NativeProject, NativeSession, TranscriptEntry } from '../types.ts';
export declare function isNativeId(id: string): boolean;
export declare function nativeProjects(): Promise<NativeProject[]>;
export declare function projectSessions(cwd: string): Promise<NativeSession[]>;
export declare function findNativeSession(id: string, cwd: string): Promise<NativeSession | undefined>;
export declare function redactText(text: string): string;
export declare function nativeHistory(id: string, cwd: string): Promise<TranscriptEntry[]>;
