import type { Context } from '@deepseek-ai/cordis';
import type { FileDiff, WorktreeChanges } from '../types.ts';
export declare function worktreeChanges(ctx: Context, cwd: string): Promise<WorktreeChanges>;
export declare function worktreeDiff(ctx: Context, cwd: string, path: string): Promise<FileDiff>;
