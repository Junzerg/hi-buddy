import type { Context } from '@deepseek-ai/cordis';
import type { EnvironmentView } from '../types.ts';
export declare function detectRuntime(subprocess: Context['subprocess'], cwd: string, signal: AbortSignal): Promise<EnvironmentView>;
