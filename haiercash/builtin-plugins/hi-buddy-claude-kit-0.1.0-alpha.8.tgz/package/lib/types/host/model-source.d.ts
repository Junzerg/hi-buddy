import type { Context } from '@deepseek-ai/cordis';
import type { LlmConfigurableProvider } from '@deepseek-ai/dsh-llm';
import type { SettingsDescriptor } from '@deepseek-ai/dsh-settings';
import type { ModelSelection } from '../types.ts';
export type ModelChoice = ModelSelection & {
    name: string;
    providerName: string;
};
export type ModelProblem = 'missing-provider' | 'missing-settings' | 'unsupported-protocol' | 'invalid-endpoint' | 'missing-model' | 'missing-credential' | 'configuration-changed';
export declare class ModelConfigurationError extends Error {
    readonly code: ModelProblem;
    constructor(code: ModelProblem);
}
/** Host-only operation result. Never serialize this object or put it in storage. */
export interface ModelExecutionConfig extends ModelSelection {
    baseURL: string;
    secret: string;
}
interface Route {
    baseURL: string;
    reference?: string;
    account: boolean;
    identity: string;
}
/** Interpret explicitly configured Messages routes; no provider-name or endpoint rewriting. */
export declare function readRoute(entry: LlmConfigurableProvider, descriptors: readonly SettingsDescriptor[]): Route;
/** Reads the current Host services for every operation; no independent credential cache. */
export declare class DshModelSource {
    private readonly ctx;
    constructor(ctx: Context);
    private route;
    choices(): Promise<{
        models: ModelChoice[];
        problems: {
            provider: string;
            code: ModelProblem;
        }[];
    }>;
    resolve(selection: ModelSelection): Promise<ModelExecutionConfig>;
}
export {};
