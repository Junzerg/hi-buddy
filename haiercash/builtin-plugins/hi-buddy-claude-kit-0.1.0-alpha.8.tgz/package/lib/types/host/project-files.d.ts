import type { ProjectFile, ProjectFileList, ProjectFilePreview } from '../types.ts';
export declare function listProjectFiles(root: string, directory: string): Promise<ProjectFileList>;
export declare function searchProjectFiles(root: string, query: string, signal: AbortSignal): Promise<ProjectFileList>;
export declare function createProjectEntry(root: string, parent: string, name: string, folder: boolean): Promise<ProjectFile>;
export declare function previewProjectFile(root: string, path: string): Promise<ProjectFilePreview>;
