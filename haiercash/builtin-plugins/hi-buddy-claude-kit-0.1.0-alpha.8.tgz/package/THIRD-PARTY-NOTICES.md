# 第三方依赖声明

`@anthropic-ai/claude-agent-sdk@0.3.218` 通过 npm 依赖使用。运行时来自 SDK 的官方平台依赖，保持上游二进制和许可证。插件包仅声明 npm 依赖。部署和预装条件见 [Anthropic 官方条款](https://code.claude.com/docs/en/legal-and-compliance)。

Cordis、DSH、React 和 UI primitives 由宿主提供，各自保留其许可证。
