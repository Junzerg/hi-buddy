# hi-buddy-glossary-kit

版本 `0.3.0-rc.1`。当前本地 profile 共用一份海消术语表，界面和 Agent 共用宿主本地持久化数据。主页面 key 和侧栏 entry ID 均为 `project-glossary`。

## 使用

在侧栏打开「海消术语表」，自动读取本地 profile 的全局术语，无需选择或创建工作区。点击「新建术语」开始录入。名称与定义必填；别名、分类和标签选填。词条 ID 唯一，同名词条可保留不同定义。支持编辑、删除确认、搜索、分类筛选、详情和复制。

新词条默认启用「AI 查询」。已有词条在列表分类下方提供开关，切换后立即保存，不必再次点击保存；切换只提交启用状态，不提交表单里其他未保存的修改。保存失败恢复原开关状态并提示。新词条在创建时应用所选状态。停用只影响 AI 检索，词条仍保留在界面中，可以编辑或重新启用。每个 Agent 的真实工具注册表包含只读 `glossary_search`，系统提示明确覆盖人名、昵称、内部称呼、部门、业务用语和缩写，即使是日常称呼也先查询；追问或新增知识时重新查询相关称呼。查询参数使用具体称呼，不传整句问题；定义不能作为实时考勤等事实的依据。工具只接受 `query`、可选 `limit`，不接受 workspaceId 或 profileId；使用当前宿主 profile 的同一份数据，无工作区会话也可查询。查询覆盖名称、别名、定义、分类、标签；默认返回 8 条、最多 20 条，JSON 输出不超过 16 KB，裁剪时标记 `truncated`。

在可写会话中选中文字，宿主引用浮层会出现「添加术语」。通过该会话的 Agent lookup 和全局资源权限检查后，打开预填名称的新建表单；定义留空、默认启用，保存前不写数据。无工作区会话也支持。同名则打开已有词条（包括已停用词条）；迁移保留了多个同名词条时打开存储顺序中的第一条，其他条目仍可在列表查看和编辑。无权访问或无效会话会提示失败。

导入、导出、术语表信息和重新读取集中在页头「更多操作」中。桌面端固定左右分栏与分隔线，未选中词条时右侧留空，选中后在右侧显示详情；编辑、复制和删除放在详情顶部。

JSON 导出是完整备份。导入只接受 [schemaVersion 2 示例](examples/sample.json)，最大 5 MB，包含必填的布尔字段 `enabled`；替换已保存内容前确认，不合并多份术语表。软件协作示例只在用户主动导入时写入。首次初始化自动加入业务默认项「够花」「海智伙伴」，默认启用，均可编辑、停用和删除；删除后不会补回。已存在同名本地词条时优先保留用户内容，不额外加入同名默认项。没有术语市场入口、embedding 或向量数据库。

## 保存与并发

宿主 `storageDomain` 的 `hi_buddy_glossary` 域的 `profile` 表、`global` 记录保存唯一文档，正文是事实来源。实际磁盘根目录和存储后端由目标宿主的 storage 配置决定，插件不硬编码文件路径。关闭客户端页面不会关闭宿主服务，Agent 仍能查询。

每次写入在服务的串行队列内检查 revision，再等待宿主持久化成功才返回。其他窗口抢先保存会得到冲突，保留当前输入；重新读取后检查内容再保存。没有后台轮询或自动覆盖其他窗口修改。卸载释放工具、提示、槽位、远程贡献和存储句柄，保留持久化数据。

这是未上线格式的切换：不读取、迁移或删除旧 IndexedDB，也不接受旧多表／schemaVersion 1 JSON。旧宿主 `workspaces` 表中的术语会在首次全局初始化时一次性合并，原文件不删除、不修改。按去首尾空格且不区分大小写的名称、定义和启停状态去重，并合并别名／标签；不同分类保留为标签。同名不同定义或不同启停状态均保留独立词条，碰撞 ID 重新生成。默认项和合并结果在同一个原子记录中保存，存在全局记录即不再初始化；失败不标记完成，重启可重试。不跨 profile 或设备同步。

## 权限

Remote `read()`、`write(expectedRevision, document)` 使用宿主 global 资源 ACL；只有工作区权限的访客不能读取全局库。`authorizeSelection(agentId)` 同时要求会话 lookup 和全局访问通过。Agent 工具权限沿用宿主执行器的 scoped `tools.guard`：共享访客回合和共享 fork 不将 `glossary_search` 视为安全 passthrough。宿主必须保留 liveshare 的来源回合限制及恢复时重装的执行限制；`remoteAccess.allows()` 在非 Remote 执行中不代表调用者是 owner。

## 构建与交付

需要 Node >=24.9、相邻 `../../hi-buddy` checkout，以及已安装依赖并构建的宿主包。开发依赖使用真实宿主 `file:` 链接；不把同名公共 npm 包当作内部版本。

```sh
cd hi-buddy-glossary-kit
npm ci
npm run build
npm test
npm pack
```

产物为 `hi-buddy-glossary-kit-0.3.0-rc.1.tgz`，无需用户机器存在相邻源码。构建用宿主 Typert 的 `WorkspaceAnalyzer` / `FaceModelEmitter` 生成 Host 描述符和 Client Remote 贡献；由于分析器按 workspace 判定类型归属，脚本在忽略的 `build/typert` 中复制 kit 及四个公共协议／类型拥有方源码，只分析并输出 kit。不会改写宿主，不手写 RPC 或放宽类型检查。

兼容门槛为 `>=0.2.2-rc.1 <0.2.2-rc.2`，保留对 `0.2.2-rc.1.YYYYMMDD.index` 等内部宿主后缀的支持。**版本范围只是初筛**，目标构建还必须具备下节能力；不能把尚未包含新插槽的旧 rc.1 当作已经兼容。

本轮只构建，没有发布或安装。后续安装请使用目标 hi-buddy 自己的 CLI 和明确的测试 profile，例如在已准备好的宿主源码目录执行：

```sh
pnpm dsh plugin --profile glossary-test add /绝对路径/hi-buddy-glossary-kit-0.3.0-rc.1.tgz
pnpm dsh --profile glossary-test
```

命令依据宿主 `docs/user/develop/basic/publish.zh.md`；不要使用未核实的全局 dsh，也不要把示例 profile 换成正在使用的 desktop profile 进行试验。

## 所需宿主能力

- `storageDomain` 与已配置的本地持久化后端。
- Agent 生命周期与作用域工具／系统提示注册表，Typert Agent lookup、Gateway、RemoteAccess、Host 元数据加载及 Client Remote `$mount`。
- `@deepseek-ai/dsh-message-quotes/client` 声明并实际注册的 list/session 插槽 `conversation.chat.text-interaction.quote.actions`，包括 `sessionId`、`readText`、`clearSelection`、`dismiss`、`actionClassName`。
- `ctx.layout.selectPanel`、main/sidebar/overlay 插槽，以及共享 primitives/theme/locale。

客户端用 type-only 导入声明，并在 `dsh.client.inject` 声明提供方依赖。新增按钮沿用宿主 actionClassName 和 pointerdown 保留选区行为；没有新增 selection interaction、替换 quote 面板、DOM 注入或全局事件桥接。

## 参考结构与验证

| 位置 | 职责 |
| --- | --- |
| `src/index.ts` | 宿主服务、权限边界、Agent 工具与提示生命周期 |
| `src/host/repository.ts` | 存储域、校验、串行写入与 revision 检查 |
| `src/host/search.ts` | 独立查询接口与关键词实现，未来索引可替换 |
| `src/types.ts`、`src/model.ts` | v2 数据契约与导入校验 |
| `src/client/index.tsx` | Remote 挂载、槽位、会话选词导航及生命周期 |
| `src/client/source.ts` | 宿主快照与未保存草稿请求，不使用浏览器数据库 |
| `src/client/Page.tsx`、`AddTermAction.tsx` | 框架派生 props，不接收业务服务或 ctx |
| `tests/` | 真实宿主服务组合、实际工具执行、槽位生命周期与边界测试 |

`npm run preview` 在 `127.0.0.1:4179` 启动隔离界面，使用真实宿主控件及临时 storageDomain。预览 HTTP 适配器只服务测试，不是生产通信方式。另一个终端执行 `npm run test:browser` 可检查 UI。构建、宿主组件组合、隔离浏览器和真实 desktop 验收是不同层次，具体结果与待验收项见 [VERIFICATION.md](VERIFICATION.md)。

本机链接开发中，修改宿主侧工具描述或系统提示后需要重新加载插件或重启当前 Web 宿主进程；仅刷新网页不会更新进程中已经加载的宿主模块。普通词条保存和启停无需重启。

## 共享 UI

页面容器、内容列与页头消费 [shared/ui/Page.module.css](../shared/ui/Page.module.css)，作用域样式通过 mountPluginStyles 安装；基础控件继续使用宿主 ui-primitives。构建使用 [共享 CSS Modules 编译器](../shared/build/css-modules.mjs)，需要完整仓库 checkout，最终包不依赖 shared 源码目录。编辑、导入和删除弹窗还消费 [Form.module.css](../shared/ui/Form.module.css)。

本轮共享提取的证据与边界见 [共享层验证](../shared/ui/VERIFICATION.md)。
