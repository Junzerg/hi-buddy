# 0.3.0-rc.1 验证记录

日期：2026-11-06。本轮仅修改 kit；没有发布、安装或重启实际宿主。

## 已通过

- 构建：真实宿主类型、Typert 生成、客户端类型检查与 bundle。
- 10 项自动测试：JSON storageDomain 重启、并发 revision 冲突、真实写入失败；旧工作区一次性合并、定义／启停冲突保留、原记录保留、默认项删除后重启不补回；Agent-scoped 工具和提示、启停过滤、无工作区 Agent 实际调用；global Remote 拒绝仅有 workspace grant 的 guest；选词授权和草稿、同名处理、真实 SlotRegistry 与卸载清理。
- 执行权限：真实宿主 `installSourceSessionAccess` guard 经真实模型工具执行器拒绝 confined 回合的 `glossary_search`，owner 回合正常。`forkToolDecision` 默认拒绝仅为单函数验证，不代表共享 fork 创建／恢复完整链路验收。
- 隔离浏览器：无工作区选择器的全局页面、CRUD、刷新持久化、左侧启停立即保存及失败恢复、编辑草稿不被启停提交、并发冲突、搜索、JSON 导入导出及失败反馈、弹窗 Esc／焦点、深浅色与窄窗口。

## 本轮接口与数据

入口 key/sidebar id 保持 `project-glossary`，显示名称为「海消术语表」。Remote 改为 `read()`、`write(expectedRevision, document)`、`authorizeSelection(agentId)`。移除 workspace 服务依赖。数据仍使用 schemaVersion 2，允许同名不同内容，由 ID 标识词条。storageDomain 的 `profile/global` 文档存在即表示初始化完成；旧 `workspaces` 表只读保留。

默认项仅首次加入：够花、海智伙伴；已有同名用户词条优先。去重仅针对同名、同定义、同启停状态，合并别名／标签，不同分类保留为标签；启停冲突保留两条。重启不重复迁移或补回默认项。

## 待宿主侧联调

实际 Web 中无工作区选词、跨工作区共用、既有本地数据迁移、默认项删除后重启、共享访客来源准入与共享 fork 恢复链路。隔离测试不能替代这组真实宿主验收。

以下为历史 0.2.2 记录；其中工作区隔离行为已被本轮全局语义取代。

---

# 0.2.2 验证记录

日期：2026-11-06。Node `v24.22.2`。宿主 HEAD：`6b71eb33d929d2e8f3d50fdabfde2bcb6b8f6a86`；宿主工作树有并行未提交修改，包括 message-quotes 新插槽及 sidebar，不能以 HEAD 单独重现全部能力。kit 初次交付后，宿主侧完成了本地 tarball 的完整 Web 联调，并修复 kit 的 Remote 命名空间依赖声明。未发布包或安装 desktop profile。

## 已核查的真实接口

- `packages/storage/storage-domain`、`storage/storage-json`：域持久化、per-record 布局、不可变快照、失败拒绝和生命周期。合法域名使用下划线：`hi_buddy_glossary`。
- `packages/workspace/workspace`：稳定 ID 与 header 验证后的 sessionIds；不通过 cwd 或页面当前工作区猜归属。
- `packages/core/agent`、`core/tools`、`core/system-prompt`：已有及新 Agent 的作用域工具和提示，原生执行器调用，随卸载撤销。
- `packages/typert/{protocol,generator,registry}`、`packages/api/{gateway,remote-access}`：真实 Remote 装饰器、Agent lookup、资源 ACL、生成的 wire schema 和注册贡献。
- `packages/session/message-quotes/src/client/index.ts` 及已构建 client/types：用户约定的新 list/session 插槽已落地。kit 使用 type-only 声明、提供方依赖及 slots.inject/register；不注册竞争交互。
- 复用宿主 Button/Input/Menu/Modal/Switch/Toast、主题与 CSS Modules；引用按钮消费宿主 actionClassName。未引入另一套视觉规范。

## 检查结果

| 层次 | 实际检查 |
| --- | --- |
| 构建 | Host/Client 严格 TypeScript、官方 Typert 协议生成、双端打包 |
| 持久化 | 真实 Cordis Storage + JSON backend + storageDomain，临时目录重开读取、工作区隔离、两个同 revision 写入只成功一个、拒绝写入不改变 revision；真实文件系统写入失败不发布新快照，移除测试障碍后可重试 |
| 服务集成 | 真实 AgentLoop、AgentRegistry、WorkspaceRegistry、SessionPersistence、SystemPrompt、Tools、Native executor、Typert Registry/Gateway/RemoteAccess 与构建后的 kit 组合；通过 Gateway 保存后 Agent 工具读取；无页面也可查询；停用后结果排除；无工作区会话失败 |
| 权限 | 非 owner Peer 仅能读取获准工作区；其他工作区读取和未授权会话解析被拒绝；工具参数不含 workspaceId |
| 生命周期 | 卸载后实际作用域工具及提示消失，重载后保留数据；真实 SlotRegistry 与已构建 quote 插件能发现迟到的 kit action，重建父槽不重复，卸载移除 action 和 kit 样式 |
| 行为单测 | v2 严格格式／大小／重复校验，停用过滤、UTF-8 输出上限、过期异步读取保护；构建后的选词按钮重新读文本、保留选区、捕获会话、无效选区不创建、同名定位、无工作区不回退、未保存不写入 |
| 浏览器 | Chromium 隔离预览：CRUD、启停开关立即保存／写入失败恢复／不提交其他未保存字段、刷新读取、分类搜索／无结果、复制、JSON 导出与替换确认／错误、并发冲突后草稿保留／重读再保存、删除取消／确认、Esc 焦点恢复、深浅色及 390px 无横向溢出 |
| 包检查 | 本地 tarball 内容检查；无 node_modules、测试／预览源、AGENTS.md 或宿主源码。未发布 |

`npm test` 共 9 个测试通过。宿主服务集成在真实 Cordis Context 内加载实际包，不连接 LLM 供应商；调用的是宿主原生工具执行器，并非仅直接调用检索函数。槽位测试使用真实 SlotRegistry 与 quote 插件，周边会话／工作区／导航服务是测试夹具，不渲染真实聊天引用浮层。选词行为测试的 Remote 返回值是夹具；权限和数据共享另由真实 Gateway 组合覆盖。

浏览器测试为 Page + 真实 primitives/theme + 临时持久化适配器，不是完整宿主。机器缺少默认浏览器动态库，执行时复用已有 `LD_LIBRARY_PATH=/tmp/haier-browser-libs/extracted/usr/lib/x86_64-linux-gnu`，未安装或修改系统库。截图与 JSON 在忽略的 `dist/verification/`，不冒充宿主截图。

## 完整 Web 宿主联调

使用重新构建的 `hi-buddy-glossary-kit-0.2.0.tgz` 安装到新建临时目录，由真实 Web scaffold 加载，Chromium 验收测试 1 个通过。验证了聊天选词时引用与添加术语按钮共存、选词预填且定义为空、保存后真实 Agent 原生工具执行器读取、同名定位已有词条、切换工作区隔离、停用后工具排除该词条，以及浏览器刷新后仍能读取。没有调用真实 LLM 供应商。

联调发现 kit 挂载 Remote 命名空间后未声明消费者依赖，实际点击会报 `cannot get property "remote.projectGlossary" without inject`。修复为 `$mount` 后在 `ctx.inject(['remote.projectGlossary'], mountClient)` 子作用域注册消费者，并通过真实 Cordis 槽位回调回归测试覆盖。修复后重新构建，9 个 kit 测试通过；全宿主测试使用新 tarball 的原始安装内容。

测试源码与实际宿主截图留在忽略的 `dist/verification/host/`。390px 自动检查确认没有横向溢出，但截图显示宿主侧栏展开时正文过窄，因此不将其视为移动端布局验收通过。

## 尚未完成的验收

未安装目标 desktop profile，也未验证真实桌面重启、完整侧栏安全区及多插件共存。窄屏侧栏展开时的布局仍需单独处理。Web 联调在独立临时 profile 内完成，没有操作用户现有 profile 数据。

协议生成器在外部包环境不能直接按 npm 类型完整分析 Remote Agent lookup。kit 使用公开 WorkspaceAnalyzer/FaceModelEmitter，在自己的忽略构建目录复制四个公共协议／类型拥有方源码后仅分析 kit，已生成可调用的真实协议；没有修改宿主、手工伪造接口或关闭诊断。更轻量的第三方插件生成入口可由宿主后续提供，不阻塞本轮构建。

旧 IndexedDB、旧导入和多表格式无迁移／兼容。本轮没有读取或删除用户现有数据文件；测试写入均在新建临时目录内。

## 0.2.1 查询指引修正

本机 Web 的实际会话记录表明 `glossary_search` 已进入模型工具声明，查询指引也已进入系统消息，但模型未调用工具便回答不知道。原指引只强调专有名词和缩写，未明确覆盖日常昵称。本次同时扩展系统提示、工具描述与 query 参数说明，要求对昵称、内部称呼及新增知识的追问先查询，并区分术语定义与实时事实。

已验证构建后的工具描述与系统提示包含新指引；未以真实模型再次提问验收，因此不宣称提示能保证每次调用。运行中的 Web 宿主仍需重新加载插件或重启进程后，才能使用本次宿主代码。

## 0.2.2 页面与使用流程调整

以宿主 TaskManagerPage 与 PluginManagerPage 的 960px 内容列、20/28/500 标题、紧凑圆角列表行为为依据：工作区合并到页头，去掉常驻的第二个术语表标题、版本／来源说明；低频操作收进已有 Menu。默认自动读取第一个工作区，后续列表变化不覆盖手动选择。桌面端保持固定左右分栏与分隔线，无选择时右侧留空；每条分类下方直接提供即时保存的 Switch，详情不再重复展示启用控件。详情动作移到顶部，隐藏空的别名和标签字段。

自动初选及保留手动选择在构建产物测试中覆盖；隔离浏览器覆盖列表开关即时持久化、编辑开关失败恢复、导入替换、复制／删除、搜索与窄窗口。无真实数据自动写入。进入本机 3080 的独立浏览器上下文遇到宿主授权要求，未绕过授权；本次截图来自 4179 隔离预览，真实宿主视觉验收仍待用户确认。
