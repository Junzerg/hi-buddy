import type { SearchResult } from '../types.ts';
import type { GlossaryReader } from './repository.ts';
/** Replaceable query implementation. The durable document remains the source of truth. */
export interface GlossarySearch {
    search(query: string, limit?: number): SearchResult;
}
export declare class KeywordSearch implements GlossarySearch {
    private reader;
    constructor(reader: GlossaryReader);
    search(query: string, limit?: number): SearchResult;
}
