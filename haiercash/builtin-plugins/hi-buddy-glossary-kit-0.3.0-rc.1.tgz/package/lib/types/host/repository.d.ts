import { type Domain, type KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { Document, RecordSnapshot } from '../types.ts';
export declare const glossaryDomain: {
    name: string;
    version: number;
    layout: "per-record";
    tables: {
        workspaces: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, RecordSnapshot>;
        profile: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, RecordSnapshot>;
    };
};
export interface GlossaryReader {
    read(): RecordSnapshot;
}
/** Host storage-domain owns durable files and locking. One service serializes revision checks with writes. */
export declare class Repository implements GlossaryReader {
    private table;
    private tail;
    private closed;
    constructor(table: KvTable<string, RecordSnapshot>);
    initialize(legacy: KvTable<string, RecordSnapshot>): Promise<void>;
    read(): RecordSnapshot;
    write(expected: number, document: Document, authorize: () => void): Promise<RecordSnapshot>;
    close(domain: Domain<typeof glossaryDomain>): Promise<void>;
}
