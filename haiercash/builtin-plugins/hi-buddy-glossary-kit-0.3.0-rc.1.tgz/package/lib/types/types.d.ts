/** v2 is deliberately incompatible with the unpublished browser-only v1. */
export interface Term {
    id: string;
    glossaryId: string;
    name: string;
    aliases: string[];
    definition: string;
    category: string;
    tags: string[];
    enabled: boolean;
}
export interface Glossary {
    id: string;
    name: string;
    description: string;
    version: string;
    source: {
        kind: 'local' | 'market';
        marketId: string | null;
    };
}
export interface Document {
    schemaVersion: 2;
    glossary: Glossary;
    terms: Term[];
}
export interface RecordSnapshot {
    revision: number;
    document: Document;
}
export type ErrorCode = 'format' | 'size' | 'duplicate' | 'conflict' | 'storage' | 'missing' | 'denied';
export type WriteResult = {
    ok: true;
    value: RecordSnapshot;
} | {
    ok: false;
    code: ErrorCode;
    path: string;
};
export interface SearchResult {
    matches: {
        name: string;
        aliases: string[];
        definition: string;
        category: string;
        tags: string[];
    }[];
    truncated: boolean;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        'glossary/denied': {};
    }
}
