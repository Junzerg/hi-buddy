import type { Document, Term, ErrorCode } from './types.ts';
export type { Document, Glossary, Term } from './types.ts';
export declare const MAX_BYTES: number;
export declare class GlossaryError extends Error {
    code: ErrorCode;
    path: string;
    constructor(code: ErrorCode, path?: string);
}
export declare function validateDocument(value: unknown): Document;
export declare function parseDocument(json: string): Document;
export declare function filterTerms(terms: Term[], query: string, category: string | null): Term[];
export declare function splitLabels(value: string): string[];
export declare function emptyDocument(scopeId: string): Document;
