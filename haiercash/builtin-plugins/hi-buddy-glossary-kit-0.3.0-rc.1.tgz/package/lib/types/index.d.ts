/** Host companion: one authoritative glossary service and Agent-scoped read-only tools. */
import { Context, Service } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { Document, RecordSnapshot, WriteResult } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        projectGlossary: ProjectGlossaryService;
    }
}
export declare class ProjectGlossaryService extends TypertRemoteService {
    static inject: string[];
    private repository;
    private searcher;
    private readonly agentFibers;
    constructor(ctx: Context);
    protected [Service.init](): Promise<void>;
    private authorize;
    private authorizeAgent;
    read(): RecordSnapshot;
    /** Agent lookup enforces session access; global access is also required. */
    authorizeSelection(agent: Agent): boolean;
    write(expectedRevision: number, document: Document): Promise<WriteResult>;
}
export declare function apply(ctx: Context): Promise<void>;
