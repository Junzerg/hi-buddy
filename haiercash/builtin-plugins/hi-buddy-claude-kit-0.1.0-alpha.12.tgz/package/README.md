# hi-buddy Claude

在 hi-buddy 侧边栏打开 **Claude**，选择本机项目，再从中间栏顶部选择或新建会话。插件使用原生 Claude Code 会话 ID。在终端继续同一会话后，点击页面的「刷新」即可读取新增内容。

左侧是可搜索的项目选择器和当前项目的会话列表。用「新建项目」选择一个现有目录。中间保留当前会话和输入框，会话标题栏可打开「文件」「改动」和「会话详情」。宽度足够时，会话详情紧靠聊天，可和右侧工具面板同时显示。窄窗口从标题栏的 `…` 打开工具，文件或改动显示在聊天下方。

文件树支持查找、定位、刷新、全部收起以及新建文件或文件夹。点文件树、聊天里的文件路径或 Diff 的「查看文件」，可打开只读预览。带行号的路径会定位并高亮对应行。

「改动」展示 Git 工作区相对 HEAD 的未提交差异，包含用户或其他工具的修改。未提交初始版本的仓库分别显示暂存和未暂存差异。改动在任务结束后自动刷新，也可手动刷新。可对文件或某段改动填写反馈，反馈加入聊天草稿，发送前可以编辑。

在输入框开头输入 `/` 查看命令，继续输入可筛选。用方向键和 Enter 或点击选中命令，填写参数后发送。首版支持 `/context` 查看上下文用量，以及 `/compact [说明]` 压缩当前会话并指定保留重点。最近一次命令的结果显示在当前会话里，保留到下一次发送或 Host 重启。

## 使用条件

- hi-buddy / DSH 0.2.2-rc.1，Node.js 24.9 或更新版本。
- 查看工作区差异需要本机 Git。
- 安装插件时保留 npm 可选依赖，以便 Agent SDK 安装对应平台的运行时。
- 在 hi-buddy 的「设置 → 模型」配置明确使用 Anthropic Messages 协议的模型和认证。插件使用所选路由的原始模型 ID 和地址，认证由 DSH Host 提供。

在目标 profile 的插件管理器安装本地 `.tgz` 并启用。使用 DSH CLI 管理 Web profile 时，执行以下命令。

```sh
dsh plugin --profile web add /absolute/path/hi-buddy-claude-kit-0.1.0-alpha.12.tgz
```

发送消息时由 Agent SDK 启动配套的 Claude Code 运行时。缺少平台依赖时，会话会提示重新安装插件。[Agent SDK 安装说明](https://code.claude.com/docs/en/agent-sdk/typescript#installation)

## 会话和权限

项目来自 Claude Code 会话的工作目录和通过目录选择器添加的目录。会话数据来自 Host 用户的 Claude Code 配置目录，默认为 `~/.claude`，也支持 Host 启动时设置的 `CLAUDE_CONFIG_DIR`。页面展示最近 200 条可呈现记录，文本总量上限为 1 MB。

终端若已安装兼容的 Claude Code，可以在插件的会话菜单中点「复制终端续聊命令」，再用同一账号和配置目录，在同一项目目录运行 `claude --resume <会话ID>`。程序化会话可能被终端的会话选择器过滤。主会话保存对话及工具记录，子 agent 的记录保存在父会话下。正在运行的命令和待处理审批归发起它们的进程管理。[会话存储](https://code.claude.com/docs/en/agent-sdk/sessions) · [子 agent 记录](https://code.claude.com/docs/en/sub-agents)

Claude Code 运行工具并写入原生会话。插件转发 Claude 请求的工具审批和问题，使用默认权限模式。执行时关闭用户、项目和本地设置来源，组织托管策略仍可能生效。离开页面后，正在执行的任务会继续。停止任务会关闭插件管理的进程。

同一 Host 在一个工作目录内一次运行一项任务。请在一边结束本轮执行后再切换到另一边继续同一会话。插件的 DSH 存储记录已添加的目录、任务状态和请求去重信息，消息历史由 Claude Code 管理。

## 构建和验证

构建需要相邻的 hi-buddy 源码及其已构建的开发依赖。安装包自带生成的 Host、Client 和 Remote 产物。

```sh
pnpm install --frozen-lockfile
pnpm dev:link-host
pnpm build
pnpm test
pnpm typecheck
pnpm test:loader
pnpm test:browser
pnpm pack --pack-destination dist
```

外网模型集成测试需要一个已保存的 Web profile 和明确的 Anthropic Messages 路由。测试使用临时项目和原生会话。最后一个参数仅供测试用来验证外部终端续聊。

```sh
pnpm test:live /absolute/dsh-home provider-id /absolute/path/to/claude
```

参见 [工作区截图](verification/workspace-files-light.png)、[验证记录](VERIFICATION.md)、[宿主右栏接入调查](RIGHTBAR.md) 和 [第三方依赖声明](THIRD-PARTY-NOTICES.md)。
