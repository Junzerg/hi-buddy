import type { SpawnedProcess, SpawnOptions } from '@anthropic-ai/claude-agent-sdk';
import type { Context } from '@deepseek-ai/cordis';
/** One task owns its process ranges; cleanup never enumerates or kills unrelated Claude processes. */
export declare class ClaudeProcessOwner {
    private readonly subprocess;
    private readonly handles;
    private closing?;
    constructor(subprocess: Context['subprocess']);
    readonly spawn: (options: SpawnOptions) => SpawnedProcess;
    close(): Promise<void>;
}
