import type { SDKAssistantMessageError } from '@anthropic-ai/claude-agent-sdk';
export declare class ClaudeProtocolError extends Error {
}
export declare class ClaudeResultError extends Error {
    readonly status: number | null | undefined;
    readonly assistantError?: SDKAssistantMessageError | undefined;
    constructor(message: string, status: number | null | undefined, assistantError?: SDKAssistantMessageError | undefined);
}
export declare function taskFailure(error: unknown): string;
