import type { ModelExecutionConfig } from './model-source.ts';
/** Only execution essentials and explicitly selected model authentication reach Claude. */
export declare function claudeRuntimeEnvironment(parent: NodeJS.ProcessEnv, configDirectory: string): NodeJS.ProcessEnv;
export declare function claudeEnvironment(parent: NodeJS.ProcessEnv, model: ModelExecutionConfig, configDirectory: string): NodeJS.ProcessEnv;
/** Subprocess applies overlays to a scrubbed parent; tombstone every unselected ambient key. */
export declare function exactEnvironment(parent: NodeJS.ProcessEnv, selected: NodeJS.ProcessEnv): NodeJS.ProcessEnv;
