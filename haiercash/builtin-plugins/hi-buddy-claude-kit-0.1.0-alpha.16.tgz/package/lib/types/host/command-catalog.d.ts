import type { Context } from '@deepseek-ai/cordis';
import type { CommandChoice } from '../types.ts';
export declare function commandCatalog(ctx: Context, cwd: string, configDirectory: string, signal: AbortSignal): Promise<CommandChoice[]>;
