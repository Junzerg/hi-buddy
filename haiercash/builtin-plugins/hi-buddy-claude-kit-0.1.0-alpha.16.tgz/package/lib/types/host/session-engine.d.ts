import { Interactions, type InteractionAnswer } from './interactions.ts';
import type { StoredSession, SessionSnapshot, SessionState, TranscriptEntry, ModelSelection } from '../types.ts';
export interface SessionPersistence {
    list(): StoredSession[];
    save(session: StoredSession): Promise<void>;
}
export interface TaskExecution {
    signal: AbortSignal;
    session: StoredSession;
    text: string;
    model: ModelSelection;
    nativeSession(): Promise<void>;
    append(message: TranscriptEntry): Promise<void>;
    reportRuntime(runtime: Partial<Pick<SessionState, 'commandOutput' | 'commandOutcome' | 'mcpServers'>>): Promise<void>;
    ask: Interactions['ask'];
}
export type TaskRunner = (task: TaskExecution) => Promise<void>;
/** Single Host admission owner. Client subscriptions do not own tasks or approvals. */
export declare class SessionEngine {
    private readonly persistence;
    private readonly run;
    private readonly history?;
    private readonly sessions;
    private readonly tasks;
    private readonly directories;
    private readonly listeners;
    private readonly epoch;
    private sequence;
    private closed;
    constructor(persistence: SessionPersistence, run: TaskRunner, history?: ((session: StoredSession) => Promise<TranscriptEntry[]>) | undefined);
    initialize(): Promise<void>;
    has(id: string): boolean;
    snapshot(id: string): SessionSnapshot;
    bind(id: string, cwd: string, existing: boolean): void;
    open(id: string): Promise<SessionSnapshot>;
    private notify;
    private commit;
    private publish;
    send(id: string, requestId: string, text: string, model: ModelSelection): Promise<string>;
    private finishedHistory;
    answer(id: string, taskId: string, approvalId: string, answer: InteractionAnswer): boolean;
    cancel(id: string): void;
    subscribe(id: string, signal: AbortSignal): AsyncGenerator<SessionSnapshot>;
    settled(id: string): Promise<void>;
    close(): Promise<void>;
}
