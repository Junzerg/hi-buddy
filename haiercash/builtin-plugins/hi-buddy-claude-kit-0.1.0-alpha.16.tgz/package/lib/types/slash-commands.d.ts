export declare const slashCommands: readonly ["context", "compact"];
export type SlashCommand = typeof slashCommands[number];
export declare function slashCommandOf(text: string): SlashCommand | undefined;
export declare function isModelCommand(text: string): boolean;
