import { Context, Service } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { CommandChoice, NativeProject, NativeSession, SessionSnapshot, WorktreeChanges, FileDiff, ProjectFile, ProjectFileList, ProjectFilePreview } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        hiBuddyClaude: HiBuddyClaude;
    }
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        'hi-buddy-claude/denied': {};
        'hi-buddy-claude/unavailable': {};
    }
}
export default class HiBuddyClaude extends TypertRemoteService {
    static inject: string[];
    private domain;
    private engine;
    private models;
    private nativeRoot;
    private catalogAbort;
    private catalogs;
    private stopping;
    constructor(ctx: Context);
    protected [Service.init](): Promise<void>;
    private authorize;
    modelChoices(): Promise<{
        models: {
            provider: string;
            model: string;
            name: string;
            providerName: string;
        }[];
        problems: {
            provider: string;
            code: string;
        }[];
    }>;
    commands(cwd: string): Promise<CommandChoice[]>;
    projects(): Promise<NativeProject[]>;
    addProject(cwd: string): Promise<NativeProject>;
    files(cwd: string, path: string): Promise<ProjectFileList>;
    searchFiles(cwd: string, pattern: string, signal: AbortSignal): Promise<ProjectFileList>;
    createEntry(cwd: string, parent: string, name: string, folder: boolean): Promise<ProjectFile>;
    previewFile(cwd: string, path: string): Promise<ProjectFilePreview>;
    sessions(cwd: string): Promise<NativeSession[]>;
    changes(cwd: string): Promise<WorktreeChanges>;
    diff(cwd: string, path: string): Promise<FileDiff>;
    open(cwd: string, id: string): Promise<SessionSnapshot>;
    create(cwd: string): Promise<SessionSnapshot>;
    private directory;
    send(id: string, requestId: string, text: string, provider: string, model: string): Promise<string>;
    answer(id: string, taskId: string, approvalId: string, allow: boolean, answers: {
        question: string;
        answer: string;
    }[]): boolean;
    cancel(id: string): void;
    watch(id: string, signal: AbortSignal): AsyncIterable<SessionSnapshot>;
}
