import { type Options } from '@anthropic-ai/claude-agent-sdk';
import type { WebRuntime } from '@deepseek-ai/dsh-web';
export declare function hostSearch(web: WebRuntime, turnSignal: AbortSignal): Pick<Options, 'mcpServers' | 'toolAliases' | 'disallowedTools'>;
