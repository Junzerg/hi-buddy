import type { SDKUserMessage } from '@anthropic-ai/claude-agent-sdk';
export declare class FollowUpInput {
    private readonly unread;
    private readonly ready;
    private admissions;
    private resultSeen;
    private closed;
    private wake?;
    get accepting(): boolean;
    get hasUnread(): boolean;
    reserve(): boolean;
    settleAdmission(message?: SDKUserMessage): void;
    read(uuid: string): boolean;
    rejectNext(): void;
    finishResponse(): void;
    close(): void;
    private closeIfFinished;
    messages(first: SDKUserMessage): AsyncGenerator<SDKUserMessage>;
}
