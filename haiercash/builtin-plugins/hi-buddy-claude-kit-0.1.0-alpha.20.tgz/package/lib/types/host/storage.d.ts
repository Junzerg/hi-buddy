import { type StoredSession } from '../types.ts';
export type RunRecord = Omit<StoredSession, 'messages' | 'commandName' | 'commandOutput' | 'commandOutcome' | 'commandEntryId' | 'mcpServers' | 'activity'>;
export declare const claudeDomain: {
    name: string;
    version: number;
    layout: "per-record";
    tables: {
        runs: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, RunRecord>;
        projects: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            cwd: string;
            name: string;
        }>;
    };
};
