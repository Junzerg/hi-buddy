import type { SDKMessage } from '@anthropic-ai/claude-agent-sdk';
import type { PermissionMode, TurnActivity } from '../types.ts';
/** SDK progress belongs to one process. Native transcript records remain the source for history. */
export declare class SdkActivity {
    private readonly redact;
    private permissionMode;
    private phase;
    private readonly tools;
    private readonly tasks;
    private readonly hiddenTasks;
    private readonly notices;
    constructor(redact: (text: string) => string, permissionMode: PermissionMode);
    private text;
    private notice;
    private tool;
    private task;
    observe(message: SDKMessage): TurnActivity | undefined;
}
