import type { SDKAssistantMessageError, TerminalReason } from '@anthropic-ai/claude-agent-sdk';
export declare class ClaudeProtocolError extends Error {
}
export declare class ClaudeResultError extends Error {
    readonly status: number | null | undefined;
    readonly assistantError?: SDKAssistantMessageError | undefined;
    readonly reason?: TerminalReason | undefined;
    constructor(message: string, status: number | null | undefined, assistantError?: SDKAssistantMessageError | undefined, reason?: TerminalReason | undefined);
}
export declare function taskFailure(error: unknown): string;
