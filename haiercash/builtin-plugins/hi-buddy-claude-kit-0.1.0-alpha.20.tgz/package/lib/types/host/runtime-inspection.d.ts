import { type Options, type Query } from '@anthropic-ai/claude-agent-sdk';
import type { Context } from '@deepseek-ai/cordis';
export declare function inspectRuntime<T>(ctx: Context, options: Options, signal: AbortSignal, timeout: number, read: (execution: Query) => Promise<T>): Promise<T>;
