export declare const permissionModes: readonly ["default", "acceptEdits", "plan", "dontAsk", "auto", "bypassPermissions"];
export type PermissionMode = typeof permissionModes[number];
export declare const effortLevels: readonly ["low", "medium", "high", "xhigh", "max"];
export type EffortLevel = typeof effortLevels[number];
export interface ContextUsage {
    totalTokens: number;
    maxTokens: number;
    percentage: number;
    categories: {
        name: string;
        tokens: number;
    }[];
}
export type SessionStatus = 'idle' | 'running' | 'waiting-for-input' | 'cancelling' | 'completed' | 'failed' | 'interrupted';
export type CommandOutcome = 'completed' | 'no-change' | 'unavailable' | 'failed' | 'interrupted';
export interface TranscriptCommand {
    name?: string;
    output?: string;
    outcome?: CommandOutcome;
    summary?: string;
}
export interface TranscriptEntry {
    id: string;
    kind: 'user' | 'assistant' | 'thinking' | 'tool' | 'tool-result' | 'notice' | 'command' | 'compaction';
    text: string;
    toolName?: string;
    toolUseId?: string;
    toolError?: boolean;
    command?: TranscriptCommand;
}
export interface NativeProject {
    cwd: string;
    name: string;
}
export interface NativeSession {
    id: string;
    title: string;
    updatedAt: number;
}
export interface ModelSelection {
    provider: string;
    model: string;
}
export type TurnPhase = {
    kind: 'starting' | 'requesting' | 'compacting' | 'authenticating';
} | {
    kind: 'thinking';
    tokens: number;
} | {
    kind: 'retrying';
    attempt: number;
    maximum: number;
    delayMs: number;
    status?: number;
};
export interface ToolProgress {
    id: string;
    name: string;
    seconds?: number;
    denied?: boolean;
    detail?: string;
}
export interface BackgroundTask {
    id: string;
    toolUseId?: string;
    description?: string;
    detail?: string;
    state: 'requested' | 'running' | 'paused' | 'completed' | 'failed' | 'interrupted' | 'unknown';
    retry?: Extract<TurnPhase, {
        kind: 'retrying';
    }>;
}
export interface TurnNotice {
    id: string;
    kind: 'notice' | 'warning' | 'fallback' | 'refusal' | 'rateLimit' | 'rateLimitWarning' | 'compactFailed' | 'hookFailed' | 'outputLimit' | 'paused' | 'toolDeferred' | 'filesFailed' | 'pluginFailed' | 'background' | 'permissionMode' | 'conversationReset' | 'mcpInputCompleted';
    detail?: string;
}
export interface TurnActivity {
    phase?: TurnPhase;
    tools: ToolProgress[];
    tasks: BackgroundTask[];
    notices: TurnNotice[];
}
export interface SessionState {
    id: string;
    cwd: string;
    status: SessionStatus;
    taskId?: string;
    error?: string;
    messages: TranscriptEntry[];
    permissionMode?: PermissionMode;
    activity?: TurnActivity;
    commandName?: string;
    commandOutput?: string;
    commandOutcome?: CommandOutcome;
    commandEntryId?: string;
    mcpServers?: {
        name: string;
        status: string;
    }[];
}
export interface CommandChoice {
    name: string;
    description: string;
    argumentHint: string;
}
export interface StoredSession extends SessionState {
    version: 1;
    existing: boolean;
    requests: {
        id: string;
        digest: string;
        taskId: string;
        followUpUuid?: string;
    }[];
    pendingPrompts?: {
        id: string;
        uuid: string;
        taskId: string;
        text: string;
    }[];
    commandResults?: {
        id: string;
        output?: string;
        outcome: CommandOutcome;
    }[];
}
export interface ApprovalView {
    id: string;
    taskId: string;
    toolUseId: string;
    toolName: string;
    inputJson: string;
}
export interface SessionSnapshot {
    epoch: string;
    sequence: number;
    session: SessionState;
    approvals: ApprovalView[];
    acceptsFollowUps?: boolean;
    followUps?: {
        id: string;
        text: string;
        waiting: boolean;
    }[];
}
export interface WorktreeFile {
    path: string;
    status: string;
}
export interface WorktreeChanges {
    available: boolean;
    files: WorktreeFile[];
    truncated: boolean;
}
export interface FileDiff {
    text: string;
    truncated: boolean;
    previewPath?: string;
}
export interface ProjectFile {
    path: string;
    name: string;
    kind: 'directory' | 'file' | 'other';
}
export interface ProjectFileList {
    files: ProjectFile[];
    truncated: boolean;
}
export interface ProjectFilePreview {
    path: string;
    text: string;
    binary: boolean;
    truncated: boolean;
}
