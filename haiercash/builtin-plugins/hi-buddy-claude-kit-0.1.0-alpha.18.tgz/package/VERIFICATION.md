# 验证记录

## 已验证

### 0.1.0-alpha.18 发版准备

2026-11-17 将本轮会话 Tab、右侧工作区、逐处反馈、按需刷新和侧栏图标调整汇总为 `0.1.0-alpha.18`。最终版本构建、真实 DSH Loader/Remote 检查和独立 Profile 的 Web 加载检查通过；本轮 36 项插件测试、2 项共享 UI 测试及完整隔离浏览器回归通过。Web 截图确认 Claude 的宿主 `IconCodeOutlineRegular` 与海消术语表的文件图标不同。SDK 仍为 0.3.218，未变更依赖或兼容范围。安装包为 `build/hi-buddy-claude-kit-0.1.0-alpha.18.tgz`，未发布远端；Desktop、Windows/macOS 本次交互待验收。

按需刷新收尾通过构建、类型检查、36 项单元测试和完整隔离浏览器回归。浏览器验证进入/离开改动工具的可见性通知及刷新后保留当前块；单元测试覆盖前方插入改动块后保持原内容定位和块删除后的有效序号。生产接入在当前订阅会话结束、项目读取和文件创建时按可见性决定是否查询 Git，隐藏后已发出的请求允许完成，不新增轮询。滚动保留逻辑已源码核查。真实临时 Profile Web 宿主验证当前 bundle 能加载、文件树/预览、工具切换及深浅色；未用真实模型新增自动刷新场景，Desktop 待验收。

逐处反馈调整通过构建和完整隔离浏览器回归。验证当前意见立即追加路径/行号至聊天草稿、反馈框清空且不能重复加入、下一处可继续填写、返回前一处不恢复旧意见，以及未加入的文字不跨改动保留。此行为替代此前多处意见汇总和快照方案。截图 `build/preview/per-change-feedback-light.png`。

2026-11-17，文件内多处改动与批量反馈通过类型检查、构建、35 项单元测试和完整隔离浏览器回归。标题区「改动 x / y」及箭头切换当前文件的 Diff 块，文件切换仍走列表；查看文件使用当前块行号。反馈支持整个文件及各处独立意见，切换改动保留填写内容，统一追加到当前会话草稿；单元测试覆盖多块、删除、新增及省略计数的行号。浏览器验证两处改动加整体意见合并、原草稿保留和输入焦点。截图 `build/preview/multi-change-feedback-light.png`。反馈期间保留打开时的 Diff 快照，若后台 Diff 更新则显示并附带版本提示；此更新分支已源码检查，未作真实并发文件写入验收。本轮未重新执行真实宿主/模型测试。

反馈入口按用户最终更正调整为顶部「查看文件」「反馈修改」，差异块下方不再显示评论按钮。构建和完整隔离浏览器回归通过，验证文件级反馈保留原草稿并追加当前文件路径及意见。

2026-11-17，改动面板层级调整通过类型检查、构建和隔离浏览器回归。范围说明改为可聚焦的信息提示，文件列表分为文件名与目录两行，当前文件标题/序号/切换箭头成组，查看文件与反馈使用 outline 按钮，逐段评论放到对应 Diff 下方。补充 48 个变更文件及长路径 fixture，检查正常宽度与 390px 深色窗口无页面横向溢出。新截图为 `build/preview/changes-hierarchy-light.png` 和 `changes-hierarchy-narrow-dark.png`。本次视觉调整使用真实宿主 primitives/theme 的隔离页面，未重新执行真实宿主或 Desktop 验收。

2026-11-17，`0.1.0-alpha.17` 右侧工作区第一阶段通过构建、类型检查、33 项插件测试及隔离 Chromium 回归。覆盖文件/改动/会话固定标签、键盘切换、收起后恢复预览与开关焦点、文件引用保留草稿且不串会话、Diff 上一个/下一个、反馈和审批定位；同时回归已有会话 Tab、项目、模型、命令、创建文件与问答流程，浏览器无 console error。浅色 1600px 和深色 390px 布局已检查。

真实 hi-buddy Web（`caed11856e2d7ef87f12086c0b017c9c04d1b3bb`）使用独立临时 Profile，核对实际提供的 bundle 等于本地构建产物，验证真实目录树、只读预览、会话工具切换、收起重开和深浅色背景。真实宿主未运行模型修改文件；Diff、审批与多会话引用使用 fixture 验证。截图在 `build/preview/rightbar-preview-light.png`、`rightbar-preview-narrow-dark.png`、`rightbar-host-preview-light.png`、`rightbar-host-narrow-dark.png`。宿主自身侧栏展开时会占用手机宽度，插件内部标签可横向滚动。Desktop、原生窗口焦点、外部文件变化监听和检查点回退未验收；后两项未在本阶段实现。

`0.1.0-alpha.17` 的右栏底色修正在 hi-buddy `caed11856e2d7ef87f12086c0b017c9c04d1b3bb` 的真实 Web 宿主验证。展开目录并打开文件后，比较浅色、深色的计算样式，右栏与聊天底色一致，代码预览为透明。隔离 Chromium 补充验证了行高亮和 390px 深色窗口。构建、类型检查及 33 项插件测试通过。预览见 `build/preview/rightbar-host-files-light.png`、`build/preview/rightbar-host-preview-light.png` 和 `build/preview/rightbar-preview-narrow-dark.png`。Desktop 窗口待验收。

`0.1.0-alpha.17` 的本地会话标签改动使用 Node 24.22.2 和 hi-buddy `caed11856e2d7ef87f12086c0b017c9c04d1b3bb` 验证。构建、类型检查、33 项插件测试、2 项共享 UI 测试和真实 DSH Loader 通过。隔离 Chromium 覆盖左侧会话搜索、标签键盘切换、草稿隔离、关闭后重新打开、项目切换清空标签及 390px 深色窗口溢出。项目菜单验证了「新建项目（开发中）」的禁用提示和「添加项目文件夹」目录流程。`npm run test:browser` 生成 `build/preview/session-tabs-light.png`、`build/preview/session-tabs-narrow-dark.png` 和 `build/preview/project-picker-development.png`。Desktop 窗口待验收。

真实 hi-buddy Web 使用独立临时 Profile 加载当前客户端 bundle，验证目录选择、登记已有文件夹、新建两个空会话、来回切换各自草稿以及关闭后返回相邻标签。截图位于 `build/preview/session-tabs-host-web.png`。本地安装包位于 `build/hi-buddy-claude-kit-0.1.0-alpha.17.tgz`。

`0.1.0-alpha.15` 修复 Desktop 启动 SDK 内置 Claude 的路径。使用 Linux x64 上的 Electron 44.7.0 RunAsNode 和实际 SDK 0.3.218、Claude Code 2.1.218 复现了旧路径问题。Electron 能读取 `app.asar` 内的路径，但启动子进程时返回 `ENOTDIR`。改用 `app.asar.unpacked` 后，SDK 完成初始化并成功执行 `/context`。测试环境的 PATH 无 `claude`。构建、类型检查、26 项自动化测试和真实 DSH Loader 测试通过。路径测试覆盖 Windows 带空格的路径、macOS 路径和独立安装路径。[Electron ASAR 执行限制](https://www.electronjs.org/docs/latest/tutorial/asar-archives#executing-binaries-inside-asar-archive)

Windows `0.2.2-rc.1.20261110.2` 内置 `alpha.14`。带 `alpha.15` 的 Windows 安装包仍需验证从该版本升级后新建会话。macOS 安装验证也待完成。

`0.1.0-alpha.14` 在 Ubuntu 24.04.5 x64、Node 24.22.2、DSH `0.2.2-rc.1` 和 hi-buddy `ae0a9064190f44048ebed09ca68d8dc624eda8dd` 上通过构建、类型检查和 25 项自动化测试。Chromium 验证了从 `/` 菜单选择、直接输入后按 Enter、提交按钮、Escape 焦点返回，以及有零个、一个和多个模型时的流程。

真实 DSH Loader 和内置 Claude Code 2.1.218 使用 Anthropic Messages fixture 验证，同一原生会话的下一轮请求使用新模型 ID，历史保留。直接把 `/model` 提交到 Host 的 `send` 会在任务发起前被拒绝。Desktop 窗口和公司网关待验收。[模型选择器截图](verification/model-command-light.png)

`0.1.0-alpha.13` 使用 Ubuntu 24.04.5 x64、Node 24.22.2、DSH `0.2.2-rc.1`、hi-buddy `f60f499f684cf3f966d46551d86578571aa70b51`、Agent SDK 0.3.218 和内置 Claude Code 2.1.218 验证。

| 验证 | 结果 |
| --- | --- |
| 会话呈现 | Chromium 使用宿主 `BrandLogo`、`UserMessageBubble`、`DisclosureRow` 和主题。验证工具参数和结果配对、思考可折叠、命令结果可展开，以及 390px 深色窗口 |
| 真实原生执行 | DSH Loader 与 Typert Remote 通过 Anthropic Messages fixture 接收原生流式思考。真实 Claude Code 执行 Read 并返回文件内容，结果按原生工具 ID 配对 |
| 命令 | 原生目录发现返回八项且不创建会话。`/context` 返回用量，`/compact` 分别验证未压缩、完成事件、续聊与重连。`/code-review` 确认传入的参数出现在 SDK 展开的 Skill 提示中 |
| 本机扩展边界 | 独立临时目录中，`settingSources: []` 不发现示例本机 Skill 和 MCP，启用 `user/project` 后发现该 Skill 并开始连接 MCP。插件本轮保留现有设置策略。MCP 状态 UI 验证使用浏览器 fixture |

[会话预览](verification/session-transcript-light.png) · [命令菜单](verification/slash-commands-light.png)

`0.1.0-alpha.12` 的斜杠命令在 Ubuntu 24.04.5 x64、Node 24.22.2、DSH `0.2.2-rc.1` 和 hi-buddy `63dc1aa9071f0476dac8e513ee8f54589ef68b83` 上验证。构建、类型检查和 25 项自动化测试通过。浏览器覆盖输入 `/`、筛选、方向键、Enter、Escape、点击、参数编辑、显式发送和 390px 窄屏。命令菜单复用宿主 `Menu` 和 `MenuItemButton`。

真实 Loader 与 Agent SDK 0.3.218 的内置 Claude Code 2.1.218 通过 Typert Remote 执行 `/context` 和 `/compact`。测试使用本地 Anthropic Messages fixture，覆盖空会话提示、已有会话带参数压缩、压缩后的原生续聊，以及结果在同一 Host 内重新打开和重连后保留。Gateway 的回复使用 fixture，内网模型实际压缩待验收。

[斜杠命令菜单](verification/slash-commands-light.png)

`0.1.0-alpha.11` 使用 Ubuntu 24.04.5 x64、Node 24.22.2、DSH `0.2.2-rc.1` 和 hi-buddy `7c0124e022001ff7c998f8a6550241f2e3152cec` 的 Loader、Client 组件与主题。构建、类型检查和 25 项自动化测试通过。

| 验证 | 结果 |
| --- | --- |
| 工作区布局 | Chromium 1600px 下会话详情和文件预览可同时打开。文件与 Diff 面板打开或展开时，聊天输入框保留。390px 深色窗口下，标题栏菜单打开下方工具区，长会话名仍为新建按钮留出空间 |
| 文件与改动 | 文件树搜索、定位、创建、刷新和收起通过。聊天文件链接和 Diff 均能跳转预览及行号。改动段反馈可带入现有草稿，焦点返回输入框 |
| 会话 | 左侧会话列表和标题栏选择器保持同步。会话详情可跳到实际审批。原生历史、发送、问答、拒绝和复制续聊命令通过页面 fixture 回归 |
| 真实 Loader 和 Typert Remote | 验证项目内绝对路径可预览，拒绝目录越界和指向外部的符号链接。嵌套项目的 Diff 返回正确的项目相对预览路径。禁用和重新启用后项目仍可读取 |
| 安装包 | 核对 SHA-256、入口、Remote、locale、bundle patch 和依赖引用。从独立目录安装 tarball 并加载，省略平台依赖时得到 SDK 运行时安装提示。PATH 中的测试用 CLI 未被执行 |

[宽屏文件预览](verification/workspace-files-light.png) · [工作台与差异](verification/native-session-light.png) · [窄屏深色](verification/native-session-mobile-dark.png) · [项目入口](verification/projects-light.png)

原生运行时集成验证使用 `0.1.0-alpha.9`。实测环境为 Ubuntu 24.04.5 x64、Node 24.22.2、Agent SDK 0.3.218 和内置 Claude Code 2.1.218。终端验证使用独立的 Claude Code 2.1.218。宿主为 DSH `0.2.2-rc.1`，hi-buddy HEAD 为 `b550cdb269d891badb05aa08fffbb25c39ca403a`。

| 验证 | 结果 |
| --- | --- |
| 安装包 | 从 `.tgz` 安装后由真实 Loader 启用。在独立目录用 `--no-optional` 安装后，发送时由 SDK 报告缺少运行时，会话显示安装提示 |
| 终端与内置运行时往返 | PATH 无 `claude` 时，插件通过内置运行时执行真实模型请求。终端创建的会话可在插件续聊，插件创建的会话可由终端用 `--resume <会话ID>` 续聊 |
| 子 agent 与终端列表 | 插件发起的子 agent 产生可读取的独立记录，终端续聊父会话可读到子 agent 结果。按终端会话选择器规则过滤程序化会话时，插件新建会话不出现在列表中 |
| 会话与任务 | 跨项目打开被拒绝。DSH 新建会话在首次发送后可通过 SDK 查询。原生问题可通过 Remote 回答，重复回答被拒绝。重启后的重复发送返回原任务 ID |

原生会话往返及原生问答的真实模型测试使用已保存的外网 Anthropic Messages 路由，以及临时 DSH profile、工作目录和 Claude 配置目录。终端步骤使用本机 CLI 的非交互模式。

## 未验证

页面截图和交互使用隔离浏览器和 fixture。真实 Desktop 窗口、Windows、macOS、其他终端版本和内网认证待验收。`alpha.13` 的思考和工具过程使用本地模型接口 fixture。本机扩展启用和 MCP 认证、调用待接入。工作区采用固定的并排布局与窄屏堆叠，文件预览只读。自由拖动停靠和面板独立窗口属于后续范围。

## 失败项

首次省略平台依赖的安装检查从源码目录启动，解析到了开发依赖里的 SDK 二进制，导致使用 fixture 地址的请求超时。切换到独立安装目录启动同一个 Loader 检查后通过。
