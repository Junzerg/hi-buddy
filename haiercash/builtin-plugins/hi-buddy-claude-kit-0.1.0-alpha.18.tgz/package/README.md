# hi-buddy Claude

在 hi-buddy 侧边栏打开 **Claude**，选择本机项目，再从中间栏顶部选择或新建会话。插件使用原生 Claude Code 会话 ID。在终端继续同一会话后，点击页面的「刷新」即可读取新增内容。

左侧是可搜索的项目选择器和当前项目的会话列表。用「添加项目文件夹」登记现有目录，「新建项目」在菜单中标记为开发中。中间标题栏显示已打开的会话，标签右侧的加号新建会话。切换标签会保留各自的草稿，关闭标签后可从左栏重新打开。标题栏的工作区开关打开右栏，固定「文件」「改动」「会话」三个工具标签。切换工具或收起右栏保留阅读位置；文件可复制路径、引用到当前会话草稿。改动展示整个 Git 工作区相对 HEAD 的变化，通过「改动 x / y」切换同文件的各处差异；每处反馈点击「加入输入框」即追加文件、行号范围和意见到聊天草稿，然后可切换下一处继续处理，不暂存多处意见。会话工具包含状态、审批定位、MCP 信息和终端续聊命令。改动面板可见时才在当前订阅会话回合结束后自动刷新，隐藏时等下次打开再读取；手动刷新保留，刷新尽量维持当前文件、改动块和阅读位置。窄窗口将工作区放到聊天下方。

文件树支持查找、定位、刷新、全部收起以及新建文件或文件夹。点文件树、聊天里的文件路径或 Diff 的「查看文件」，可打开只读预览。带行号的路径会定位并高亮对应行。

「改动」展示 Git 工作区相对 HEAD 的未提交差异，包含用户或其他工具的修改。未提交初始版本的仓库分别显示暂存和未暂存差异。改动面板可见时在当前订阅会话任务结束后自动刷新，也可手动刷新。可对文件或某段改动填写反馈，反馈加入聊天草稿，发送前可以编辑。

会话使用 hi-buddy 的头像、气泡和折叠行。Claude Code 返回思考文本时可展开查看。工具行用原生工具 ID 配对调用与结果，并显示请求、审批、完成或失败等已知状态。

在输入框开头输入 `/` 查看内置 Agent SDK 返回的命令，继续输入可筛选。用方向键和 Enter 或点击选中，填写参数后发送。`/compact` 压缩模型的续聊上下文，聊天区仍可查看原生日志中保留的压缩前消息。有原生摘要时可展开压缩状态行。重新打开会话时，可以查看原生历史中记录的命令及其结果。插件也保留最近 24 条由它启动、且仍有原生命令记录可关联的 `/context` 和 `/compact` 结果。

选择 `/model` 或直接输入 `/model` 后按 Enter，可以打开输入框下方的宿主模型选择器。选中后从下一轮使用新的模型，继续当前 Claude 原生会话。模型候选来自 DSH 的 Anthropic Messages 路由。没有可用模型时，页面提示在「设置 → 模型」配置并刷新。

在输入框下方打开模型菜单，再选 `effort` 查看 SDK 为当前模型报告的等级。选择后从下一次发送生效，`default` 使用模型默认值。切换模型或会话时恢复默认值。点右侧的上下文圆环可按当前模型读取原生会话的 token 明细，并直接执行 `/compact`，保留输入框草稿。圆环显示最近一次读取的用量，再次打开面板时刷新。

## 0.1.0-alpha.18

- 会话标签支持新增、关闭和独立草稿，项目菜单区分添加目录与开发中的新建项目。
- 右侧工作区统一文件、改动、会话工具，保留阅读状态并支持文件引用。
- 同文件多处改动可逐处切换；反馈立即携带文件和行号加入聊天草稿。
- 改动按面板可见性刷新，尽量保留当前阅读位置。
- Claude 侧栏使用宿主代码图标，与术语表的文件图标区分。

## 使用条件

- hi-buddy / DSH 0.2.2-rc.1，Node.js 24.9 或更新版本。
- 查看工作区差异需要本机 Git。
- 安装插件时保留 npm 可选依赖，以便 Agent SDK 安装对应平台的运行时。
- 在 hi-buddy 的「设置 → 模型」配置明确使用 Anthropic Messages 协议的模型和认证。插件使用所选路由的原始模型 ID 和地址，认证由 DSH Host 提供。

在目标 profile 的插件管理器安装本地 `.tgz` 并启用。使用 DSH CLI 管理 Web profile 时，执行以下命令。

```sh
dsh plugin --profile web add /absolute/path/hi-buddy-claude-kit-0.1.0-alpha.15.tgz
```

发送消息时由 Agent SDK 启动配套的 Claude Code 运行时。缺少平台依赖时，会话会提示重新安装插件。[Agent SDK 安装说明](https://code.claude.com/docs/en/agent-sdk/typescript#installation)

## 会话和权限

项目来自 Claude Code 会话的工作目录和通过目录选择器添加的目录。会话数据来自 Host 用户的 Claude Code 配置目录，默认为 `~/.claude`，也支持 Host 启动时设置的 `CLAUDE_CONFIG_DIR`。页面展示最近 200 条可呈现记录，文本总量上限为 1 MB。

终端若已安装兼容的 Claude Code，可以在插件的会话菜单中点「复制终端续聊命令」，再用同一账号和配置目录，在同一项目目录运行 `claude --resume <会话ID>`。程序化会话可能被终端的会话选择器过滤。主会话保存对话及工具记录，子 agent 的记录保存在父会话下。正在运行的命令和待处理审批归发起它们的进程管理。[会话存储](https://code.claude.com/docs/en/agent-sdk/sessions) · [子 agent 记录](https://code.claude.com/docs/en/sub-agents)

Claude Code 运行工具并写入原生会话。插件默认启用 SDK 的 `user` 和 `project` 设置来源，打包和启动均无需额外参数。SDK 从 Host 的 Claude 配置目录和会话项目目录加载 Skills，供 `/` 菜单与会话使用。对应的 `settings.json`、`CLAUDE.md` 和 hooks 也由 SDK 加载。模型路由、端点和鉴权由 hi-buddy Host 提供，SDK 采用原生的宿主管理路由模式。会话详情展示 Claude Code 最近启动时上报的 MCP 连接状态。[Agent SDK 设置来源](https://code.claude.com/docs/en/agent-sdk/claude-code-features#control-filesystem-settings-with-settingsources)

回复时，会话显示 SDK 上报的请求、重试、思考、压缩和工具进度。工具行标记审批与拒绝，后台任务在对应工具行或单独状态行展示。模型拒绝、限额、截断和 hook 失败等提示保留到下一次发送，原生历史由 Claude Code 保存。

网页搜索通过 Claude Agent SDK 的 MCP 工具调用宿主的 `ctx.web.search()`，采用当前 hi-buddy profile 配置的搜索供应商和凭据。搜索授权沿用会话的 SDK 权限模式。

离开页面后，正在执行的任务会继续。停止任务会关闭插件管理的进程。

在输入框下方选择权限模式，从本会话的下一次发送起生效。首次发送带有所选模式的消息时，插件会为该会话保存选择。菜单提供 SDK 的六种模式，工具审批由 SDK 决定，插件转发 SDK 请求的审批和问题。`auto` 的实际可用性取决于 Claude Code 运行时和所选模型。[Agent SDK 权限模式](https://code.claude.com/docs/en/agent-sdk/permissions#permission-modes)

未为会话选择模式时，默认使用 `default`。Host 启动变量 `HI_BUDDY_CLAUDE_BYPASS_PERMISSIONS=1` 可把未设置会话的默认值设为 `bypassPermissions`。在该模式下，Claude 可以用 Host 账户的权限读写文件和运行命令。操作系统权限和组织托管策略仍然生效。

同一 Host 在一个工作目录内一次运行一项任务。请在一边结束本轮执行后再切换到另一边继续同一会话。插件的 DSH 存储记录已添加的目录、任务状态和请求去重信息，消息历史由 Claude Code 管理。

## 构建和验证

构建需要相邻的 hi-buddy 源码及其已构建的开发依赖。安装包自带生成的 Host、Client 和 Remote 产物。

```sh
pnpm install --frozen-lockfile
pnpm dev:link-host
pnpm build
pnpm test
pnpm typecheck
pnpm test:loader
pnpm test:browser
pnpm pack --pack-destination dist
```

外网模型集成测试需要一个已保存的 Web profile 和明确的 Anthropic Messages 路由。测试使用临时项目和原生会话。最后一个参数仅供测试用来验证外部终端续聊。

```sh
pnpm test:live /absolute/dsh-home provider-id /absolute/path/to/claude
```

参见 [工作区截图](verification/workspace-files-light.png)、[验证记录](VERIFICATION.md)、[宿主右栏接入调查](RIGHTBAR.md) 和 [第三方依赖声明](THIRD-PARTY-NOTICES.md)。
