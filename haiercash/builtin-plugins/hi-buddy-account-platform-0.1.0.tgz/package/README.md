# hi-buddy-account-platform

Hi-Buddy 账号登录（hibuddy-server 真实登录协议的进程内 cordis 服务）。按 [Hi-Buddy 账号登录宿主接入设计](../docs/design/2026-11-14-hi-buddy-account-integration-design.md)（2026-11-14 拍板版）实现：浏览器授权编排、会话票被动续期、登出，全部写宿主账号面板读取的同一凭据记录键。生产与开发同一份代码，只有 hibuddy-server 的 IAM 环境不同。

## 接线

- **槽位名 `hiBuddyAccount`**（宿主的 `deepseekAccount` 仍属旧 DeepSeek 登录，互不占用）。宿主 `deepseek-account-platform` 包在其 `hiBuddyLogin` 配置键打开时把全部公开方法委托到本服务；`hi-buddy-connector-kit` 的会话源 `HostSessionSource` 也在每次调用现解析本槽位。
- **依赖注入**：`credentials`（凭据存储，本包与宿主面板共享记录键 `credentialKey('deepseek-account-platform', 'default')`）与 `authorization`（dsh-authorization 授权缝，浏览器登录 attempt 的生命周期归它管）。
- **登录协议**：`POST /v1/auth/start` → 浏览器打开 `authorizeUrl` → 轮询 `POST /v1/auth/poll` 至单次 `completed`（sessionTicket 一次性）→ 经授权缝 `session.commit` 落凭据记录；临期自动 `POST /v1/auth/renew`（401 → 本地移除记录 + `ReloginRequiredError`）；登出 `POST /v1/auth/logout`（尽力而为）。
- 会话票只存在于 Host 内存、凭据存储与发往 hibuddy 端点的请求体——不进日志、环境变量、Loader 配置或任何视图类型；错误与日志里票据只以长度出现。

## 配置键（ConfigSchema）

| 键 | 默认 | 说明 |
|---|---|---|
| `endpoint` | `https://ai-mate-hibuddy.haierxj.cn` | hibuddy-server 根地址。启动时强制：非回环主机必须 HTTPS；回环 HTTP 需 `allowLoopbackHttp` 放行 |
| `allowLoopbackHttp` | `true` | 允许回环 HTTP endpoint（开发用）。非回环主机一律要求 HTTPS——此键无法为非回环明文放行 |
| `requestTimeoutMs` | `10000` | 单个登录请求超时 |
| `pollIntervalMs` | `2000` | 登录轮询间隔 |

## 本地验证

```sh
npm install
npm run build && npm test   # 构建 + 全部套件（service/login/session/boot）
npm pack                    # 打包（当前 0.1.0）
```

宿主消费：在宿主 profile 的 `package.json` 把 `hi-buddy-account-platform` 指向新 tgz 并重装；开发态用 `pnpm run dev:web --hibuddy` 自动接线启动器探测的 hibuddy-server（`HIBUDDY_ENDPOINT` 可指向本地或远程部署，以探测通过的端点为准）。
