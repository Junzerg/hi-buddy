import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { AuthorizationSession } from '@deepseek-ai/dsh-authorization';
import type { AccountClientMetadata, AccountDetails, AccountUserId, AccountBonusOrderId, PlatformSession, SignInAttemptId, SignInAttemptView } from '@deepseek-ai/dsh-deepseek-account';
import type { AccountView } from '@deepseek-ai/dsh-deepseek-account';
import type { HiBuddyGrantPayload } from './login.js';
declare module '@deepseek-ai/cordis' {
    interface Events {
        /** The stored lingxi ticket died server-side and was removed locally.
         * @mode emit
         */
        'deepseek-account/session-expired'(): void;
    }
}
export { decodeTicketPayload } from './ticket.js';
export type { TicketClaims } from './ticket.js';
export { buildGrant } from './login.js';
export type { HiBuddyGrantPayload, LoginStartResult, PollOutcome } from './login.js';
export { ReloginRequiredError } from './errors.js';
/** The credential record the Host account panel and this package share. */
export declare const KEY: import("@deepseek-ai/dsh-credentials").CredentialKey;
/** Renewal margin: refresh this many ms before the ticket's exp. */
export declare const RENEW_MARGIN_MS = 30000;
export declare const ConfigSchema: Schema<Schemastery.ObjectS<NoInfer<{
    endpoint: Schema<string, string, "defined">;
    allowLoopbackHttp: Schema<boolean, boolean, "defined">;
    requestTimeoutMs: Schema<number, number, "defined">;
    pollIntervalMs: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    endpoint: Schema<string, string, "defined">;
    allowLoopbackHttp: Schema<boolean, boolean, "defined">;
    requestTimeoutMs: Schema<number, number, "defined">;
    pollIntervalMs: Schema<number, number, "defined">;
}>>, "plain">;
export interface Config {
    endpoint?: string;
    allowLoopbackHttp?: boolean;
    requestTimeoutMs?: number;
    pollIntervalMs?: number;
}
/** AccountView plus the Host workspace's authenticationMethod field. */
export type HiBuddyAccountView = AccountView & {
    authenticationMethod?: 'iam';
};
/** One login attempt: its id, cancellation handle, public view, settle task. */
export interface AttemptState {
    id: SignInAttemptId;
    controller: AbortController;
    view: SignInAttemptView;
    /** Resolves when the seam attempt settles; never rejects (handled inside). */
    task?: Promise<void>;
}
export default class HiBuddyAccount extends Service {
    static inject: string[];
    private readonly endpoint;
    protected readonly requestTimeoutMs: number;
    protected readonly pollIntervalMs: number;
    private readonly watchListeners;
    /** Active or last login attempt; null until the first startSignIn. */
    protected attempt: AttemptState | undefined;
    /** In-flight ticket renewal; concurrent gets join this single flight. */
    private renewing;
    /** In-flight expiry/sign-out cleanup; serialized like the Host's `removing`. */
    private removing;
    constructor(ctx: Context, config?: Config, fetchImpl?: typeof fetch);
    private readonly fetchImpl;
    /** lingxi-server root; no usage/top-up pages exist, so both links point there. */
    private links;
    /** Read this package's grant record; undefined while signed out. */
    protected readGrant(): Promise<HiBuddyGrantPayload | undefined>;
    /** Write the grant record (single-shot tickets land here immediately). */
    protected writeGrant(grant: HiBuddyGrantPayload): Promise<void>;
    getState(): Promise<HiBuddyAccountView>;
    getProfile(_client: AccountClientMetadata): Promise<AccountDetails['profile'] | null>;
    getBalance(_client: AccountClientMetadata): Promise<AccountDetails['balance'] | null>;
    getUnnotifiedBonuses(_client: AccountClientMetadata): Promise<null>;
    ackBonusNotified(_accountId: AccountUserId, _orderId: AccountBonusOrderId, _client: AccountClientMetadata): Promise<boolean>;
    getPlatformSession(): Promise<PlatformSession | null>;
    resolveToken(_url: string): Promise<string | undefined>;
    /**
     * The current session ticket, renewing first when it is within
     * {@link RENEW_MARGIN_MS} of expiry (or on `force`). Renewal is a
     * single flight: concurrent callers share one request. A rejected renewal
     * removes the stored grant, fires the expiry events, and throws.
     */
    getSessionTicket(force?: boolean): Promise<string>;
    private runRenew;
    /**
     * Sign out: withdraw any live attempt, tell lingxi-server to end the session
     * (a remote failure never blocks local cleanup), drop the grant, and notify.
     */
    signOut(_client?: AccountClientMetadata): Promise<HiBuddyAccountView>;
    /**
     * Remove the stored login only while it still matches the rejected token —
     * the Host's `expireCredential` sequence, verbatim: delete, session-expired,
     * clear attempt, signed-out, change.
     */
    rejectToken(token: string): Promise<void>;
    /** The Host's expiry sequence, single-flighted; a no-op if the record moved on. */
    private expireStoredTicket;
    /**
     * Start (or join) a browser login. A live attempt is joined by returning its
     * current view; a new one goes through the authorization seam, whose flow
     * (the Host guard forwards to {@link handleAuthorizationRun}) drives the
     * protocol. Resolves immediately with the attempt's first view.
     */
    startSignIn(_client?: AccountClientMetadata, _callbackOrigin?: string, _loginSource?: 'web' | 'desktop'): Promise<HiBuddyAccountView>;
    /** Withdraw the named attempt; the seam settles its begin() as cancelled. */
    cancelSignIn(id: SignInAttemptId): Promise<HiBuddyAccountView>;
    /**
     * The login protocol run behind the authorization flow registered for
     * {@link KEY} (by the Host guard, or a test seam): start the transaction,
     * surface the browser URL, poll until the single-shot ticket arrives, commit
     * it immediately through the seam, and record the outcome view.
     */
    handleAuthorizationRun(session: AuthorizationSession): Promise<void>;
    /** Merge a patch into the current attempt's view and notify watchers. */
    private setAttemptView;
    getDeviceIdentity(): Promise<{
        osVersion: string;
    }>;
    /** Hi-Buddy login has no API-key path; the Host workspace surface rejects it. */
    completeApiKeySignIn(_apiKey: string, _client: AccountClientMetadata): Promise<never>;
    /**
     * Snapshot stream: a complete initial view, then a fresh frame after every
     * state change. Signal lifetime only controls the subscription.
     */
    watch(signal: AbortSignal, _includeIdentityChanges?: boolean): AsyncIterable<HiBuddyAccountView>;
    /** Push a fresh snapshot to every active watch consumer. */
    protected changed(): void;
    /** Host guard forwards `credentials/record-updated` here; refresh watchers. */
    notifyRecordUpdated(): void;
}
