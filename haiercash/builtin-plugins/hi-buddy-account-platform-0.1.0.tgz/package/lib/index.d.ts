import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { AuthorizationSession } from '@deepseek-ai/dsh-authorization';
import type { AccountClientMetadata, AccountDetails, AccountUserId, AccountBonusOrderId, PlatformSession, SignInAttemptId, SignInAttemptView } from '@deepseek-ai/dsh-deepseek-account';
import type { AccountView } from '@deepseek-ai/dsh-deepseek-account';
import type { HiBuddyGrantPayload } from './login.js';
declare module '@deepseek-ai/cordis' {
    interface Events {
        /** The stored hibuddy ticket died server-side and was removed locally.
         * @mode emit
         */
        'deepseek-account/session-expired'(): void;
    }
}
export { decodeTicketPayload } from './ticket.js';
export type { TicketClaims } from './ticket.js';
export { buildGrant } from './login.js';
export type { HiBuddyGrantPayload, LoginStartResult, PollOutcome } from './login.js';
export { ReloginRequiredError } from './errors.js';
/** The credential record the Host account panel and this package share. */
export declare const KEY: import("@deepseek-ai/dsh-credentials").CredentialKey;
/** Renewal margin: refresh this many ms before the ticket's exp. */
export declare const RENEW_MARGIN_MS = 30000;
export declare const ConfigSchema: Schema<Schemastery.ObjectS<NoInfer<{
    endpoint: Schema<string, string, "defined">;
    allowLoopbackHttp: Schema<boolean, boolean, "defined">;
    requestTimeoutMs: Schema<number, number, "defined">;
    pollIntervalMs: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    endpoint: Schema<string, string, "defined">;
    allowLoopbackHttp: Schema<boolean, boolean, "defined">;
    requestTimeoutMs: Schema<number, number, "defined">;
    pollIntervalMs: Schema<number, number, "defined">;
}>>, "plain">;
export interface Config {
    endpoint?: string;
    allowLoopbackHttp?: boolean;
    requestTimeoutMs?: number;
    pollIntervalMs?: number;
}
/** The provisioning stage labels — `SignInAttemptView['errorStage']` in the
 *  Host workspace type; the published dependency predates the field, so the
 *  kit carries it as a structural extension (runtime passthrough only). */
type AttemptStage = 'configuration' | 'model-discovery' | 'model-selection' | 'credential-reset' | 'model-settings' | 'default-model' | 'credential-save' | 'grant-save' | 'rollback';
/** Attempt view plus the stage labels; still assignable to SignInAttemptView. */
type StageAttemptView = SignInAttemptView & {
    errorStage?: AttemptStage | undefined;
};
/** AccountView plus the Host workspace's authenticationMethod field and the
 *  extended attempt view. */
export type HiBuddyAccountView = Omit<AccountView, 'attempt'> & {
    attempt: StageAttemptView | null;
    authenticationMethod?: 'iam';
};
/** One login attempt: its id, cancellation handle, public view, settle task. */
export interface AttemptState {
    id: SignInAttemptId;
    controller: AbortController;
    view: StageAttemptView;
    /** Resolves when the seam attempt settles; never rejects (handled inside). */
    task?: Promise<void>;
}
export default class HiBuddyAccount extends Service {
    static inject: string[];
    private readonly endpoint;
    protected readonly requestTimeoutMs: number;
    protected readonly pollIntervalMs: number;
    private readonly watchListeners;
    /** Active or last login attempt; null until the first startSignIn. */
    protected attempt: AttemptState | undefined;
    /** In-flight ticket renewal; concurrent gets join this single flight. */
    private renewing;
    /** In-flight expiry/sign-out cleanup; serialized like the Host's `removing`. */
    private removing;
    constructor(ctx: Context, config?: Config, fetchImpl?: typeof fetch);
    private readonly fetchImpl;
    /** hibuddy-server root; no usage/top-up pages exist, so both links point there. */
    private links;
    /** Read this package's grant record; undefined while signed out. */
    protected readGrant(): Promise<HiBuddyGrantPayload | undefined>;
    /** Write the grant record (single-shot tickets land here immediately). */
    protected writeGrant(grant: HiBuddyGrantPayload): Promise<void>;
    getState(): Promise<HiBuddyAccountView>;
    getProfile(_client: AccountClientMetadata): Promise<AccountDetails['profile'] | null>;
    getBalance(_client: AccountClientMetadata): Promise<AccountDetails['balance'] | null>;
    getUnnotifiedBonuses(_client: AccountClientMetadata): Promise<null>;
    ackBonusNotified(_accountId: AccountUserId, _orderId: AccountBonusOrderId, _client: AccountClientMetadata): Promise<boolean>;
    getPlatformSession(): Promise<PlatformSession | null>;
    /**
     * The inference credential for `accountRequired` model routes, 主包
     * resolveToken 语义的 kit 对应: llm-pi-ai calls this with the route's own
     * baseURL, and the route serves models only when a token comes back. Under
     * companyLogin the grant token WAS that credential; here the login
     * provisioning stores the gateway key under its credential ref instead, so
     * this serves it for the configured company-gateway route origin and
     * `undefined` everywhere else (foreign route, no key, no settings plane) —
     * the caller renders MISSING_CREDENTIAL either way.
     */
    resolveToken(url: string): Promise<string | undefined>;
    /**
     * The current session ticket, renewing first when it is within
     * {@link RENEW_MARGIN_MS} of expiry (or on `force`). Renewal is a
     * single flight: concurrent callers share one request. A rejected renewal
     * removes the stored grant, fires the expiry events, and throws.
     */
    getSessionTicket(force?: boolean): Promise<string>;
    private runRenew;
    /**
     * Sign out: withdraw any live attempt, tell hibuddy-server to end the session
     * (a remote failure never blocks local cleanup), drop the grant, and notify.
     */
    signOut(_client?: AccountClientMetadata): Promise<HiBuddyAccountView>;
    /**
     * Remove the stored login only while it still matches the rejected token —
     * the Host's `expireCredential` sequence, verbatim: delete, session-expired,
     * clear attempt, signed-out, change.
     */
    rejectToken(token: string): Promise<void>;
    /** The Host's expiry sequence, single-flighted; a no-op if the record moved on. */
    private expireStoredTicket;
    /**
     * Start (or join) a browser login. A live attempt is joined by returning its
     * current view; a new one goes through the authorization seam, whose flow
     * (the Host guard forwards to {@link handleAuthorizationRun}) drives the
     * protocol. Resolves immediately with the attempt's first view.
     */
    startSignIn(_client?: AccountClientMetadata, _callbackOrigin?: string, _loginSource?: 'web' | 'desktop'): Promise<HiBuddyAccountView>;
    /** Withdraw the named attempt; the seam settles its begin() as cancelled.
     *  The committing phase covers gateway-key provisioning + the seam commit:
     *  an abort there would roll the wiring back AND delete the still-valid
     *  previous session grant, so it is refused exactly like the Host's
     *  cancelSignIn. Always awaits the attempt's settlement (covering a
     *  provisioning walk in flight), so sign-out/expiry never race it. */
    cancelSignIn(id: SignInAttemptId): Promise<HiBuddyAccountView>;
    /**
     * The login protocol run behind the authorization flow registered for
     * {@link KEY} (by the Host guard, or a test seam): start the transaction,
     * surface the browser URL, poll until the single-shot ticket arrives, commit
     * it immediately through the seam, and record the outcome view.
     */
    handleAuthorizationRun(session: AuthorizationSession): Promise<void>;
    /** Merge a patch into the current attempt's view and notify watchers. */
    private setAttemptView;
    /**
     * Fetch the personal gateway key and wire the company-gateway model plane,
     * 主包 queueCompanyKey 的照搬 (stage order, write order, and cleanup all
     * match): provider-row validation → catalog fetch + full validation →
     * selection → credential-reset → model-settings → default-model →
     * credential-save → grant-save (the caller's commit). All-or-nothing: the
     * commit is the last step, and any failure afterwards rolls the model plane
     * back and leaves no grant. Failures before the first write need no cleanup.
     * Pre-existing errorStage patches on the attempt view report the progress.
     */
    private provisionGatewayKey;
    /**
     * Sign-out cleanup, 主包 clearCompanyAccess 语义: withdraw the gateway key
     * ref, clear the provider catalog, and reset a company-gateway default.
     * Missing configuration services mean the wiring never ran (it requires
     * them), so the remaining cleanup is a no-op rather than a failure — unlike
     * the Host package, whose deployments always mount this plane.
     */
    private clearCompanyAccess;
    getDeviceIdentity(): Promise<{
        osVersion: string;
    }>;
    /** Hi-Buddy login has no API-key path; the Host workspace surface rejects it. */
    completeApiKeySignIn(_apiKey: string, _client: AccountClientMetadata): Promise<never>;
    /**
     * Snapshot stream: a complete initial view, then a fresh frame after every
     * state change. Signal lifetime only controls the subscription.
     */
    watch(signal: AbortSignal, _includeIdentityChanges?: boolean): AsyncIterable<HiBuddyAccountView>;
    /** Push a fresh snapshot to every active watch consumer. */
    protected changed(): void;
    /** Host guard forwards `credentials/record-updated` here; refresh watchers. */
    notifyRecordUpdated(): void;
}
