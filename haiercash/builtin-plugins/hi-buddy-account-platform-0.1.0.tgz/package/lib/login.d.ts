/** The grant payload stored under the shared credential key. */
export interface HiBuddyGrantPayload {
    version: 1;
    /** HMAC session ticket (iss=lingxi-login, aud=lingxi-control-plane). */
    token: string;
    /** The lingxi-server origin that issued the ticket. */
    issuer: string;
    hiBuddy: {
        expiresAt: number;
        sub: string;
        tenant: string;
    };
}
/** What `POST /v1/auth/start` returns on 201. */
export interface LoginStartResult {
    loginId: string;
    authorizeUrl: string;
    /** Epoch milliseconds; the login transaction's deadline. */
    expiresAt: number;
}
export type PollOutcome = {
    kind: 'pending';
} | {
    kind: 'completed';
    sessionToken: string;
} | {
    kind: 'invalid-grant';
};
export type RenewOutcome = {
    kind: 'renewed';
    sessionToken: string;
} | {
    kind: 'relogin-required';
};
/** Sanitized protocol failure; `kind` drives the attempt's error code. */
export declare class RequestError extends Error {
    readonly kind: 'transport' | 'http' | 'protocol' | 'aborted';
    constructor(message: string, kind: RequestError['kind'], options?: {
        cause?: unknown;
    });
    /** An abort surfacing as a request failure (cancel, not breakage). */
    static isAborted(error: unknown): boolean;
}
export declare function requestStart(endpoint: string, timeoutMs: number, fetchImpl: typeof fetch, signal: AbortSignal): Promise<LoginStartResult>;
export declare function requestPoll(endpoint: string, loginId: string, timeoutMs: number, fetchImpl: typeof fetch, signal: AbortSignal): Promise<PollOutcome>;
/** `POST /v1/auth/renew {sessionToken}` → a fresh ticket, or relogin-required. */
export declare function requestRenew(endpoint: string, token: string, timeoutMs: number, fetchImpl: typeof fetch): Promise<RenewOutcome>;
/** `POST /v1/auth/logout` (Bearer); the ticket travels only in the header. */
export declare function requestLogout(endpoint: string, token: string, timeoutMs: number, fetchImpl: typeof fetch): Promise<void>;
/** Build the stored grant from a single-shot ticket; issuer is the server origin. */
export declare function buildGrant(token: string, issuer: string): HiBuddyGrantPayload;
/** Abort-aware sleep: resolves early when the signal fires. */
export declare function sleep(ms: number, signal: AbortSignal): Promise<void>;
