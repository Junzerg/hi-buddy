/**
 * The login state died server-side and only a browser login can restore it.
 * Thrown by `getSessionTicket` after the stored grant was removed and the
 * expiry events fired; carried by the message, never the ticket value.
 */
export declare class ReloginRequiredError extends Error {
    constructor(message?: string);
}
