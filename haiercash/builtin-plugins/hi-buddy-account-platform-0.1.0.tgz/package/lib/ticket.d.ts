/** Session-ticket payload claims (the subset this package reads locally). */
export interface TicketClaims {
    sub: string;
    tenant: string;
    sid: string;
    name?: string;
    iat: number;
    exp: number;
}
/**
 * Decode a session ticket's payload claims locally, without verification.
 * The ticket comes from this Host's own credential store, so authenticity is
 * already established; this only reads display fields (name) and expiry.
 */
export declare function decodeTicketPayload(token: string): TicketClaims;
