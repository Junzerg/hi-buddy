# hi-buddy Claude

在 hi-buddy 侧边栏打开 **Claude**，选择本机项目，再打开已有会话或新建。已有会话按 Claude Code 的原生 ID 继续，新会话在首次发送后进入 Claude Code 的会话列表。在终端继续同一会话后，点击页面的「刷新」即可读取新增内容。

左侧切换项目和会话，中间聊天，右侧「改动」查看文件差异。右侧在任务结束后自动刷新，也可手动刷新。这里展示 Git 工作区相对 HEAD 的未提交改动，包含用户或其他工具的修改。未提交初始版本的仓库分别显示暂存和未暂存差异。窄窗口通过顶部按钮切换区域。

## 使用条件

- hi-buddy / DSH 0.2.2-rc.1，Node.js 24.9 或更新版本。
- 查看工作区差异需要本机 Git。
- 本机 Claude Code CLI 2.1.218。默认通过 PATH 查找，也可在页面的「运行环境」指定绝对路径。
- 在 hi-buddy 的「设置 → 模型」配置明确使用 Anthropic Messages 协议的模型和认证。插件使用所选路由的原始模型 ID 和地址，认证由 DSH Host 提供。

在目标 profile 的插件管理器安装本地 `.tgz` 并启用。使用 DSH CLI 管理 Web profile 时，执行以下命令。

```sh
dsh plugin --profile web add /absolute/path/hi-buddy-claude-kit-0.1.0-alpha.3.tgz
```

## 会话和权限

项目根据 Claude Code 会话的工作目录列出，也可以通过绝对路径打开其他目录。会话数据来自 Host 用户的 Claude Code 配置目录，默认为 `~/.claude`，也支持 Host 启动时设置的 `CLAUDE_CONFIG_DIR`。页面展示最近 200 条可呈现记录，文本总量上限为 1 MB。

Claude Code 运行工具并写入原生会话。插件转发 Claude 请求的工具审批和问题，使用默认权限模式。执行时关闭用户、项目和本地设置来源，组织托管策略仍可能生效。离开页面后，正在执行的任务会继续。停止任务会关闭插件管理的进程。

同一 Host 在一个工作目录内一次运行一项任务。请在外部终端结束本轮执行后再到 hi-buddy 继续同一会话。插件的 DSH 存储只记录 CLI 路径、任务状态和请求去重信息，消息历史由 Claude Code 管理。

## 构建和验证

构建需要相邻的 hi-buddy 源码及其已构建的开发依赖。安装包自带生成的 Host、Client 和 Remote 产物。

```sh
pnpm install --frozen-lockfile
pnpm dev:link-host
pnpm build
pnpm test
pnpm typecheck
pnpm test:loader
pnpm test:browser
pnpm pack --pack-destination dist
```

外网模型集成测试需要一个已保存的 Web profile 和明确的 Anthropic Messages 路由。测试使用临时项目和原生会话。

```sh
pnpm test:live /absolute/dsh-home provider-id /absolute/path/to/claude
```

参见 [验证记录](VERIFICATION.md) 和 [第三方依赖声明](THIRD-PARTY-NOTICES.md)。
