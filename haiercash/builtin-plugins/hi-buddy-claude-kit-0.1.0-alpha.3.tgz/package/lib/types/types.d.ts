export type SessionStatus = 'idle' | 'running' | 'waiting-for-input' | 'cancelling' | 'completed' | 'failed' | 'interrupted';
export interface TranscriptEntry {
    id: string;
    kind: 'user' | 'assistant' | 'tool' | 'tool-result' | 'notice';
    text: string;
    toolName?: string;
    toolUseId?: string;
}
export interface NativeProject {
    cwd: string;
    name: string;
}
export interface NativeSession {
    id: string;
    title: string;
    updatedAt: number;
}
export interface ModelSelection {
    provider: string;
    model: string;
}
export interface SessionState {
    id: string;
    cwd: string;
    status: SessionStatus;
    taskId?: string;
    error?: string;
    messages: TranscriptEntry[];
}
export interface StoredSession extends SessionState {
    version: 1;
    existing: boolean;
    requests: {
        id: string;
        digest: string;
        taskId: string;
    }[];
}
export interface ApprovalView {
    id: string;
    taskId: string;
    toolUseId: string;
    toolName: string;
    inputJson: string;
}
export interface SessionSnapshot {
    epoch: string;
    sequence: number;
    session: SessionState;
    approvals: ApprovalView[];
}
export interface EnvironmentView {
    path: string;
    version: string;
    sdkVersion: string;
    compatible: boolean;
    error: string;
}
export interface WorktreeFile {
    path: string;
    status: string;
}
export interface WorktreeChanges {
    available: boolean;
    files: WorktreeFile[];
    truncated: boolean;
}
export interface FileDiff {
    text: string;
    truncated: boolean;
}
