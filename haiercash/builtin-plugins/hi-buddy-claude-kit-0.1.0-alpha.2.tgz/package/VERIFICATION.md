# 验证记录

版本为 `0.1.0-alpha.2`。Linux x64、Node 24.22.2、Claude Code CLI 2.1.218、Agent SDK 0.3.218。目标 hi-buddy 源码为 `c99b8405cac5ca2ac632784325cd8a4617bbeb41`，DSH 包版本为 `0.2.2-rc.1`。工作树包含宿主模型文案等本地改动。

| 验证 | 结果 |
| --- | --- |
| 构建和类型 | Host、Client 及生成的 Typert Remote 构建通过 |
| 自动化测试 | 24 项通过，覆盖凭据解析、审批去重、取消、进程清理及中断恢复 |
| 真实 DSH Loader | 从独立临时目录安装打包产物，验证 Loader 加载、Remote 授权及序列化、CLI 路径检测、禁用和重新启用 |
| 本机 Claude CLI 与真实 DSH Remote | 终端创建会话，DSH 发现项目和会话、读取历史并按同一 ID 续聊。终端再续聊后，DSH 刷新可读到新增消息 |
| 会话与任务 | 跨项目打开被拒绝。DSH 新建会话在首次发送后可通过 SDK 查询。原生问题可通过 Remote 回答，重复回答被拒绝。重启后的重复发送返回原任务 ID |
| 浏览器页面 | 使用宿主 UI 组件和测试数据验证项目选择、读取会话、新建、问答、拒绝及手动打开目录。390px 深色视图无横向溢出 |

真实模型测试使用已保存的外网 Anthropic Messages 路由，以及临时 DSH profile、工作目录和 Claude 配置目录。终端步骤使用本机 CLI 的非交互模式。

页面预览使用测试数据。真实 Desktop 安装及浏览器载体的端到端交互、内网认证、Windows 和 macOS 待验收。

[项目入口](verification/projects-light.png) · [会话页面](verification/native-session-light.png) · [窄屏深色](verification/native-session-mobile-dark.png)
