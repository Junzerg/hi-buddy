# hi-buddy-connector-kit

连接器市场插件（Host 侧 Remote 服务 + Web 页面）。按 [Lingxi 托管连接器动态凭据设计](../docs/design/2026-11-13-lingxi-mcp-dynamic-credentials-design.md)（2026-11-13 拍板版）实现：会话接缝 + RFC 8693 token exchange + 宿主 `authProviderRef` 定制层。客户端不持有账号标识（accountRef 不存在于任何客户端可见面）。

## 凭据流

- **控制面**（authorize / poll / accounts / revoke）：Host 携带会话票（HMAC JWT，来源 = 宿主 `hiBuddyAccount` 槽位，2026-11-14 起由 hi-buddy-account-platform 供给）调用 Lingxi API；401 时强制刷新会话并重试一次。
- **数据面**（MCP）：激活时，插件在当前宿主的 Cordis 上监听 `mcp-client/resolve-auth-provider`。查询 `hi-buddy-connector:${connectorId}` 时返回 `{ url: runtime.endpoint, provider }`，其中 `provider` 是该连接器当前注册的实例。宿主创建 transport 时查找该实例并校验 URL。Loader 条目只含 `{transport, serverName, url, authProviderRef, failOnStartupError: false}`。停用时先移除 Loader 条目，再注销监听器。SDK transport 每次请求通过 `token()` 获取 MCP access token。票临期自动换新，并发请求共用一次 exchange。401 `invalid_token` 时清缓存并换票，401 `ACCOUNT_REVOKED` 时停止连接器、标记本地记录并把重连指引交给 agent（见下节）。
- **工具发现**：`discoverMcpTools(connectorId)` 按宿主工具注册表的 `mcp__hi_buddy_<connectorId>__` 前缀过滤，不回源服务端。
- 两张票都只在 Host 内存：不落盘、不进 Loader 配置、环境变量、日志或前端状态。

## 对话内扫码重连（2026-11-16）

设计：`../docs/design/2026-11-16-conversation-qr-reconnect-design.md`。授权失效时 MCP 工具面已被拆除，agent 的唯一发现通道是 401 错误文案：provider 把服务端 message 原样抛出（§1 载体链），模型按指引调用下面的工具，用户在对话里扫码即完成重连，宿主零改动。

插件常驻注册两个宿主工具（构造时经 `ctx.get('tools')`，随 effect 清理注销）：

- `connect_connector(connectorId)`：创建授权事务，返回 `authMarkdown`（扫码型连接器为二维码图片 `![连接二维码](…/v1/connector-accounts/authorizations/{id}/qr)`，浏览器型为授权链接；agent 原样发出宿主即渲染）与操作指引；同 connectorId 存在未过期在途事务时直接复用（去重，不重复发起）。
- `wait_for_connector(authorizationId)`：25s 有界长轮询确认授权结果。`authorized` → 清在途项并 reconcile（MCP 工具面即回）；`pending` → 返回隧道不可达提示；`denied` 且 `reason:'account_mismatch'` → 提示须用原账号重新授权（服务端回调强制同账号，换号须先在面板撤销）。

每笔在途事务另挂 1.5s 间隔的后台 watcher：用户不叫 agent 也能在扫码完成后自动 reconcile（agent 不问自愈）。

## 连接记录（version 2）

`hi_buddy_connector` 存储域按 connectorId 唯一：`connection:${connectorId}` → `{connectorId, displayName?, grantedScopes?, status: 'connected'|'revoked', createdAt, updatedAt}`。无 accountRef。**开发期不写迁移**：旧 version 1 记录需清空 `.state/home/storages/hi_buddy_connector.json` 后重连。

## 本地验证

```sh
(cd ../lingxi-server && npm ci && npm run dev)  # 在独立终端运行，Node ≥ 24
npm ci && npm test                             # 构建并运行测试
npm pack
```

在配套宿主 checkout 运行 `pnpm run dev:web --hibuddy --kits`。账号登录后，在连接器市场授权「演示记事本」可验证本地 MCP 工具的注册和撤销。

宿主的 MCP client 需支持 `authProviderRef` 以及 `mcp-client/resolve-auth-provider` 查询。账号平台的 `endpoint` 与本插件的 `apiBaseUrl` 应指向同一个 `lingxi-server` 实例。API 基地址支持 HTTPS 和回环 HTTP。

## 构建

```sh
npm install
npm run build   # tsc ×3 + typert 生成 + client bundle
```

打包前通过 ASCII 标识符 `lxcm-page` 检查 client bundle。
