/** OAuth declaration carried by a connector from the market. */
export interface ConnectorAuth {
    type?: string;
    scopes?: string[];
    /** 授权引导形态：qr=扫码（缺省），browser=默认浏览器打开授权页。 */
    flow?: 'qr' | 'browser';
}
/** One connector shown in the initial market list. */
export interface ConnectorSummary {
    id: string;
    version: string;
    name: string;
    description: string;
    /** One-line card text; the long description is detail-page-only. */
    summary?: string;
    /** Catalog icon URL (market.ts 已消费的三级回退第 2 级，此处补类型洞)。 */
    icon?: string;
    publisher?: {
        id?: string;
        name?: string;
    };
    auth?: ConnectorAuth;
}
/** One connector's full market detail (runtime, compatibility, artifact). */
export interface ConnectorDetail extends ConnectorSummary {
    /** WorkBuddy-style usage examples shown on the detail page. */
    examples?: string[];
    /** `endpoint` is the canonical MCP resource URL (token-exchange audience). */
    runtime?: {
        type: string;
        transport?: string;
        endpoint?: string;
    };
    hostCompatibility?: {
        min?: string;
    };
    risk?: string;
    artifact?: {
        url: string;
        sha256: string;
        signature: string;
        keyId?: string;
        size?: number;
    };
}
/** List response returned by Hi-Buddy's connector-market API. */
export interface ConnectorList {
    items: ConnectorSummary[];
    nextCursor: string | null;
}
/** Created OAuth authorization transaction. */
export interface AuthorizationCreated {
    authorizationId: string;
    authorizationUrl: string;
    expiresAt: string;
}
/** Status of one OAuth authorization transaction while it is polled. */
export type AuthorizationStatusName = 'pending' | 'completed' | 'denied' | 'expired' | 'failed';
export interface AuthorizationStatus {
    status: AuthorizationStatusName;
    connectorId?: string;
    displayName?: string;
    grantedScopes?: string[];
    error?: string;
    /** denied 且扫码者与已连接账号不一致时出现（设计 §5，2026-11-16）。
     *  生成契约的 zod schema 若不认识此字段会静默剥离 —— 面板与 wait 工具都靠它。 */
    reason?: 'account_mismatch';
}
/** One connected account on the Hi-Buddy side. Server-side identity only — no accountRef leaves the API. */
export interface ConnectorAccount {
    connectorId: string;
    displayName?: string;
    grantedScopes: string[];
    status: string;
    /** Epoch ms — hibuddy-server accounts.updated_at is INTEGER and passed through as-is. */
    updatedAt: number;
}
/** Connected-account list for one connector. */
export interface ConnectorAccountList {
    items: ConnectorAccount[];
}
/** One MCP tool reported by a reconcile snapshot. */
export interface ReconcileTool {
    name: string;
    description: string;
}
/** reconcileConnector 结果：服务端账号真相 × 宿主侧自愈结果（错误已脱敏回传）。 */
export interface ReconcileResult {
    account: 'connected' | 'none';
    /** connected 时：detail.runtime.endpoint 是否存在（有无 MCP 工具面）。 */
    expectsTools: boolean;
    tools: ReconcileTool[];
    /** 本次调用是否触发了激活尝试。 */
    activated: boolean;
    /** none 时：是否清理了本地僵尸（停用 + 镜像标记）。 */
    healed: boolean;
    /** account === 'connected' 时的账号信息。 */
    displayName?: string;
    grantedScopes: string[];
    /** 激活尝试的错误（safeErrorMessage 已脱敏）；成功为 undefined。 */
    error?: string;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        'connector-market/endpoint-mismatch': Record<string, never>;
        'connector-market/forbidden': Record<string, never>;
        'connector-market/invalid-config': Record<string, never>;
        'connector-market/invalid-response': Record<string, never>;
        'connector-market/not-found': Record<string, never>;
        'connector-market/not-implemented': Record<string, never>;
        'connector-market/reauth-required': Record<string, never>;
        'connector-market/relogin-required': Record<string, never>;
        'connector-market/unavailable': Record<string, never>;
    }
}
