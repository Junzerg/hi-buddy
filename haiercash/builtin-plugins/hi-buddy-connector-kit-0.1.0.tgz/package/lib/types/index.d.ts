/**
 * Host-side connector-market Remote service（2026-11-13 动态凭据设计）。
 *
 * 会话接缝：控制面（authorize/poll/accounts/revoke）与数据面（MCP access token）
 * 都由 Hi-Buddy 侧按主体鉴权，客户端不持有任何账号标识（accountRef 不存在）。
 * MCP 工具面经宿主 authProviderRef 定制层注入 HiBuddyAuthProvider —— 票只在
 * Host 内存里流转，不进 Loader 配置、环境变量、日志或前端状态。
 */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { type McpAuthProviderShape } from './auth.js';
import type { AuthorizationCreated, AuthorizationStatus, ConnectorAccountList, ConnectorDetail, ConnectorList, ReconcileResult } from './types.js';
export type * from './types.js';
export { HiBuddyAuthProvider, HostSessionSource } from './auth.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        connectorMarket: ConnectorMarket;
    }
    interface Events {
        /** Resolve a connector's in-memory MCP provider in the current Host. @mode bail */
        'mcp-client/resolve-auth-provider'(ref: string): {
            url: string;
            provider: McpAuthProviderShape;
        } | undefined;
        /** Host 登录态清除（主动登出）。@mode emit */
        'deepseek-account/signed-out'(): void;
        /** Host 会话票服务端失效并被本地移除。@mode emit */
        'deepseek-account/session-expired'(): void;
    }
}
/** Deployment-owned Hi-Buddy API endpoint. HTTP is accepted only for a loopback development mock. */
export interface Config {
    apiBaseUrl?: string;
    requestTimeoutMs?: number;
}
export declare const ConfigSchema: Schema<Schemastery.ObjectS<NoInfer<{
    apiBaseUrl: Schema<string, string, "defined">;
    requestTimeoutMs: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    apiBaseUrl: Schema<string, string, "defined">;
    requestTimeoutMs: Schema<number, number, "defined">;
}>>, "plain">;
export default class ConnectorMarket extends TypertRemoteService {
    static inject: string[];
    private readonly apiBaseUrl;
    private readonly requestTimeoutMs;
    private readonly session;
    private readonly activations;
    private readonly deactivations;
    private readonly authProviderDisposers;
    private readonly authProviders;
    /** connectorId → 本宿主生命周期内的重建代数。唯一用途：令每次 connectConnector
     *  交给 loader 的配置必然不等——宿主 loader.update 对 deep-equal 配置不触发
     *  fiber 重启（vendor/loader entry.ts，同配置等于 no-op；2026-11-26 review
     *  实证，飞书卡死案例根因），不带变化量时复活/对账重建会静默失效。重启宿主
     *  后归零无害：届时条目不存在，走 create 路径，本就不比较配置。 */
    private readonly rebuildRevisions;
    private readonly connections;
    /** connectorId → 在途重连授权单（去重依据，设计 §2 评审修正：不判断"已连接"）。
     *  flow/name 取自 catalog detail（2026-11-16 flow 参数化）：复用在途单时
     *  直接从条目重组载荷，不重取目录。 */
    private readonly pendingReconnects;
    private reconnectToolDisposers;
    constructor(ctx: Context, config?: Config);
    /** 宿主登出/会话过期联动：逐连接器停用；单个失败不阻断其余。 */
    private deactivateAllManaged;
    /** Read the connector-market list through the Host-owned API boundary. */
    list(): Promise<ConnectorList>;
    /** Read one connector's detail through the Host-owned API boundary. */
    get(connectorId: string): Promise<ConnectorDetail>;
    /** Start an OAuth authorization transaction for the authenticated principal. */
    authorize(connectorId: string, scopes?: string[]): Promise<AuthorizationCreated>;
    /** Poll one OAuth authorization transaction until it reaches a terminal status. */
    pollAuthorization(authorizationId: string): Promise<AuthorizationStatus>;
    /** List connected accounts for the authenticated principal. */
    listAccounts(connectorId?: string): Promise<ConnectorAccountList>;
    /** Discover the tools a connected connector currently exposes, via the Host tool registry (no server round-trip). */
    discoverMcpTools(connectorId: string): Promise<{
        tools: Array<{
            name: string;
            description: string;
        }>;
    }>;
    /** 以服务端账号为准对账：缺激活→自愈激活；僵尸镜像→停用并标记；结果（含脱敏错误）回传 UI。 */
    reconcileConnector(connectorId: string): Promise<ReconcileResult>;
    /** Revoke the authenticated principal's account for one connector on the Hi-Buddy side. */
    revokeAccount(connectorId: string): Promise<{
        revoked: boolean;
    }>;
    private activateConnector;
    /** 重建代数递增：携带工具面重建意图的 connectConnector 调用，其 loader
     *  配置必须逐次不等，方能保证 update 走真重启（见 rebuildRevisions 注释；
     *  设计文档 2026-11-26-mcp-tool-list-refresh-reconcile-fix-design.md §4）。 */
    private bumpRevision;
    private connectConnector;
    /** 服务端 401 ACCOUNT_REVOKED：停掉连接器工具面并把本地记录标记为 revoked。 */
    private handleAccountRevoked;
    /** 服务端已无账号时的本地清理：停工具面 + 镜像标记 revoked；返回是否清了东西。 */
    private markRevokedLocally;
    /** 激活后等待工具注册：loader.create 在 MCP 异步连接完成前 resolve，须有界轮询兜住。 */
    private waitForTools;
    /** dispose 顺序：先 loader.remove（停止工具面），后 disposeProvider（注销 ref）。 */
    private deactivateConnector;
    private removeMcpEntry;
    /**
     * 注册两个宿主本地工具。它们与 MCP 工具面解耦：撤销瞬间 MCP 面已被拆除，
     * 这两个入口必须始终在线；服务端 401 指引文案（guidance.mjs，经
     * HiBuddyAuthProvider throw 中继）是模型发现它们的唯一通道。
     */
    private registerReconnectTools;
    private disposeReconnectTools;
    /**
     * 发起（或复用在途的）重连授权单并组装模型直接可用的载荷。
     * 去重只看在途单是否未过期——不判断"是否已连接"：主场景（refresh_token
     * 死亡）下服务端账号行仍是 connected，且 kit 拆工具面异步未完（设计 §2）。
     */
    private startReconnect;
    private reconnectPayload;
    /**
     * 有界等待授权完成（服务端长轮询，设计 §4）。completed 先自愈工具面再返回
     * authorized，agent 紧接着重试原工具即成功；状态词表沿用授权单五态不新增。
     */
    private waitReconnect;
    /**
     * 后台看护（设计 §6）：与 wait 工具共享同一 poll 端点（先到先生效，同面板
     * 弹窗与扫码卡的共享模式）。单被换代/清理（map 不再是本单）或到 expiresAt
     * 即停；poll 失败不杀看护（到 expiresAt 自然停）。
     */
    private watchReconnect;
    private clearPendingReconnect;
    private openConnections;
    /** 启动恢复只看本地连接表 —— 账号真源在服务端，但激活是宿主侧的一次性决定。 */
    private restoreConnections;
    private saveConnection;
    private loader;
    private hasLoaderEntry;
    private findLoaderEntry;
    private loaderEntryId;
    /** 无鉴权的公共目录面（list/detail）。 */
    private requestJson;
    /** 会话鉴权控制面：携带会话票；401 时强制刷新会话并重试一次。`timeoutMs`
     *  覆盖单次请求默认超时（长轮询需与服务端窗口同宽，见 waitReconnect）。 */
    private authedRequest;
    /** 二次 401 的漂移诊断：并列两侧 origin，永不含票值。 */
    private endpointMismatchMessage;
    private fetchWithSession;
    private fetchJson;
    private parseJsonResponse;
}
export declare function apply(ctx: Context, config: Config): void;
export declare const inject: string[];
export declare const name = "hi-buddy-connector-kit";
