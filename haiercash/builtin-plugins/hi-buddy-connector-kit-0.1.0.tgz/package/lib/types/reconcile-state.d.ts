/**
 * 连接器详情页的对账状态归约（纯函数）。
 *
 * 抽出为独立模块的原因（2026-11-15 评审 Critical 1/Important 2）：
 * - poll 完成后的一次性 reconcile 后续不能 gate 在 poll effect 的 cancelled 上
 *   （该 effect 依赖 connectState，setConnectState 必触发 cleanup，网络级 RPC
 *   的结果会被确定性丢弃）——迟到的结果经函数式更新落地，由这里裁决。
 * - 宿主 tsconfig 编译进 lib/，node 测试可直测；客户端 bundle 直接引 .ts 源。
 */
import type { ReconcileResult } from './types.js';
export interface DiscoveredMcpTool {
    name: string;
    description: string;
}
export type ConnectState = {
    kind: 'idle';
} | {
    kind: 'connecting';
    authorizationId: string;
    authorizationUrl?: string;
} | {
    kind: 'connected';
    displayName?: string;
    grantedScopes: string[];
    mcpTools: DiscoveredMcpTool[];
    discovering: boolean;
    expectsTools: boolean;
    activationError?: string;
} | {
    kind: 'error';
    message: string;
};
/** 一次对账结果 → 展示状态（绿态只在工具核验通过或无工具面时出现）。 */
export declare function reconcileState(result: ReconcileResult): ConnectState;
/** 迟到的对账后续：只有仍处 connected 态才应用（防踩掉撤销/切换后的新状态）；
 * 失败也必须落地 —— 关掉 discovering 并带上错误，否则降级 UI 永远不出现。 */
export interface ReconcileFollowUp {
    ok: boolean;
    value?: ReconcileResult;
    errorMessage?: string;
}
export declare function nextReconcileState(prev: ConnectState, followUp: ReconcileFollowUp): ConnectState;
/** 弹窗打开瞬间的对账落地守卫（2026-11-16 终审 Important 2）：开屏 reconcile
 * 与用户点【连接】竞态时，无条件落地会把 connecting 打回 idle —— poll 停、
 * 授权孤儿化、卡片点卡黄。connecting 期间返回 null（吞掉，不动状态）。 */
export declare function applyReconcileOnOpen(prev: ConnectState, next: ConnectState): ConnectState | null;
/** 连接动作可用性（2026-11-23 用户反馈）：弹窗从【连接】翻到【已连接】靠开屏
 * reconcile，而【连接】按钮在 detail 就绪时就渲染 —— 已连接连接器会短暂露出
 * 【连接】，用户此刻点击会对已连接连接器再发一轮 OAuth。两条时序都坏：
 * authorize 先回则对账结果被 applyReconcileOnOpen 吞掉（被困进本不需要的扫码）；
 * 对账先回则已连接态被 authorize 结算打回「连接中」+亮码。故 idle 且开屏对账
 * 已落定才可连：弹窗【连接】按钮的渲染门与"+"号 autoConnect 共用本判定，
 * 两处不得分叉。
 *
 * openReconcileSettled 的"落定"五路枚举（漏任何一路都会在 cancel/retry 回 idle
 * 后把按钮永久锁死——开屏对账不会重跑）：成功应用 / 被吞（connecting 保护）/
 * 业务失败（ok:false）/ 协议异常（ok 无 value）/ 网络 reject（catch）。 */
export declare function canStartConnect(state: ConnectState, openReconcileSettled: boolean): boolean;
