/**
 * 连接器详情页的对账状态归约（纯函数）。
 *
 * 抽出为独立模块的原因（2026-11-15 评审 Critical 1/Important 2）：
 * - poll 完成后的一次性 reconcile 后续不能 gate 在 poll effect 的 cancelled 上
 *   （该 effect 依赖 connectState，setConnectState 必触发 cleanup，网络级 RPC
 *   的结果会被确定性丢弃）——迟到的结果经函数式更新落地，由这里裁决。
 * - 宿主 tsconfig 编译进 lib/，node 测试可直测；客户端 bundle 直接引 .ts 源。
 */
import type { ReconcileResult } from './types.js';
export interface DiscoveredMcpTool {
    name: string;
    description: string;
}
export type ConnectState = {
    kind: 'idle';
} | {
    kind: 'connecting';
    authorizationId: string;
    authorizationUrl?: string;
} | {
    kind: 'connected';
    displayName?: string;
    grantedScopes: string[];
    mcpTools: DiscoveredMcpTool[];
    discovering: boolean;
    expectsTools: boolean;
    activationError?: string;
} | {
    kind: 'error';
    message: string;
};
/** 一次对账结果 → 展示状态（绿态只在工具核验通过或无工具面时出现）。 */
export declare function reconcileState(result: ReconcileResult): ConnectState;
/** 迟到的对账后续：只有仍处 connected 态才应用（防踩掉撤销/切换后的新状态）；
 * 失败也必须落地 —— 关掉 discovering 并带上错误，否则降级 UI 永远不出现。 */
export interface ReconcileFollowUp {
    ok: boolean;
    value?: ReconcileResult;
    errorMessage?: string;
}
export declare function nextReconcileState(prev: ConnectState, followUp: ReconcileFollowUp): ConnectState;
/** 弹窗打开瞬间的对账落地守卫（2026-11-16 终审 Important 2）：开屏 reconcile
 * 与用户点【连接】竞态时，无条件落地会把 connecting 打回 idle —— poll 停、
 * 授权孤儿化、卡片点卡黄。connecting 期间返回 null（吞掉，不动状态）。 */
export declare function applyReconcileOnOpen(prev: ConnectState, next: ConnectState): ConnectState | null;
