/** WorkBuddy 同款 31 位字符串哈希：t=(t<<5)-t+code，按名取板内色。 */
export declare function iconFallbackColor(name: string): string;
/** 内置品牌 data URI；未命中返回 undefined（交给首字母回退）。 */
export declare function brandIconDataUri(id: string): string | undefined;
