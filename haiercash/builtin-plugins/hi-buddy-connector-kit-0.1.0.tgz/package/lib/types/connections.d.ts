import { z } from 'zod';
export declare const CONNECTION_DOMAIN: {
    name: string;
    version: number;
    tables: {
        connections: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            key: string;
            connectorId: string;
            status: "connected" | "revoked";
            createdAt: number;
            updatedAt: number;
            displayName?: string | undefined;
            grantedScopes?: string[] | undefined;
        }>;
    };
};
export type ConnectionRecord = z.infer<typeof CONNECTION_DOMAIN.tables.connections.valueSchema>;
export interface ConnectionTable {
    get(key: string): ConnectionRecord | undefined;
    entries(): IterableIterator<[string, ConnectionRecord]>;
    put(key: string, value: ConnectionRecord): Promise<void>;
    delete(key: string): Promise<boolean>;
}
export interface StorageDomain {
    open(spec: typeof CONNECTION_DOMAIN): Promise<{
        table(name: 'connections'): ConnectionTable;
        close(): Promise<void>;
    }>;
}
export declare function connectionKey(connectorId: string): string;
export declare function serverNameFor(connectorId: string): string;
export declare function mcpToolNamePrefix(connectorId: string): string;
