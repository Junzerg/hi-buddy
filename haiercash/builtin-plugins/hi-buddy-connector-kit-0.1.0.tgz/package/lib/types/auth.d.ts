/** SDK `AuthProvider` 的结构子集 —— 只依赖 kit 可见的形状。 */
export interface McpAuthProviderShape {
    token(): Promise<string | undefined>;
    onUnauthorized?(context: {
        response: Response;
        serverUrl?: string;
    }): Promise<void>;
}
type FetchLike = (url: string, init?: RequestInit) => Promise<Response>;
/**
 * 会话票来源：宿主 `hiBuddyAccount` 槽位（hi-buddy-account-platform 注册）。
 * 每次调用现解析槽位，挂载次序免疫；续期/失效判定全在宿主侧（含 renew
 * single-flight 与过期事件）。槽位缺席或宿主要求重登时上抛
 * `connector-market/relogin-required`；其余错误原样透传。
 */
export declare class HostSessionSource {
    private readonly ctx;
    constructor(ctx: {
        get(name: string): unknown;
    });
    /** 当前会话票；`force` 透传给宿主强制续期。 */
    get(force?: boolean): Promise<string>;
}
/** 会话票来源：`SessionTokenSource` 实例，或等价的 `get(force)` 函数对象/裸函数。 */
export type SessionLike = ((force?: boolean) => Promise<string>) | {
    get(force?: boolean): Promise<string>;
};
export interface HiBuddyAuthProviderOptions {
    /** Hi-Buddy API 基地址（https 或回环 http，已在配置层校验）。 */
    apiBaseUrl: string;
    /** MCP resource URL —— exchange 的 audience，须与 runtime.endpoint 一致。 */
    resource: string;
    /** 会话票来源（与控制面共享同一 SessionTokenSource 实例）。 */
    session: SessionLike;
    /** 401 ACCOUNT_REVOKED 时通知上层停止连接器并刷新连接状态。 */
    onAccountRevoked?: () => void;
    requestTimeoutMs?: number;
    /** 测试注入点；生产用全局 fetch。 */
    fetchOverride?: FetchLike;
}
/**
 * MCP 数据面 AuthProvider：SDK transport 每个请求前调用 `token()`，401 后调用
 * `onUnauthorized()` 并重试一次。缓存 {token, exp}，临期（exp-30s）自动换新，
 * 并发 `token()` single-flight 共享一次 exchange。票本体永不出现在异常消息里。
 */
export declare class HiBuddyAuthProvider implements McpAuthProviderShape {
    private readonly options;
    private cached;
    private exchanging;
    private readonly session;
    constructor(options: HiBuddyAuthProviderOptions);
    token(): Promise<string | undefined>;
    onUnauthorized(context: {
        response: Response;
    }): Promise<void>;
    /** 宿主登出联动：丢弃缓存的 MCP 票（会话票随之在宿主侧失效）。 */
    clear(): void;
    private exchange;
}
export {};
