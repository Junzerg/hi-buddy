export declare function qrSvg(content: string, options?: {
    cellSize?: number;
    margin?: number;
    level?: 'L' | 'M' | 'Q' | 'H';
}): string;
