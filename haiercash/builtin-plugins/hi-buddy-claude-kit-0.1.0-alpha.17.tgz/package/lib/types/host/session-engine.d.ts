import { Interactions, type InteractionAnswer } from './interactions.ts';
import type { StoredSession, SessionSnapshot, SessionState, TranscriptEntry, ModelSelection, PermissionMode, EffortLevel } from '../types.ts';
export interface SessionPersistence {
    list(): StoredSession[];
    save(session: StoredSession): Promise<void>;
}
export interface TaskExecution {
    signal: AbortSignal;
    session: StoredSession;
    text: string;
    model: ModelSelection;
    permissionMode: PermissionMode;
    effort?: EffortLevel;
    nativeSession(): Promise<void>;
    append(message: TranscriptEntry): Promise<void>;
    retract(ids: readonly string[]): Promise<void>;
    reportRuntime(runtime: Partial<Pick<SessionState, 'commandOutput' | 'commandOutcome' | 'mcpServers' | 'activity'>>): Promise<void>;
    ask: Interactions['ask'];
}
export type TaskRunner = (task: TaskExecution) => Promise<void>;
/** Single Host admission owner. Client subscriptions do not own tasks or approvals. */
export declare class SessionEngine {
    private readonly persistence;
    private readonly run;
    private readonly history?;
    private readonly defaultPermissionMode;
    private readonly sessions;
    private readonly tasks;
    private readonly directories;
    private readonly listeners;
    private readonly epoch;
    private sequence;
    private closed;
    constructor(persistence: SessionPersistence, run: TaskRunner, history?: ((session: StoredSession) => Promise<TranscriptEntry[]>) | undefined, defaultPermissionMode?: PermissionMode);
    initialize(): Promise<void>;
    has(id: string): boolean;
    snapshot(id: string): SessionSnapshot;
    bind(id: string, cwd: string, existing: boolean): void;
    open(id: string): Promise<SessionSnapshot>;
    private notify;
    private commit;
    private publish;
    send(id: string, requestId: string, text: string, model: ModelSelection, permissionMode?: PermissionMode, effort?: EffortLevel): Promise<string>;
    private finishedHistory;
    answer(id: string, taskId: string, approvalId: string, answer: InteractionAnswer): boolean;
    cancel(id: string): void;
    subscribe(id: string, signal: AbortSignal): AsyncGenerator<SessionSnapshot>;
    settled(id: string): Promise<void>;
    close(): Promise<void>;
}
