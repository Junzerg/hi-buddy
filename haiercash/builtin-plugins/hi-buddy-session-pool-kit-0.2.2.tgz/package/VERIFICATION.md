# 验证记录

日期：2026-11-06。包：`hi-buddy-session-pool-kit@0.2.0`。宿主 HEAD：`6b71eb33d929d2e8f3d50fdabfde2bcb6b8f6a86`。宿主已有模型选择、侧栏、message-quotes、测试和文档等未提交改动，以及若干生成文件；本次仅只读参考，没有修改宿主仓库。kit 根 README 和 glossary 包原有未提交内容未动。

## 0.1.1 联调修复

完整宿主联调发现 0.1.0 菜单读取失败：`cannot get property "remote.sessionPool" without inject`。原客户端测试使用普通嵌套对象，未模拟真实 Gateway 的 Cordis namespace 依赖约束，不能证明该行为兼容。

0.1.1 先执行 `remote.$mount`，再通过 `ctx.inject(['remote.sessionPool'], child => ...)` 注册菜单、Toast 和读写回调；所有 namespace 访问使用 child，状态与清理绑定同一子作用域。顶层仍只注入 slots、locale、remote，避免等待自己尚未挂载的 namespace。

客户端回归改为真实 Cordis + 真实 Client Gateway + 生成的 Typert contribution，只替换连接传输响应；验证缺少 namespace inject 的负例确实抛错，以及本插件的读取成功、加入/退出、失败重试、槽位重声明、卸载撤销和过期回调不再写入。

宿主联调任务随后确认：0.1.1 原始 tgz 在完整 Web 中无需补丁，菜单、加入/退出、跨项目发送、简介、刷新、退出拒收均通过；Desktop collection 21 项测试与 lint 通过，但没有桌面安装器人工验收。本次 0.2.0 新 UI 产物需单独复验。

## 0.2.0 任务池 UI

所有用户文案改为任务池，包名、工具名及服务名不变。新增 main/侧栏入口（session-pool）、成员页、点击打开会话、数量与摘要/状态、加载/空白/失败重试，以及会话标题前的成员标记与 Tooltip。

客户端使用单一共享 watchMembers 事件流，页面未打开也订阅；页面关闭不取消侧栏订阅，插件卸载取消整个流并撤销所有槽位。Host members 仅返回 remoteAccess 允许的普通池成员的必要信息；AI 发现仍单独校验调用 Agent 身份和成员资格。测试覆盖流快照、标题变更、取消、乱序结果、失败保留、重试和共享生命周期。

公共接口缺口：已有 row.leading 是定时任务占用的固定 16px 单元，不适合再放成员标记。已向宿主任务提供调用场景与最小建议，由该任务新增 sidebar.session.title.prefix（list/root/inline，owner.sessionId），本插件仅消费公开类型；宿主任务同时维护 Sidebar allowlist。侧栏实际行高度、截断与定时图标共存由宿主任务验证。

## 环境与检查

Node `v24.22.2`，Linux。默认 shell Node 22 仅用于最初安装探测，正式构建和测试显式使用 Node 24。开发依赖通过 `file:` 指向真实宿主已构建包。

| 检查 | 结果及边界 |
| --- | --- |
| `npm run build` | Host / Client strict 类型检查、官方 Typert 生成、Host ESM 与 Client ModuleLoader bundle 成功 |
| `npm test` | 6 个测试通过；内部包含下述场景断言 |
| Loader 集成 | 从临时 `cordis.yml` 由真实 Loader 加载宿主生产服务和 kit；不是单纯手写业务 mock。模型响应由本地确定性 LlmAdapter 提供 |
| 持久化 | 真实 JSON storageDomain 写入，关闭并重建 Cordis Context 后重新读取；退出和重新加入代次有效 |
| 跨工作空间发现 | A/B 独立路径、真实 workspaceRegistry，返回对方 ID、项目和会话标题；不返回自己、不返回退池成员 |
| 投递与回复 | 真实工具执行器调用；真实 Agent 空闲唤醒、运行中下一步骤接收；B 使用同一工具回复 A |
| 冷恢复 | 测试通过自己拥有的 AgentHandle 释放 B，再由插件公开 resolveAgent 恢复已保存 B，接收成功；插件未 dispose 借用 Agent |
| 来源与身份 | 模型收到的消息保留 agent-message / relay / 实际 A 的 senderSessionId；额外 senderId 不产生伪造来源；未入池工具被执行器拒绝 |
| 异常与竞态 | 在公开恢复和 steer 边界注入故障：恢复期间退出再加入，恢复错误、steer 抛错均无虚假成功；普通成功路径使用真实服务 |
| 简介 | 真实 turn/end → projection → llm.prepareCall 辅助调用 → storageDomain；独立单测覆盖异步乱序、失败保留旧简介、退池取消和卸载 abort/drain |
| 卸载 | Agent 工具和指引移除；卸载后新的 turn/end 不再启动辅助调用；SlotRegistry 菜单/Toast 撤销、Remote mount 释放、已释放 UI 回调不再写入 |
| 菜单逻辑 | 真实 Cordis/Gateway namespace 注入和 SlotRegistry 延迟声明、重新声明、加载/失败重试、加入/退出、错误状态与卸载 |
| 隔离浏览器 | 真实宿主 Menu/Button/Tooltip + 本包组件，浅色 1100px / 深色 360px、Enter 加入、点击退出、标记显隐与 hover；成员页状态、数量、键盘导航、长文本和窄屏无横向溢出，浏览器无 pageerror |
| UI 静态检查 | impeccable detector 返回 `[]`；页面使用 CSS modules 与宿主语义 tokens，没有全局主题覆盖或 DOM sweep |
| 安装包 | `npm pack`；只包含 lib、文档、manifest 和 cordis.patch.yml，不包含宿主源码或 node_modules |

浏览器首次启动缺少系统 `libatk-1.0.so.0`；随后复用已有 `/tmp/haier-browser-libs/extracted/usr/lib/x86_64-linux-gnu`，未安装系统库。复现：

```sh
LD_LIBRARY_PATH=/tmp/haier-browser-libs/extracted/usr/lib/x86_64-linux-gnu npm run test:ui
```

隔离截图在 `dist/verification/task-pool-light.png`、`task-pool-dark.png` 及对应空池截图；该目录被 Git 忽略。这是控件预览，不是完整宿主界面截图。

## 尚未验证

- 本版 0.2.0 尚未将 tgz 安装到完整 Web/desktop profile 进行人工菜单、Toast、多个插件共存及全部焦点/输入法验收；没有改动用户运行中的 profile。
- 没有访问真实 LLM 供应商，未对摘要质量、网络断线或供应商取消延迟作端到端保证。
- 恢复失败通过公开调用边界注入验证；没有另起进程制造真实 writer 锁冲突。实际恢复遵循宿主控制器，不实现绕过逻辑。
- `resolveAgent` 无取消参数，卸载会等待已经启动的恢复返回；等待期间不能通过投递后置授权检查。此非阻塞公共接口建议已登记。

## 公共接口结论

原始通信业务接口足以完成最小闭环；0.2.0 UI 需要上述新增通用标题前缀槽位和 Sidebar 配置。来源类型位于 subagent 包、resolveAgent 缺少调用方取消参数两项建议见 `docs/design-proposals/0002-session-pool-host-interfaces.md`。仅登记为草案，未自行批准或修改宿主。

## 0.2.0 完整宿主验收回传

2026-11-06，宿主任务 `01a1af9c-621f-7140-8669-6950af432bae` 确认原始 0.2.0 tgz（SHA-1 `3b1d0c0750341168fd7fb2579129fe5f58fbe2bc`）通过完整业务验收：侧栏任务池入口、成员数量与简介、点击进入会话、未打开成员页时标记实时出现，以及退出后标记消失和页面数量同步。

宿主通用前缀槽位在 1280px / 390px 浏览器验证通过：与 leading 共存、多个前缀、空贡献零宽、卸载恢复、行高及标题截断稳定。宿主 build 10 项、组件 125 项、Desktop 包收集 21 项均通过。宿主仍在收尾页面快照与文档检查；没有要求 kit 额外修改。以上为宿主任务回传证据，取代前文 0.2.0 完整宿主业务验收待完成的状态，不代表真实供应商或桌面安装器人工验收。

此记录在验收后补入源码文档；已验收 tgz 保持原始字节，不重新打包。

## 0.2.1 图标局部更新

用户通过宿主协作线程确认采用 Lucide MessagesSquare。两个入口共享单个本地组件，原始 SVG 与完整上游许可随包发布；没有新增图标库依赖。标题前标记保持 12px，使用随明暗主题切换的 state-business-primary token，入口尺寸继续由宿主决定。

Node 24 构建和既有隔离浏览器回归通过。实际查看 12px / 16px 图标浅色 1100px、深色 360px 截图，双方形气泡可辨识，前缀呈主题强调色；Tooltip、加入/退出显隐、页面状态和导航回归通过。截图为 dist/verification/task-pool-icons-light.png 与 task-pool-icons-dark.png。本次未更改业务逻辑，不重复之前已通过的业务测试；0.2.1 完整宿主安装后的视觉验收交由宿主任务进行。此状态不继承 0.2.0 的新版本安装验收结论。
