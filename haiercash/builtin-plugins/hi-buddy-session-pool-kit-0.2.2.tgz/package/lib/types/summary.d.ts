import { z } from 'zod';
import type { Context } from '@deepseek-ai/cordis';
import type { SessionEvent, SessionId } from '@deepseek-ai/dsh-session';
declare module '@deepseek-ai/dsh-llm/types' {
    interface LlmRequestPurposeMap {
        'session-pool-summary': true;
    }
}
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'session-pool-summary': {
            kind: 'session-pool-summary';
        };
    }
}
export declare const inputSchema: z.ZodObject<{
    text: z.ZodString;
    provider: z.ZodString;
    model: z.ZodString;
}, z.core.$strip>;
export type SummaryInput = z.infer<typeof inputSchema>;
/** Host-only bounded projection: current turn's text, tool outcomes and exact last route. */
export declare function foldInput(state: SummaryInput, event: SessionEvent): SummaryInput;
export declare function generateSummary(ctx: Context, sessionId: SessionId, previous: string, input: SummaryInput, signal: AbortSignal): Promise<string>;
