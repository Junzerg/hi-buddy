import { type KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { Member } from './types.ts';
export declare const poolDomain: {
    name: string;
    version: number;
    layout: "per-record";
    tables: {
        members: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, Member>;
    };
};
/** Serial durable commits; immediate revocation also invalidates requests from earlier memberships. */
export declare class Pool {
    private table;
    private changed;
    private tail;
    private denied;
    private epochs;
    private lifetime;
    private jobs;
    private tasks;
    constructor(table: KvTable<string, Member>, changed?: () => void);
    get signal(): AbortSignal;
    read(id: string): Member;
    ticket(id: string): number;
    check(id: string, epoch: number): void;
    private enqueue;
    set(id: string, joined: boolean, authorize: () => Promise<void>): Promise<Member>;
    summarize(id: string, seq: number, generate: (previous: string, signal: AbortSignal) => Promise<string>, failure: (error: unknown) => void): void;
    close(): Promise<void>;
}
