/** Durable membership and the last successful auxiliary summary watermark. */
export interface Member {
    joined: boolean;
    summary: string;
    summarySeq: number;
}
export type PoolSession = {
    sessionId: string;
    workspaceTitle: string;
    sessionTitle: string;
    summary: string;
    status: 'running' | 'idle' | 'unloaded';
};
export type Delivery = {
    ok: true;
    messageId: string;
    status: 'accepted';
} | {
    ok: false;
    code: string;
    message: string;
};
/** All pool members visible to the UI caller; no histories or file capabilities. */
export interface PoolSnapshot {
    total: number;
    members: PoolSession[];
}
