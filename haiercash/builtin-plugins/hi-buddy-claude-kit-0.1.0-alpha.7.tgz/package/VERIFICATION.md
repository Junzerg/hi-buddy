# 验证记录

当前版本为 `0.1.0-alpha.7`。实测环境为 Ubuntu 24.04.5 x64、Node 24.22.2、Agent SDK 0.3.218 和 Claude Code CLI 2.1.218。宿主为 DSH `0.2.2-rc.1`，hi-buddy HEAD 为 `36dc280eaada5cdc2046770d587710f67ba492c3`，工作树包含宿主模型文案等本地改动。

| 验证 | 结果 |
| --- | --- |
| 构建和类型 | Host、Client 及生成的 Typert Remote 构建通过 |
| 自动化测试 | 27 项通过，覆盖 SDK 会话通信与认证、模型和连接失败的区分，以及凭据解析、审批去重、取消、进程清理和中断恢复 |
| 真实 DSH Loader 和 Typert Remote | Node 24 的 PATH 找不到 CLI 时从 nvm 的 Node 22 目录找到真实 2.1.218 并标为已验证。验证 PATH 优先、显式路径无回退、中文和空格路径、配置持久化、禁用回收探测进程 |
| 版本开放回归 | 报告 2.1.219 的可执行 fixture 标为尚未验证，Remote 发送通过真实 SDK 启动该文件。fixture 拒绝 SDK 的会话参数后出现包含已验证组合的通信错误。找不到、不可执行、启动失败及无法读取版本的 CLI 仍不可用 |
| 本机 Claude CLI 与真实 DSH Remote | 终端创建会话，DSH 发现项目和会话、读取历史并按同一 ID 续聊。终端再续聊后，DSH 刷新可读到新增消息 |
| 会话与任务 | 跨项目打开被拒绝。DSH 新建会话在首次发送后可通过 SDK 查询。原生问题可通过 Remote 回答，重复回答被拒绝。重启后的重复发送返回原任务 ID |
| Git 改动 Remote | 用真实临时 Git 仓库验证已跟踪文件、含中文空格的未跟踪文件、逐文件差异、拒绝列表之外的路径和非 Git 目录 |
| 项目和文件 Remote | 实际添加空会话项目并在重新启用后读取，验证目录列表、文件查找、新建、只读预览、拒绝覆盖和目录越界 |
| 浏览器页面 | 验证已验证组合、CLI 缺失提示和尚未验证状态下的发送。使用宿主主题和组件回归项目、文件树、会话、模型、问答和文件差异，在 390px 深色视图验证区域切换 |

原生会话往返及原生问答的真实模型测试使用已保存的外网 Anthropic Messages 路由，以及临时 DSH profile、工作目录和 Claude 配置目录。终端步骤使用本机 CLI 的非交互模式。

其他真实 CLI 版本尚未做模型往返验证。页面预览使用测试数据，macOS 和 Windows 仅验证候选路径。实际 Desktop 安装、真实宿主页面交互和内网认证待验收。

[项目入口](verification/projects-light.png) · [工作台与差异](verification/native-session-light.png) · [窄屏深色](verification/native-session-mobile-dark.png)
