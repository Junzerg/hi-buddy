export type SessionStatus = 'idle' | 'running' | 'waiting-for-input' | 'cancelling' | 'completed' | 'failed' | 'interrupted';
export interface TranscriptEntry {
    id: string;
    kind: 'user' | 'assistant' | 'tool' | 'tool-result' | 'notice';
    text: string;
    toolName?: string;
    toolUseId?: string;
}
export interface NativeProject {
    cwd: string;
    name: string;
}
export interface NativeSession {
    id: string;
    title: string;
    updatedAt: number;
}
export interface ModelSelection {
    provider: string;
    model: string;
}
export interface SessionState {
    id: string;
    cwd: string;
    status: SessionStatus;
    taskId?: string;
    error?: string;
    messages: TranscriptEntry[];
}
export interface StoredSession extends SessionState {
    version: 1;
    existing: boolean;
    requests: {
        id: string;
        digest: string;
        taskId: string;
    }[];
}
export interface ApprovalView {
    id: string;
    taskId: string;
    toolUseId: string;
    toolName: string;
    inputJson: string;
}
export interface SessionSnapshot {
    epoch: string;
    sequence: number;
    session: SessionState;
    approvals: ApprovalView[];
}
export type CliIssue = '' | 'notFound' | 'notExecutable' | 'startFailed';
export interface EnvironmentView {
    configuredPath: string;
    path: string;
    version: string;
    verifiedVersion: string;
    sdkVersion: string;
    available: boolean;
    verified: boolean;
    issue: CliIssue;
    error: string;
}
export interface WorktreeFile {
    path: string;
    status: string;
}
export interface WorktreeChanges {
    available: boolean;
    files: WorktreeFile[];
    truncated: boolean;
}
export interface FileDiff {
    text: string;
    truncated: boolean;
}
export interface ProjectFile {
    path: string;
    name: string;
    kind: 'directory' | 'file' | 'other';
}
export interface ProjectFileList {
    files: ProjectFile[];
    truncated: boolean;
}
export interface ProjectFilePreview {
    path: string;
    text: string;
    binary: boolean;
    truncated: boolean;
}
