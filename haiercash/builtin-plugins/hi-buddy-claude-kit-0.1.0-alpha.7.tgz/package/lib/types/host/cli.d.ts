import type { Context } from '@deepseek-ai/cordis';
import type { EnvironmentView } from '../types.ts';
/** Known working pair. Discovery accepts other CLIs that can report their version. */
export declare const VERIFIED_CLI_VERSION = "2.1.218";
export declare const SDK_VERSION = "0.3.218";
type CliHost = {
    platform: NodeJS.Platform;
    home: string;
    env: NodeJS.ProcessEnv;
};
/** Only inspect known installation layouts; never source shell profiles or scan project folders. */
export declare function commonCliCandidates(host: CliHost, list?: (path: string) => Promise<string[]>): AsyncGenerator<string>;
export declare function detectCli(subprocess: Context['subprocess'], configuredPath: string, cwd: string, signal: AbortSignal, host?: CliHost): Promise<EnvironmentView>;
export {};
