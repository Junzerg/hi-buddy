import { z } from 'zod';
import type { StoredSession } from '../types.ts';
export type RunRecord = Omit<StoredSession, 'messages'>;
export declare const claudeDomain: {
    name: string;
    version: number;
    layout: "per-record";
    global: {
        schema: z.ZodObject<{
            executable: z.ZodString;
        }, z.core.$strip>;
        initial: {
            executable: string;
        };
    };
    tables: {
        runs: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, RunRecord>;
        projects: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            cwd: string;
            name: string;
        }>;
    };
};
