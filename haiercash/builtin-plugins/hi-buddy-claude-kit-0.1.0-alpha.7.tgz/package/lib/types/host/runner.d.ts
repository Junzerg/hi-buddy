import type { Context } from '@deepseek-ai/cordis';
import type { TaskExecution } from './session-engine.ts';
import { DshModelSource } from './model-source.ts';
export declare function taskRunner(ctx: Context, models: DshModelSource, executable: (signal: AbortSignal) => Promise<string>, configDirectory: string): (task: TaskExecution) => Promise<void>;
