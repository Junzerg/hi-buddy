# 第三方依赖声明

`@anthropic-ai/claude-agent-sdk@0.3.218` 通过 npm 依赖使用。SDK 和其可选平台包适用 Anthropic 上游许可。运行时使用用户已安装并通过版本检查的 Claude Code CLI。许可证及使用条件见 [Anthropic 官方条款](https://code.claude.com/docs/en/legal-and-compliance)。

Cordis、DSH、React 和 UI primitives 由宿主提供，各自保留其许可证。
